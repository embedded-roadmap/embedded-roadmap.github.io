-- ============================================================
--  EmbeddedRoadmap Schema v1.1 — CV, Privacy, Projects
--  Run after v1.0 schema.sql
-- ============================================================

-- ── Enums (new) ────────────────────────────────────────────
CREATE TYPE cv_status         AS ENUM ('draft', 'published');
CREATE TYPE cv_template_id    AS ENUM ('precision', 'vector', 'circuit', 'minimal');
CREATE TYPE open_to_work      AS ENUM ('not_looking', 'open_to_work', 'hiring', 'freelance');

-- ── Engineer CV (master record) ────────────────────────────
CREATE TABLE engineer_cvs (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status            cv_status       DEFAULT 'draft',
  template_id       cv_template_id  DEFAULT 'precision',
  -- Personal
  full_name         VARCHAR(120),
  title             VARCHAR(200),
  email             VARCHAR(255),
  phone             VARCHAR(40),
  location          VARCHAR(120),
  summary           TEXT,
  open_to_work      open_to_work    DEFAULT 'not_looking',
  -- Social links (JSON for flexibility)
  social_links      JSONB DEFAULT '{"linkedin":null,"github":null,"hackaday":null,"gitlab":null,"website":null,"email":null}',
  -- Share
  share_token       VARCHAR(32) UNIQUE,
  share_enabled     BOOLEAN DEFAULT false,
  last_generated_at TIMESTAMPTZ,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)   -- one CV per user (update in place)
);

CREATE INDEX idx_cv_user         ON engineer_cvs(user_id);
CREATE INDEX idx_cv_share_token  ON engineer_cvs(share_token) WHERE share_token IS NOT NULL;

-- ── CV Education ───────────────────────────────────────────
CREATE TABLE cv_education (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id             UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  institution       VARCHAR(200) NOT NULL,
  degree            VARCHAR(100),
  field             VARCHAR(150),
  start_year        SMALLINT,
  end_year          SMALLINT,
  gpa               VARCHAR(10),
  honors            VARCHAR(200),
  relevant_courses  TEXT[],
  sort_order        SMALLINT DEFAULT 0
);

-- ── CV Certifications ──────────────────────────────────────
CREATE TABLE cv_certifications (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id         UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  name          VARCHAR(200) NOT NULL,
  issuer        VARCHAR(200),
  issued_date   DATE,
  expiry_date   DATE,
  credential_id VARCHAR(100),
  url           TEXT,
  sort_order    SMALLINT DEFAULT 0
);

-- ── CV Work Experience ─────────────────────────────────────
CREATE TABLE cv_experience (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id       UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  company     VARCHAR(200) NOT NULL,
  title       VARCHAR(200) NOT NULL,
  location    VARCHAR(120),
  start_date  DATE NOT NULL,
  end_date    DATE,
  is_current  BOOLEAN DEFAULT false,
  description TEXT,
  highlights  TEXT[],
  tech_stack  TEXT[],
  domains     TEXT[],
  sort_order  SMALLINT DEFAULT 0
);

-- ── Engineering Projects ──────────────────────────────────
CREATE TABLE cv_projects (
  id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id              UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  cv_id                UUID REFERENCES engineer_cvs(id) ON DELETE SET NULL,
  title                VARCHAR(200) NOT NULL,
  description          TEXT,
  tech_stack           TEXT[],
  hardware_stack       TEXT[],
  firmware_stack       TEXT[],
  related_topic_slugs  TEXT[],
  repo_url             TEXT,
  project_url          TEXT,
  platform             VARCHAR(20) DEFAULT 'github',
  image_url            TEXT,
  video_url            TEXT,
  is_featured          BOOLEAN DEFAULT false,
  is_public            BOOLEAN DEFAULT true,
  start_date           DATE,
  end_date             DATE,
  created_at           TIMESTAMPTZ DEFAULT NOW(),
  updated_at           TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_projects_user ON cv_projects(user_id);
CREATE INDEX idx_projects_cv   ON cv_projects(cv_id);

-- ── CV Publications ────────────────────────────────────────
CREATE TABLE cv_publications (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id      UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  title      VARCHAR(400) NOT NULL,
  venue      VARCHAR(200),
  year       SMALLINT,
  url        TEXT,
  doi        VARCHAR(100),
  authors    TEXT[],
  sort_order SMALLINT DEFAULT 0
);

-- ── CV Patents ─────────────────────────────────────────────
CREATE TABLE cv_patents (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id          UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  title          VARCHAR(400) NOT NULL,
  patent_number  VARCHAR(60),
  filing_date    DATE,
  grant_date     DATE,
  jurisdiction   VARCHAR(10),
  url            TEXT,
  inventors      TEXT[],
  sort_order     SMALLINT DEFAULT 0
);

-- ── CV Awards ─────────────────────────────────────────────
CREATE TABLE cv_awards (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id       UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  title       VARCHAR(200) NOT NULL,
  issuer      VARCHAR(200),
  year        SMALLINT,
  description TEXT,
  sort_order  SMALLINT DEFAULT 0
);

-- ── CV References ─────────────────────────────────────────
CREATE TABLE cv_references (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id        UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  name         VARCHAR(120) NOT NULL,
  title        VARCHAR(200),
  company      VARCHAR(200),
  email        VARCHAR(255),
  phone        VARCHAR(40),
  relationship VARCHAR(100),
  is_public    BOOLEAN DEFAULT false,
  sort_order   SMALLINT DEFAULT 0
);

-- ── CV Manual Skills ───────────────────────────────────────
CREATE TABLE cv_manual_skills (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id      UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  category   VARCHAR(80) NOT NULL,
  skills     TEXT[],
  sort_order SMALLINT DEFAULT 0
);

-- ── CV Languages ──────────────────────────────────────────
CREATE TABLE cv_languages (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cv_id      UUID NOT NULL REFERENCES engineer_cvs(id) ON DELETE CASCADE,
  name       VARCHAR(60) NOT NULL,
  level      VARCHAR(20) DEFAULT 'professional',
  sort_order SMALLINT DEFAULT 0
);

-- ── Privacy Settings ──────────────────────────────────────
CREATE TABLE user_privacy_settings (
  user_id                    UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  is_public                  BOOLEAN DEFAULT true,
  show_percentile            BOOLEAN DEFAULT true,
  show_xp                    BOOLEAN DEFAULT true,
  show_salary_estimates      BOOLEAN DEFAULT true,
  show_streak                BOOLEAN DEFAULT true,
  show_badges                BOOLEAN DEFAULT true,
  show_projects              BOOLEAN DEFAULT true,
  allow_recruiter_view       BOOLEAN DEFAULT true,
  open_to_work               open_to_work DEFAULT 'not_looking',
  gdpr_data_export_requested BOOLEAN DEFAULT false,
  gdpr_delete_requested      BOOLEAN DEFAULT false,
  updated_at                 TIMESTAMPTZ DEFAULT NOW()
);

-- ── Updated at triggers for new tables ───────────────────
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['engineer_cvs','cv_projects','user_privacy_settings']
  LOOP
    EXECUTE format('
      CREATE TRIGGER set_updated_at
      BEFORE UPDATE ON %I
      FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at()', t);
  END LOOP;
END $$;

-- ── Function: Get full CV with all sections ───────────────
CREATE OR REPLACE FUNCTION get_full_cv(p_user_id UUID)
RETURNS JSONB AS $$
DECLARE
  v_cv JSONB;
BEGIN
  SELECT to_jsonb(c.*) || jsonb_build_object(
    'education',     (SELECT jsonb_agg(to_jsonb(e) ORDER BY e.sort_order) FROM cv_education e WHERE e.cv_id = c.id),
    'certifications',(SELECT jsonb_agg(to_jsonb(cert) ORDER BY cert.sort_order) FROM cv_certifications cert WHERE cert.cv_id = c.id),
    'experience',    (SELECT jsonb_agg(to_jsonb(ex) ORDER BY ex.sort_order) FROM cv_experience ex WHERE ex.cv_id = c.id),
    'projects',      (SELECT jsonb_agg(to_jsonb(p) ORDER BY p.is_featured DESC, p.start_date DESC) FROM cv_projects p WHERE p.cv_id = c.id),
    'publications',  (SELECT jsonb_agg(to_jsonb(pub) ORDER BY pub.year DESC) FROM cv_publications pub WHERE pub.cv_id = c.id),
    'patents',       (SELECT jsonb_agg(to_jsonb(pat) ORDER BY pat.filing_date DESC) FROM cv_patents pat WHERE pat.cv_id = c.id),
    'awards',        (SELECT jsonb_agg(to_jsonb(a) ORDER BY a.year DESC) FROM cv_awards a WHERE a.cv_id = c.id),
    'references',    (SELECT jsonb_agg(to_jsonb(r)) FROM cv_references r WHERE r.cv_id = c.id AND r.is_public = true),
    'manual_skills', (SELECT jsonb_agg(to_jsonb(s) ORDER BY s.sort_order) FROM cv_manual_skills s WHERE s.cv_id = c.id),
    'languages',     (SELECT jsonb_agg(to_jsonb(l) ORDER BY l.sort_order) FROM cv_languages l WHERE l.cv_id = c.id)
  )
  INTO v_cv
  FROM engineer_cvs c
  WHERE c.user_id = p_user_id;

  RETURN v_cv;
END;
$$ LANGUAGE plpgsql;
