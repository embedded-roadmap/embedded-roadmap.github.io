#!/usr/bin/env node
// scripts/db-migrate.js — Run schema migrations in order
const { Pool } = require('pg')
const fs = require('fs')
const path = require('path')

const pool = new Pool({ connectionString: process.env.DATABASE_URL })

async function migrate() {
  const client = await pool.connect()
  try {
    // Create migrations tracking table
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        id SERIAL PRIMARY KEY,
        version VARCHAR(80) UNIQUE NOT NULL,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      )
    `)

    const migrations = [
      { version: '001_schema', file: 'schema.sql' },
    ].filter(m => {
      const filePath = path.join(__dirname, m.file)
      return fs.existsSync(filePath)
    })

    for (const migration of migrations) {
      const { rows } = await client.query('SELECT id FROM schema_migrations WHERE version=$1', [migration.version])
      if (rows.length > 0) { console.log(`✓ ${migration.version} already applied`); continue }

      console.log(`⟳ Applying ${migration.version}...`)
      const sql = fs.readFileSync(path.join(__dirname, migration.file), 'utf8')
      
      await client.query('BEGIN')
      try {
        await client.query(sql)
        await client.query('INSERT INTO schema_migrations(version) VALUES($1)', [migration.version])
        await client.query('COMMIT')
        console.log(`✓ ${migration.version} applied`)
      } catch (e) {
        await client.query('ROLLBACK')
        throw e
      }
    }
    console.log('✓ All migrations complete')
  } finally {
    client.release()
    await pool.end()
  }
}

migrate().catch(e => { console.error('Migration failed:', e.message); process.exit(1) })
