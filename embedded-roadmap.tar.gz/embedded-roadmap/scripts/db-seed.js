#!/usr/bin/env node
// scripts/db-seed.js — Comprehensive seed for branches and topics

const { Pool } = require('pg')

const pool = new Pool({ connectionString: process.env.DATABASE_URL })

// ── Branch definitions ────────────────────────────────────────

const BRANCHES = [
  // Hardware
  { slug: 'analog-electronics',     name: 'Analog Electronics',           domain: 'hardware',       icon: '〰️', color: '#38bdf8', sort: 1,  description: 'From passive components to precision IC design — the complete analog signal chain.' },
  { slug: 'pcb-design',             name: 'PCB Design & Layout',          domain: 'hardware',       icon: '🔲', color: '#34d399', sort: 2,  description: 'From schematic capture to advanced SI/PI simulation and high-speed layout.' },
  { slug: 'power-electronics',      name: 'Power Electronics',            domain: 'hardware',       icon: '⚡', color: '#fbbf24', sort: 3,  description: 'Switching converters, magnetics, GaN/SiC, motor drives, and high-power system design.' },
  { slug: 'sensors-instrumentation',name: 'Sensors & Instrumentation',    domain: 'hardware',       icon: '📊', color: '#a78bfa', sort: 4,  description: 'Sensor interfaces, signal conditioning, calibration, and measurement systems.' },
  { slug: 'digital-design',         name: 'Digital Logic & Design',       domain: 'hardware',       icon: '💻', color: '#60a5fa', sort: 5,  description: 'Combinational and sequential logic, timing analysis, and digital system design.' },
  { slug: 'high-speed-pcb',         name: 'High-Speed PCB & Signal Integrity', domain: 'hardware', icon: '⚡', color: '#f472b6', sort: 6,  description: 'Signal integrity, PDN design, DDR layout, and high-speed PCIe/SERDES routing.' },
  // Firmware
  { slug: 'embedded-systems',       name: 'Embedded Systems Foundations', domain: 'firmware',       icon: '🔧', color: '#818cf8', sort: 10, description: 'MCU architecture, peripherals, bare-metal programming, and system bring-up.' },
  { slug: 'rtos-firmware',          name: 'RTOS & Firmware Engineering',  domain: 'firmware',       icon: '⏱️', color: '#c4b5fd', sort: 11, description: 'FreeRTOS, Zephyr, interrupt handling, DMA, and production firmware architecture.' },
  { slug: 'embedded-linux',         name: 'Embedded Linux',               domain: 'firmware',       icon: '🐧', color: '#6ee7b7', sort: 12, description: 'Yocto, Device Tree, kernel drivers, BSP development, and Linux system bring-up.' },
  { slug: 'device-drivers',         name: 'Device Driver Development',    domain: 'firmware',       icon: '🔌', color: '#fde68a', sort: 13, description: 'Linux kernel drivers, I2C/SPI/UART/USB drivers, and driver testing.' },
  { slug: 'firmware-security',      name: 'Firmware Security',            domain: 'firmware',       icon: '🔒', color: '#fca5a5', sort: 14, description: 'Secure boot, TrustZone, PSA Certified, cryptography, and threat modeling for embedded.' },
  // Systems
  { slug: 'fpga-digital-design',    name: 'FPGA & Digital Design',        domain: 'system',         icon: '🖥️', color: '#a78bfa', sort: 20, description: 'VHDL/Verilog, FPGA timing, AXI IPs, HLS, SoC design, and ASIC methodology.' },
  { slug: 'computer-architecture',  name: 'Computer Architecture',        domain: 'system',         icon: '🏗️', color: '#93c5fd', sort: 21, description: 'Processor microarchitecture, cache hierarchy, memory systems, and SoC design.' },
  { slug: 'dsp-signal-processing',  name: 'Digital Signal Processing',    domain: 'system',         icon: '📈', color: '#6ee7b7', sort: 22, description: 'Sampling theory, FIR/IIR filters, FFT, spectral analysis, and adaptive filtering.' },
  // Specializations
  { slug: 'wireless-rf',            name: 'Wireless & RF',                domain: 'specialization', icon: '📡', color: '#fb7185', sort: 30, description: 'BLE, WiFi, LoRa, NB-IoT, RF design, EMC certification, and mmWave.' },
  { slug: 'emc-compliance',         name: 'EMC & Compliance',             domain: 'specialization', icon: '🛡️', color: '#fbbf24', sort: 31, description: 'Conducted and radiated EMC, filter design, pre-compliance testing, CE/FCC certification.' },
  { slug: 'functional-safety',      name: 'Functional Safety (IEC/ISO)',  domain: 'specialization', icon: '⚠️', color: '#f87171', sort: 32, description: 'IEC 61508, ISO 26262, SIL/ASIL levels, safety analysis (FMEA, FTA), and verification.' },
  { slug: 'edge-ai-ml',             name: 'Edge AI & ML on Embedded',     domain: 'specialization', icon: '🧠', color: '#60a5fa', sort: 33, description: 'TinyML, CMSIS-NN, TFLite Micro, model quantization, and neural network inference on MCU/FPGA.' },
  { slug: 'test-validation',        name: 'Test & Validation',            domain: 'specialization', icon: '🔬', color: '#34d399', sort: 34, description: 'ATE, JTAG, boundary scan, ICT, functional test design, and automated test frameworks.' },
  // Industry
  { slug: 'medical-wearables',      name: 'Medical & Wearable Electronics',domain: 'industry',      icon: '💊', color: '#34d399', sort: 40, description: 'Bio-potential measurement, IEC 60601, EU MDR, wearable power, and sensor fusion.' },
  { slug: 'automotive-electronics', name: 'Automotive Electronics',       domain: 'industry',       icon: '🚗', color: '#fbbf24', sort: 41, description: 'ISO 26262, AUTOSAR, CAN/LIN/FlexRay/Ethernet, harsh environment design, and powertrain.' },
  { slug: 'industrial-automation',  name: 'Industrial Automation',        domain: 'industry',       icon: '🏭', color: '#818cf8', sort: 42, description: 'Fieldbus protocols (Modbus, PROFIBUS, EtherCAT), PLCs, hazardous area design, and IEC 61131.' },
  { slug: 'aerospace-defense',      name: 'Aerospace & Defense',          domain: 'industry',       icon: '🚀', color: '#6ee7b7', sort: 43, description: 'MIL-STD-810, DO-254/DO-178C, radiation-hardened design, and high-reliability electronics.' },
  { slug: 'bms-energy-storage',     name: 'BMS & Energy Storage',         domain: 'industry',       icon: '🔋', color: '#fde68a', sort: 44, description: 'Battery management, cell chemistry, BMS hardware/firmware, and EV charging design.' },
]

// ── Inline topic definitions (abridged — full data in topic files) ──

const ANALOG_TOPICS = [
  { slug: 'passive-components-fundamentals', name: 'Passive Component Fundamentals', branch_slug: 'analog-electronics', level: 1, difficulty: 12, difficulty_tier: 'foundational', estimated_hours: 8, description: 'Resistors, capacitors, inductors: real-world behavior, tolerance, parasitics, temperature coefficients.' },
  { slug: 'dc-circuit-analysis', name: 'DC Circuit Analysis', branch_slug: 'analog-electronics', level: 1, difficulty: 15, difficulty_tier: 'foundational', estimated_hours: 10, description: 'KVL, KCL, Thevenin/Norton, mesh and nodal analysis.' },
  { slug: 'ac-circuit-analysis', name: 'AC Circuit Analysis & Impedance', branch_slug: 'analog-electronics', level: 1, difficulty: 20, difficulty_tier: 'foundational', estimated_hours: 12, description: 'Phasors, complex impedance, Bode plots from first principles.' },
  { slug: 'diode-circuits', name: 'Diode Circuits & Applications', branch_slug: 'analog-electronics', level: 1, difficulty: 18, difficulty_tier: 'foundational', estimated_hours: 8, description: 'Shockley equation, rectifiers, Zener, clamps, protection circuits.' },
  { slug: 'bipolar-transistor-fundamentals', name: 'BJT Fundamentals', branch_slug: 'analog-electronics', level: 1, difficulty: 28, difficulty_tier: 'foundational', estimated_hours: 15, description: 'Ebers-Moll model, biasing, small-signal analysis, switching.' },
  { slug: 'mosfet-fundamentals', name: 'MOSFET Fundamentals', branch_slug: 'analog-electronics', level: 1, difficulty: 28, difficulty_tier: 'foundational', estimated_hours: 15, description: 'MOSFET physics, threshold, parasitic capacitances, switching.' },
  { slug: 'opamp-ideal-and-real', name: 'Op-Amp: Ideal vs Real Behavior', branch_slug: 'analog-electronics', level: 2, difficulty: 35, difficulty_tier: 'intermediate', estimated_hours: 20, description: 'Vos, bias current, CMRR, PSRR, GBW, slew rate, noise.' },
  { slug: 'opamp-configurations', name: 'Op-Amp Circuit Configurations', branch_slug: 'analog-electronics', level: 2, difficulty: 38, difficulty_tier: 'intermediate', estimated_hours: 18, description: 'Inverting, non-inverting, InAmp, integrators, Sallen-Key.' },
  { slug: 'filter-design', name: 'Active & Passive Filter Design', branch_slug: 'analog-electronics', level: 2, difficulty: 45, difficulty_tier: 'intermediate', estimated_hours: 20, description: 'Butterworth, Chebyshev, Bessel, pole-zero placement.' },
  { slug: 'feedback-theory', name: 'Feedback Theory & Stability', branch_slug: 'analog-electronics', level: 2, difficulty: 50, difficulty_tier: 'intermediate', estimated_hours: 20, description: 'Loop gain, phase/gain margin, Nyquist, compensation.' },
  { slug: 'voltage-references', name: 'Voltage References & Bandgap', branch_slug: 'analog-electronics', level: 2, difficulty: 48, difficulty_tier: 'intermediate', estimated_hours: 16, description: 'Bandgap design, PTAT/CTAT, noise, drift.' },
  { slug: 'sensor-signal-conditioning', name: 'Sensor Signal Conditioning', branch_slug: 'analog-electronics', level: 3, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 20, description: 'Bridge circuits, 4-20mA, RTD, error budget.' },
  { slug: 'adc-fundamentals', name: 'ADC Architecture & Selection', branch_slug: 'analog-electronics', level: 3, difficulty: 58, difficulty_tier: 'advanced', estimated_hours: 22, description: 'SAR, Delta-Sigma, INL, DNL, ENOB, anti-alias.' },
  { slug: 'analog-noise-analysis', name: 'Analog Noise Analysis', branch_slug: 'analog-electronics', level: 3, difficulty: 62, difficulty_tier: 'advanced', estimated_hours: 20, description: 'Johnson noise, shot noise, 1/f, noise figure, NSD.' },
  { slug: 'instrumentation-amplifier-design', name: 'Instrumentation Amplifier Design', branch_slug: 'analog-electronics', level: 3, difficulty: 60, difficulty_tier: 'advanced', estimated_hours: 18, description: 'Three-op-amp InAmp, CMRR vs frequency, noise, AD8221.' },
  { slug: 'current-sensing', name: 'Current Sensing Techniques', branch_slug: 'analog-electronics', level: 3, difficulty: 52, difficulty_tier: 'advanced', estimated_hours: 14, description: 'High-side/low-side, shunt, CT, Hall-effect sensors.' },
  { slug: 'oscillator-design', name: 'Oscillator Design', branch_slug: 'analog-electronics', level: 4, difficulty: 65, difficulty_tier: 'advanced', estimated_hours: 20, description: 'Colpitts, Pierce crystal, phase noise, TCXO/OCXO.' },
  { slug: 'pll-design', name: 'PLL Design & Analysis', branch_slug: 'analog-electronics', level: 4, difficulty: 72, difficulty_tier: 'expert', estimated_hours: 28, description: 'PFD, charge pump, loop filter, VCO, phase noise.' },
  { slug: 'transimpedance-amplifier', name: 'Transimpedance Amplifier Design', branch_slug: 'analog-electronics', level: 4, difficulty: 68, difficulty_tier: 'expert', estimated_hours: 20, description: 'TIA for photodiodes, stability, noise optimization.' },
  { slug: 'ecg-afe-design', name: 'ECG/Bio-Potential AFE Design', branch_slug: 'analog-electronics', level: 5, difficulty: 78, difficulty_tier: 'expert', estimated_hours: 30, description: 'DRL, Wilson CT, defibrillator protection, IEC 60601.' },
  { slug: 'isolation-amplifier-design', name: 'Isolation Amplifier & Galvanic Isolation', branch_slug: 'analog-electronics', level: 5, difficulty: 75, difficulty_tier: 'expert', estimated_hours: 25, description: 'Reinforced isolation, CMTI, creepage/clearance.' },
  { slug: 'delta-sigma-adc-deep', name: 'Delta-Sigma ADC Deep Dive', branch_slug: 'analog-electronics', level: 5, difficulty: 80, difficulty_tier: 'expert', estimated_hours: 28, description: 'Noise shaping, SINC filters, idle tones, 24-bit ADCs.' },
  { slug: 'high-voltage-analog-design', name: 'High-Voltage Analog Design (>500V)', branch_slug: 'analog-electronics', level: 6, difficulty: 88, difficulty_tier: 'elite', estimated_hours: 40, description: 'Partial discharge, HV op-amps, bootstrapping, IEC 60664.' },
  { slug: 'precision-analog-ic-design', name: 'Precision Analog IC Design (μV-level)', branch_slug: 'analog-electronics', level: 7, difficulty: 95, difficulty_tier: 'legendary', estimated_hours: 60, description: 'Mismatch, common-centroid layout, 1/f noise, chopper IC.' },
]

const EMBEDDED_TOPICS = [
  { slug: 'c-for-embedded', name: 'C for Embedded Systems', branch_slug: 'embedded-systems', level: 1, difficulty: 20, difficulty_tier: 'foundational', estimated_hours: 15, description: 'Fixed-width types, volatile, bitfields, endianness, memory sections.' },
  { slug: 'microcontroller-architecture', name: 'Microcontroller Architecture', branch_slug: 'embedded-systems', level: 1, difficulty: 25, difficulty_tier: 'foundational', estimated_hours: 15, description: 'Cortex-M register file, NVIC, SysTick, MPU, fault types.' },
  { slug: 'gpio-and-peripherals-basics', name: 'GPIO & Basic Peripherals', branch_slug: 'embedded-systems', level: 1, difficulty: 18, difficulty_tier: 'foundational', estimated_hours: 10, description: 'GPIO modes, EXTI interrupts, clock gating.' },
  { slug: 'uart-spi-i2c', name: 'UART, SPI & I²C Protocols', branch_slug: 'embedded-systems', level: 1, difficulty: 25, difficulty_tier: 'foundational', estimated_hours: 15, description: 'Frame formats, CPOL/CPHA, I2C stretching, DMA transactions.' },
  { slug: 'interrupt-driven-firmware', name: 'Interrupt-Driven Firmware Architecture', branch_slug: 'rtos-firmware', level: 2, difficulty: 38, difficulty_tier: 'intermediate', estimated_hours: 18, description: 'NVIC priorities, ISR latency, deferred processing.' },
  { slug: 'dma-programming', name: 'DMA Programming & Optimization', branch_slug: 'embedded-systems', level: 2, difficulty: 48, difficulty_tier: 'intermediate', estimated_hours: 18, description: 'DMA circular, double-buffer, DMAMUX, cache coherency.' },
  { slug: 'freertos-fundamentals', name: 'FreeRTOS Fundamentals', branch_slug: 'rtos-firmware', level: 2, difficulty: 42, difficulty_tier: 'intermediate', estimated_hours: 20, description: 'Tasks, scheduler, context switch, stack overflow, heap.' },
  { slug: 'freertos-synchronization', name: 'FreeRTOS Synchronization', branch_slug: 'rtos-firmware', level: 2, difficulty: 50, difficulty_tier: 'intermediate', estimated_hours: 20, description: 'Queues, semaphores, mutex, priority inheritance, deadlock.' },
  { slug: 'ble-firmware', name: 'BLE Firmware Development', branch_slug: 'rtos-firmware', level: 3, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 25, description: 'GAP/GATT/ATT, connection parameters, PHY selection.' },
  { slug: 'firmware-bootloader', name: 'Bootloader Design & OTA Updates', branch_slug: 'rtos-firmware', level: 3, difficulty: 60, difficulty_tier: 'advanced', estimated_hours: 25, description: 'MCUboot, DFU, firmware signing, rollback protection.' },
  { slug: 'power-management-firmware', name: 'Power Management Firmware', branch_slug: 'rtos-firmware', level: 3, difficulty: 58, difficulty_tier: 'advanced', estimated_hours: 20, description: 'Sleep modes, WFI/WFE, STOP, RTC wakeup, current budgeting.' },
  { slug: 'zephyr-rtos', name: 'Zephyr RTOS Development', branch_slug: 'rtos-firmware', level: 4, difficulty: 65, difficulty_tier: 'advanced', estimated_hours: 30, description: 'Devicetree, Kconfig, west build, Zephyr driver model.' },
  { slug: 'motor-control-firmware', name: 'Motor Control Firmware (FOC)', branch_slug: 'rtos-firmware', level: 4, difficulty: 78, difficulty_tier: 'expert', estimated_hours: 35, description: 'FOC, Clarke/Park transforms, SVPWM, encoder feedback.' },
  { slug: 'misra-c-coding', name: 'MISRA-C Compliant Coding', branch_slug: 'rtos-firmware', level: 5, difficulty: 68, difficulty_tier: 'expert', estimated_hours: 20, description: 'MISRA C:2012 rules, static analysis, deviation management.' },
  { slug: 'iec62304-medical-firmware', name: 'IEC 62304 Medical Firmware', branch_slug: 'rtos-firmware', level: 6, difficulty: 82, difficulty_tier: 'elite', estimated_hours: 40, description: 'Software safety class A/B/C, V&V, SOUP management.' },
  { slug: 'real-time-determinism', name: 'Real-Time Determinism & WCET', branch_slug: 'rtos-firmware', level: 6, difficulty: 88, difficulty_tier: 'elite', estimated_hours: 45, description: 'WCET analysis, schedulability (RMS/EDF), jitter.' },
  { slug: 'autosar-classic', name: 'AUTOSAR Classic Platform', branch_slug: 'rtos-firmware', level: 5, difficulty: 82, difficulty_tier: 'expert', estimated_hours: 40, description: 'SWC, RTE, MCAL, ARXML, ComStack, OSEK OS.' },
]

const PCB_TOPICS = [
  { slug: 'pcb-fundamentals', name: 'PCB Fundamentals & Layer Stack-Up', branch_slug: 'pcb-design', level: 1, difficulty: 15, difficulty_tier: 'foundational', estimated_hours: 10, description: 'FR4, layer count, controlled impedance stack-ups, IPC-6012.' },
  { slug: 'schematic-capture', name: 'Schematic Capture & Design Rules', branch_slug: 'pcb-design', level: 1, difficulty: 18, difficulty_tier: 'foundational', estimated_hours: 12, description: 'Hierarchical schematics, ERC, design reuse blocks.' },
  { slug: 'pcb-layout-best-practices', name: 'PCB Layout Best Practices', branch_slug: 'pcb-design', level: 2, difficulty: 35, difficulty_tier: 'intermediate', estimated_hours: 15, description: 'Component placement, bypass cap, ground plane stitching.' },
  { slug: 'grounding-strategies', name: 'Grounding Strategies for Mixed-Signal PCBs', branch_slug: 'pcb-design', level: 2, difficulty: 48, difficulty_tier: 'intermediate', estimated_hours: 15, description: 'Split planes, star ground, quiet analog partitioning.' },
  { slug: 'controlled-impedance-routing', name: 'Controlled Impedance Routing', branch_slug: 'pcb-design', level: 3, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 18, description: 'Microstrip/stripline, differential pairs, length matching.' },
  { slug: 'high-speed-digital-pcb', name: 'High-Speed Digital PCB Design', branch_slug: 'pcb-design', level: 3, difficulty: 65, difficulty_tier: 'advanced', estimated_hours: 22, description: 'Transmission lines, reflections, termination, via stubs.' },
  { slug: 'power-distribution-network', name: 'PCB PDN Design', branch_slug: 'pcb-design', level: 3, difficulty: 68, difficulty_tier: 'advanced', estimated_hours: 20, description: 'Target impedance, mounting inductance, plane resonance.' },
  { slug: 'rf-pcb-design', name: 'RF PCB Design (Sub-6GHz)', branch_slug: 'pcb-design', level: 4, difficulty: 78, difficulty_tier: 'expert', estimated_hours: 25, description: 'RF routing, via fence, Rogers material, match network.' },
  { slug: 'pcb-emi-emc-design', name: 'PCB EMC Design Techniques', branch_slug: 'pcb-design', level: 4, difficulty: 75, difficulty_tier: 'expert', estimated_hours: 25, description: 'Return current paths, slot antennas, filter at connectors.' },
  { slug: 'signal-integrity-simulation', name: 'Signal Integrity Simulation', branch_slug: 'pcb-design', level: 5, difficulty: 80, difficulty_tier: 'expert', estimated_hours: 30, description: 'IBIS, eye diagrams, jitter, ISI, Hyperlynx SI.' },
  { slug: 'flex-rigid-flex-pcb', name: 'Flex & Rigid-Flex PCB Design', branch_slug: 'pcb-design', level: 5, difficulty: 73, difficulty_tier: 'expert', estimated_hours: 25, description: 'Bend radius, IPC-2223, stiffener, coverlay.' },
  { slug: 'high-speed-serial-design', name: 'High-Speed Serial (>10Gbps)', branch_slug: 'pcb-design', level: 6, difficulty: 88, difficulty_tier: 'elite', estimated_hours: 45, description: 'PCIe Gen4/5, SERDES, equalization, eye mask compliance.' },
]

const WIRELESS_TOPICS = [
  { slug: 'rf-fundamentals', name: 'RF Fundamentals', branch_slug: 'wireless-rf', level: 1, difficulty: 30, difficulty_tier: 'foundational', estimated_hours: 15, description: 'S-parameters, Smith chart, VSWR, impedance matching.' },
  { slug: 'rf-link-budget', name: 'RF Link Budget Analysis', branch_slug: 'wireless-rf', level: 2, difficulty: 42, difficulty_tier: 'intermediate', estimated_hours: 12, description: 'Friis equation, EIRP, fade margin, SNR budget.' },
  { slug: 'ble-hardware-design', name: 'BLE Hardware Design', branch_slug: 'wireless-rf', level: 2, difficulty: 48, difficulty_tier: 'intermediate', estimated_hours: 18, description: 'nRF52 RF layout, crystal, DCDC for BLE, certified modules.' },
  { slug: 'wifi-hardware-design', name: 'WiFi Hardware Design', branch_slug: 'wireless-rf', level: 3, difficulty: 58, difficulty_tier: 'advanced', estimated_hours: 20, description: 'ESP32 RF front-end, antenna diversity, co-existence.' },
  { slug: 'lora-lorawan-design', name: 'LoRa & LoRaWAN System Design', branch_slug: 'wireless-rf', level: 3, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 20, description: 'Chirp spread spectrum, SF, LoRaWAN Class A/B/C.' },
  { slug: 'cellular-nb-iot', name: 'NB-IoT & LTE-M Hardware Design', branch_slug: 'wireless-rf', level: 3, difficulty: 60, difficulty_tier: 'advanced', estimated_hours: 22, description: 'nRF9160, eDRX, PSM, antenna for 700-900MHz.' },
  { slug: 'emc-fundamentals', name: 'EMC Fundamentals', branch_slug: 'emc-compliance', level: 3, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 18, description: 'Conducted vs radiated, near/far field, CM vs DM.' },
  { slug: 'esd-protection-design', name: 'ESD Protection Design', branch_slug: 'emc-compliance', level: 3, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 15, description: 'HBM/MM/CDM, TVS selection, IEC 61000-4-2.' },
  { slug: 'pre-compliance-emc', name: 'Pre-Compliance EMC Testing', branch_slug: 'emc-compliance', level: 4, difficulty: 68, difficulty_tier: 'expert', estimated_hours: 20, description: 'TinySA, LISN, near-field scanning, fixup strategies.' },
  { slug: 'red-fcc-certification', name: 'CE (RED) & FCC Certification', branch_slug: 'emc-compliance', level: 4, difficulty: 65, difficulty_tier: 'advanced', estimated_hours: 20, description: 'RED 2014/53/EU, FCC Part 15, Declaration of Conformity.' },
  { slug: 'rf-impedance-matching', name: 'RF Impedance Matching Networks', branch_slug: 'wireless-rf', level: 2, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 18, description: 'L/Pi/T networks, VNA calibration, S11 optimization.' },
  { slug: 'antenna-design-fundamentals', name: 'Antenna Design Fundamentals', branch_slug: 'wireless-rf', level: 4, difficulty: 70, difficulty_tier: 'expert', estimated_hours: 25, description: 'Gain, directivity, polarization, patch antenna design.' },
  { slug: 'rf-low-noise-amplifier', name: 'RF LNA Design', branch_slug: 'wireless-rf', level: 4, difficulty: 78, difficulty_tier: 'expert', estimated_hours: 28, description: 'Noise figure, stability circles, IIP3, source impedance.' },
  { slug: 'rf-system-architecture', name: 'RF System Architecture', branch_slug: 'wireless-rf', level: 5, difficulty: 85, difficulty_tier: 'elite', estimated_hours: 35, description: 'Superheterodyne, direct-conversion, cascaded NF/IIP3.' },
]

const POWER_TOPICS = [
  { slug: 'buck-converter-basics', name: 'Buck Converter Fundamentals', branch_slug: 'power-electronics', level: 1, difficulty: 30, difficulty_tier: 'intermediate', estimated_hours: 15, description: 'CCM/DCM, duty cycle, ripple, synchronous rectification.' },
  { slug: 'boost-converter-design', name: 'Boost Converter Design', branch_slug: 'power-electronics', level: 2, difficulty: 40, difficulty_tier: 'intermediate', estimated_hours: 18, description: 'RHP zero, current-mode control, efficiency optimization.' },
  { slug: 'magnetics-design', name: 'Magnetics Design', branch_slug: 'power-electronics', level: 2, difficulty: 58, difficulty_tier: 'advanced', estimated_hours: 25, description: 'Core materials, Steinmetz, Dowell winding loss, thermal.' },
  { slug: 'switching-converter-compensation', name: 'Switching Converter Loop Compensation', branch_slug: 'power-electronics', level: 2, difficulty: 62, difficulty_tier: 'advanced', estimated_hours: 25, description: 'Type II/III compensators, crossover frequency, state-space.' },
  { slug: 'flyback-converter', name: 'Flyback Converter Design', branch_slug: 'power-electronics', level: 3, difficulty: 65, difficulty_tier: 'advanced', estimated_hours: 25, description: 'DCM/CCM flyback, snubber, optocoupler feedback, EMI.' },
  { slug: 'mosfet-gate-drive', name: 'MOSFET/IGBT Gate Drive Design', branch_slug: 'power-electronics', level: 3, difficulty: 60, difficulty_tier: 'advanced', estimated_hours: 20, description: 'Gate charge, Miller plateau, bootstrap, shoot-through.' },
  { slug: 'thermal-management-design', name: 'Thermal Management & Heatsink', branch_slug: 'power-electronics', level: 3, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 20, description: 'Thermal resistance network, TIM, heatsink optimization.' },
  { slug: 'gan-power-design', name: 'GaN Power Device Design', branch_slug: 'power-electronics', level: 4, difficulty: 78, difficulty_tier: 'expert', estimated_hours: 30, description: 'HEMT, false turn-on, PCB layout, gate drive for GaN.' },
  { slug: 'sic-mosfet-design', name: 'SiC MOSFET Design', branch_slug: 'power-electronics', level: 4, difficulty: 80, difficulty_tier: 'expert', estimated_hours: 28, description: 'Gate oxide, threshold stability, short-circuit withstand.' },
  { slug: 'three-phase-inverter', name: 'Three-Phase Inverter Design', branch_slug: 'power-electronics', level: 4, difficulty: 82, difficulty_tier: 'expert', estimated_hours: 35, description: 'SVPWM, dead time, output filter, bearing current.' },
  { slug: 'battery-management-system-power', name: 'BMS Power Architecture', branch_slug: 'bms-energy-storage', level: 4, difficulty: 72, difficulty_tier: 'expert', estimated_hours: 30, description: 'Cell balancing, SOC/SOH estimation, CC/CV charging.' },
  { slug: 'wireless-power-transfer', name: 'Wireless Power Transfer Design', branch_slug: 'power-electronics', level: 5, difficulty: 75, difficulty_tier: 'expert', estimated_hours: 28, description: 'Qi standard, coupling coefficient, FOD, coil design.' },
  { slug: 'llc-resonant-converter', name: 'LLC Resonant Converter', branch_slug: 'power-electronics', level: 3, difficulty: 78, difficulty_tier: 'expert', estimated_hours: 30, description: 'FHA, resonant tank, ZVS, frequency-controlled output.' },
  { slug: 'power-supply-emi-design', name: 'Switching Power Supply EMI Design', branch_slug: 'power-electronics', level: 5, difficulty: 78, difficulty_tier: 'expert', estimated_hours: 30, description: 'CM/DM noise, LISN, CISPR 32, X/Y caps, CM choke.' },
]

const MEDICAL_TOPICS_SEED = [
  { slug: 'iec60601-design', name: 'IEC 60601-1 Design Requirements', branch_slug: 'medical-wearables', level: 3, difficulty: 68, difficulty_tier: 'advanced', estimated_hours: 25, description: 'MOP, B/BF/CF applied parts, leakage current, isolation.' },
  { slug: 'ppg-spo2-design', name: 'PPG & SpO2 Hardware Design', branch_slug: 'medical-wearables', level: 3, difficulty: 62, difficulty_tier: 'advanced', estimated_hours: 22, description: 'Beer-Lambert, ambient light cancellation, TIA, MAX30102.' },
  { slug: 'blood-pressure-measurement', name: 'Oscillometric Blood Pressure', branch_slug: 'medical-wearables', level: 4, difficulty: 65, difficulty_tier: 'advanced', estimated_hours: 25, description: 'Oscillometric waveform, MAP, pressure sensor, cuff control.' },
  { slug: 'ecg-signal-chain-deep', name: 'ECG Signal Chain Deep Dive', branch_slug: 'medical-wearables', level: 4, difficulty: 75, difficulty_tier: 'expert', estimated_hours: 30, description: 'MAX30003, ADS1292R, Wilson CT, motion artifact.' },
  { slug: 'wearable-system-architecture', name: 'Wearable Medical Device Architecture', branch_slug: 'medical-wearables', level: 4, difficulty: 72, difficulty_tier: 'expert', estimated_hours: 30, description: 'System design: power, MCU, sensors, BLE, regulatory path.' },
  { slug: 'eu-mdr-compliance', name: 'EU MDR 2017/745 Technical Documentation', branch_slug: 'medical-wearables', level: 4, difficulty: 70, difficulty_tier: 'expert', estimated_hours: 30, description: 'Risk management, ISO 14971, technical file, UDI, ISO 13485.' },
  { slug: 'imu-sensor-design', name: 'IMU & Motion Sensor Integration', branch_slug: 'medical-wearables', level: 3, difficulty: 58, difficulty_tier: 'advanced', estimated_hours: 22, description: 'MEMS, Allan deviation, cross-axis, calibration.' },
  { slug: 'sensor-fusion-algorithms', name: 'Sensor Fusion Algorithms', branch_slug: 'medical-wearables', level: 4, difficulty: 72, difficulty_tier: 'expert', estimated_hours: 25, description: 'Madgwick, Mahony, EKF for AHRS, quaternion, drift.' },
  { slug: 'fuel-gauge-ic', name: 'Battery Fuel Gauge IC Integration', branch_slug: 'bms-energy-storage', level: 3, difficulty: 55, difficulty_tier: 'advanced', estimated_hours: 18, description: 'MAX17303, impedance track, ModelGauge, cell characterization.' },
  { slug: 'bms-hardware-design', name: 'BMS Hardware Design', branch_slug: 'bms-energy-storage', level: 4, difficulty: 72, difficulty_tier: 'expert', estimated_hours: 28, description: 'AD7280A, coulomb counter, balancing FET, BQ76952.' },
  { slug: 'eeg-hardware-design', name: 'EEG Hardware Design', branch_slug: 'medical-wearables', level: 5, difficulty: 78, difficulty_tier: 'expert', estimated_hours: 30, description: 'EEG frequency bands, active electrode, 24-bit ADC, notch.' },
]

const FPGA_TOPICS_SEED = [
  { slug: 'digital-logic-fundamentals', name: 'Digital Logic Fundamentals', branch_slug: 'fpga-digital-design', level: 1, difficulty: 20, difficulty_tier: 'foundational', estimated_hours: 12, description: 'Boolean algebra, K-maps, metastability, setup/hold time.' },
  { slug: 'vhdl-verilog-basics', name: 'VHDL & Verilog Fundamentals', branch_slug: 'fpga-digital-design', level: 1, difficulty: 28, difficulty_tier: 'foundational', estimated_hours: 20, description: 'RTL coding, synthesizable constructs, testbench.' },
  { slug: 'fpga-architecture', name: 'FPGA Architecture', branch_slug: 'fpga-digital-design', level: 2, difficulty: 38, difficulty_tier: 'intermediate', estimated_hours: 18, description: 'LUT, DSP48, BRAM, MMCM, I/O banks.' },
  { slug: 'fpga-timing-constraints', name: 'FPGA Timing Constraints & Closure', branch_slug: 'fpga-digital-design', level: 2, difficulty: 50, difficulty_tier: 'intermediate', estimated_hours: 20, description: 'SDC, create_clock, false_path, multicycle, WNS/TNS.' },
  { slug: 'clock-domain-crossing', name: 'Clock Domain Crossing (CDC)', branch_slug: 'fpga-digital-design', level: 3, difficulty: 60, difficulty_tier: 'advanced', estimated_hours: 22, description: 'Double FF sync, handshake, Gray-code FIFO, MTBF.' },
  { slug: 'fpga-ip-core-design', name: 'FPGA IP Core Design (AXI)', branch_slug: 'fpga-digital-design', level: 3, difficulty: 58, difficulty_tier: 'advanced', estimated_hours: 25, description: 'AXI4/Lite/Stream, burst, IP packager, parameterized RTL.' },
  { slug: 'fpga-dsp-design', name: 'DSP on FPGA (FIR, FFT)', branch_slug: 'fpga-digital-design', level: 3, difficulty: 65, difficulty_tier: 'advanced', estimated_hours: 28, description: 'Fixed-point, FIR structures, Cooley-Tukey FFT, CORDIC.' },
  { slug: 'hls-high-level-synthesis', name: 'High-Level Synthesis (Vitis HLS)', branch_slug: 'fpga-digital-design', level: 4, difficulty: 72, difficulty_tier: 'expert', estimated_hours: 28, description: 'C++ to RTL, pipeline pragmas, dataflow, co-simulation.' },
  { slug: 'fpga-verification-methodology', name: 'FPGA Verification (UVM/SVA)', branch_slug: 'fpga-digital-design', level: 4, difficulty: 80, difficulty_tier: 'expert', estimated_hours: 35, description: 'UVM, SystemVerilog assertions, functional coverage.' },
  { slug: 'zynq-soc-design', name: 'Zynq UltraScale+ MPSoC Design', branch_slug: 'fpga-digital-design', level: 4, difficulty: 80, difficulty_tier: 'expert', estimated_hours: 40, description: 'PS-PL AXI, Petalinux, OpenAMP, RPU/APU partition.' },
  { slug: 'asic-front-end-design', name: 'ASIC Front-End Design', branch_slug: 'fpga-digital-design', level: 5, difficulty: 85, difficulty_tier: 'elite', estimated_hours: 45, description: 'Synthesis, STA, clock tree, scan, formal equivalence.' },
  { slug: 'sky130-custom-ic', name: 'Custom IC with SkyWater 130nm PDK', branch_slug: 'fpga-digital-design', level: 7, difficulty: 94, difficulty_tier: 'legendary', estimated_hours: 80, description: 'Xschem, ngspice, Magic VLSI, DRC/LVS, OpenLane.' },
]

// ── Seed helper ───────────────────────────────────────────────

const DIFFICULTY_MAP = {
  foundational: 'foundational', intermediate: 'intermediate',
  advanced: 'advanced', expert: 'expert', elite: 'elite', legendary: 'legendary'
}

async function seed() {
  const client = await pool.connect()
  try {
    console.log('🌱 Seeding database...')

    // 1. Upsert branches
    console.log(`  → ${BRANCHES.length} branches...`)
    for (const b of BRANCHES) {
      await client.query(`
        INSERT INTO branches(slug,name,description,domain,icon,color,sort_order)
        VALUES($1,$2,$3,$4,$5,$6,$7)
        ON CONFLICT(slug) DO UPDATE SET name=$2,description=$3,domain=$4,icon=$5,color=$6,sort_order=$7
      `, [b.slug, b.name, b.description, b.domain, b.icon, b.color, b.sort])
    }

    // 2. Upsert all topics
    const ALL_TOPICS = [
      ...ANALOG_TOPICS, ...EMBEDDED_TOPICS, ...PCB_TOPICS,
      ...WIRELESS_TOPICS, ...POWER_TOPICS, ...MEDICAL_TOPICS_SEED, ...FPGA_TOPICS_SEED,
    ]
    console.log(`  → ${ALL_TOPICS.length} topics...`)

    for (const t of ALL_TOPICS) {
      const branchRow = await client.query(`SELECT id FROM branches WHERE slug=$1`, [t.branch_slug])
      if (!branchRow.rows[0]) { console.warn(`    ⚠ Branch not found: ${t.branch_slug}`); continue }
      const branchId = branchRow.rows[0].id

      await client.query(`
        INSERT INTO topics(slug,branch_id,name,description,level,difficulty,difficulty_tier,estimated_hours)
        VALUES($1,$2,$3,$4,$5,$6,$7::difficulty_tier,$8)
        ON CONFLICT(slug) DO UPDATE SET name=$3,description=$4,level=$5,difficulty=$6,difficulty_tier=$7::difficulty_tier,estimated_hours=$8
      `, [t.slug, branchId, t.name, t.description, t.level, t.difficulty,
          DIFFICULTY_MAP[t.difficulty_tier] ?? 'intermediate', t.estimated_hours ?? null])
    }

    // 3. Update branch topic counts
    await client.query(`
      UPDATE branches b SET topic_count = (SELECT COUNT(*) FROM topics t WHERE t.branch_id=b.id AND t.status='published')
    `)

    console.log('✓ Seed complete')
  } catch(e) {
    console.error('Seed failed:', e.message)
    throw e
  } finally {
    client.release()
    await pool.end()
  }
}

seed().catch(() => process.exit(1))
