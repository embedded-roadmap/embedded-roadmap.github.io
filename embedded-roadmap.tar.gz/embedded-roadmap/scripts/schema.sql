-- ============================================================
--  EmbeddedRoadmap — PostgreSQL Schema v1.0
--  Production-grade, fully normalized, indexed for performance
-- ============================================================

-- ── Extensions ──────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";      -- trigram search
CREATE EXTENSION IF NOT EXISTS "btree_gin";    -- multi-column GIN

-- ── Enums ───────────────────────────────────────────────────
CREATE TYPE user_role      AS ENUM ('user', 'admin', 'moderator');
CREATE TYPE topic_status   AS ENUM ('draft', 'published', 'archived', 'deprecated');
CREATE TYPE difficulty_tier AS ENUM ('foundational', 'intermediate', 'advanced', 'expert', 'elite', 'legendary');
CREATE TYPE rarity_tier    AS ENUM ('ubiquitous', 'common', 'uncommon', 'rare', 'elite', 'legendary');
CREATE TYPE node_type      AS ENUM ('concept', 'skill', 'project', 'certification', 'tool', 'standard', 'milestone');
CREATE TYPE dep_type       AS ENUM ('requires', 'recommends', 'enhances', 'conflicts');
CREATE TYPE badge_trigger  AS ENUM ('topic_count', 'xp_threshold', 'branch_complete', 'streak', 'rare_topic', 'level_up', 'manual');
CREATE TYPE progress_status AS ENUM ('not_started', 'in_progress', 'learned', 'reviewing');
CREATE TYPE rank_tier      AS ENUM ('intern', 'junior', 'mid', 'senior', 'lead', 'staff', 'distinguished');

-- ── Users ───────────────────────────────────────────────────
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username        VARCHAR(40)  UNIQUE NOT NULL,
  email           VARCHAR(255) UNIQUE NOT NULL,
  password_hash   VARCHAR(255),                    -- NULL for OAuth users
  display_name    VARCHAR(80),
  avatar_url      TEXT,
  bio             TEXT,
  location        VARCHAR(100),
  website_url     TEXT,
  linkedin_url    TEXT,
  github_url      TEXT,
  role            user_role    DEFAULT 'user',
  is_public       BOOLEAN      DEFAULT true,
  is_verified     BOOLEAN      DEFAULT false,
  is_banned       BOOLEAN      DEFAULT false,
  onboarding_done BOOLEAN      DEFAULT false,
  -- XP & ranking
  total_xp        INTEGER      DEFAULT 0,
  current_level   rank_tier    DEFAULT 'intern',
  current_streak  INTEGER      DEFAULT 0,
  longest_streak  INTEGER      DEFAULT 0,
  last_activity   TIMESTAMPTZ,
  -- statistics cache (updated by background job)
  global_percentile    NUMERIC(5,2) DEFAULT 0,
  topics_learned       INTEGER      DEFAULT 0,
  rare_topics_count    INTEGER      DEFAULT 0,
  specialization_score NUMERIC(6,2) DEFAULT 0,
  consistency_score    NUMERIC(6,2) DEFAULT 0,
  -- metadata
  created_at      TIMESTAMPTZ  DEFAULT NOW(),
  updated_at      TIMESTAMPTZ  DEFAULT NOW(),
  deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_users_username   ON users(username);
CREATE INDEX idx_users_email      ON users(email);
CREATE INDEX idx_users_total_xp   ON users(total_xp DESC);
CREATE INDEX idx_users_percentile ON users(global_percentile DESC);
CREATE INDEX idx_users_level      ON users(current_level);
CREATE INDEX idx_users_search     ON users USING GIN(to_tsvector('english', display_name || ' ' || COALESCE(bio,'') || ' ' || COALESCE(location,'')));

-- ── OAuth Accounts ──────────────────────────────────────────
CREATE TABLE oauth_accounts (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider      VARCHAR(30) NOT NULL,   -- 'github', 'google'
  provider_id   VARCHAR(255) NOT NULL,
  access_token  TEXT,
  refresh_token TEXT,
  expires_at    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(provider, provider_id)
);

-- ── Sessions ────────────────────────────────────────────────
CREATE TABLE sessions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash    VARCHAR(255) UNIQUE NOT NULL,
  user_agent    TEXT,
  ip_address    INET,
  expires_at    TIMESTAMPTZ NOT NULL,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_user    ON sessions(user_id);
CREATE INDEX idx_sessions_token   ON sessions(token_hash);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

-- ── Engineering Branches ────────────────────────────────────
CREATE TABLE branches (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug            VARCHAR(60)  UNIQUE NOT NULL,
  name            VARCHAR(120) NOT NULL,
  short_name      VARCHAR(40)  NOT NULL,
  description     TEXT,
  icon            VARCHAR(10),           -- emoji or icon key
  color_hex       VARCHAR(7),            -- #38bdf8
  parent_id       UUID REFERENCES branches(id),
  sort_order      INTEGER DEFAULT 0,
  is_active       BOOLEAN DEFAULT true,
  -- taxonomy
  domain          VARCHAR(60),           -- 'hardware', 'firmware', 'system', 'specialization'
  industry_tags   TEXT[],                -- ['automotive', 'medical', 'aerospace']
  -- stats cache
  total_topics    INTEGER DEFAULT 0,
  avg_difficulty  NUMERIC(4,2) DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_branches_slug   ON branches(slug);
CREATE INDEX idx_branches_parent ON branches(parent_id);
CREATE INDEX idx_branches_domain ON branches(domain);

-- ── Topics ──────────────────────────────────────────────────
CREATE TABLE topics (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  branch_id         UUID NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
  slug              VARCHAR(120) UNIQUE NOT NULL,
  name              VARCHAR(200) NOT NULL,
  short_name        VARCHAR(80),
  description       TEXT,
  detailed_content  TEXT,               -- markdown
  -- taxonomy
  node_type         node_type DEFAULT 'skill',
  status            topic_status DEFAULT 'published',
  -- level / progression
  min_level         rank_tier DEFAULT 'intern',
  max_level         rank_tier,          -- NULL = accessible forever
  sort_order        INTEGER DEFAULT 0,
  -- scoring (all 0-100)
  difficulty_score        SMALLINT DEFAULT 50  CHECK (difficulty_score BETWEEN 0 AND 100),
  math_complexity         SMALLINT DEFAULT 0   CHECK (math_complexity BETWEEN 0 AND 100),
  practical_complexity    SMALLINT DEFAULT 50  CHECK (practical_complexity BETWEEN 0 AND 100),
  industry_value          SMALLINT DEFAULT 50  CHECK (industry_value BETWEEN 0 AND 100),
  market_demand           SMALLINT DEFAULT 50  CHECK (market_demand BETWEEN 0 AND 100),
  -- derived / cached
  difficulty_tier   difficulty_tier GENERATED ALWAYS AS (
    CASE
      WHEN difficulty_score < 20 THEN 'foundational'::difficulty_tier
      WHEN difficulty_score < 40 THEN 'intermediate'::difficulty_tier
      WHEN difficulty_score < 60 THEN 'advanced'::difficulty_tier
      WHEN difficulty_score < 75 THEN 'expert'::difficulty_tier
      WHEN difficulty_score < 90 THEN 'elite'::difficulty_tier
      ELSE 'legendary'::difficulty_tier
    END
  ) STORED,
  xp_reward         INTEGER GENERATED ALWAYS AS (
    GREATEST(30, LEAST(800,
      difficulty_score * 4
      + math_complexity * 2
      + CASE WHEN industry_value > 80 THEN 60 ELSE 0 END
    ))
  ) STORED,
  -- rarity (updated by background job from user_progress stats)
  global_known_count     INTEGER DEFAULT 0,
  global_known_pct       NUMERIC(5,2) DEFAULT 100,
  rarity_tier            rarity_tier DEFAULT 'common',
  rarity_percentile      NUMERIC(5,2) DEFAULT 0,
  -- meta
  estimated_hours        NUMERIC(5,1),
  prerequisites_summary  TEXT,
  real_world_examples    TEXT[],
  project_suggestions    TEXT[],
  tools                  TEXT[],
  standards              TEXT[],
  interview_topics       TEXT[],
  -- salary data (JSON: {"global_pct": 12, "by_country": {...}})
  salary_impact_data     JSONB DEFAULT '{}',
  -- graph position (for React Flow)
  graph_x                NUMERIC(8,2),
  graph_y                NUMERIC(8,2),
  -- timestamps
  created_at             TIMESTAMPTZ DEFAULT NOW(),
  updated_at             TIMESTAMPTZ DEFAULT NOW(),
  created_by             UUID REFERENCES users(id),
  updated_by             UUID REFERENCES users(id)
);

CREATE INDEX idx_topics_branch    ON topics(branch_id);
CREATE INDEX idx_topics_slug      ON topics(slug);
CREATE INDEX idx_topics_level     ON topics(min_level);
CREATE INDEX idx_topics_diff      ON topics(difficulty_score DESC);
CREATE INDEX idx_topics_status    ON topics(status);
CREATE INDEX idx_topics_rarity    ON topics(rarity_tier, rarity_percentile DESC);
CREATE INDEX idx_topics_search    ON topics USING GIN(
  to_tsvector('english', name || ' ' || COALESCE(short_name,'') || ' ' || COALESCE(description,''))
);
CREATE INDEX idx_topics_tools_gin ON topics USING GIN(tools);

-- ── Topic Resources ─────────────────────────────────────────
CREATE TABLE topic_resources (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  topic_id    UUID NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  type        VARCHAR(30) NOT NULL,  -- 'book','course','tool','standard','paper','video','docs'
  title       VARCHAR(300) NOT NULL,
  author      VARCHAR(200),
  url         TEXT,
  is_free     BOOLEAN DEFAULT false,
  is_primary  BOOLEAN DEFAULT false,
  sort_order  INTEGER DEFAULT 0
);

CREATE INDEX idx_resources_topic ON topic_resources(topic_id);

-- ── Topic Dependencies ──────────────────────────────────────
CREATE TABLE topic_dependencies (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  topic_id        UUID NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  depends_on_id   UUID NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  dep_type        dep_type DEFAULT 'requires',
  strength        SMALLINT DEFAULT 100 CHECK (strength BETWEEN 1 AND 100), -- 100=hard prereq, 50=recommended
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(topic_id, depends_on_id)
);

CREATE INDEX idx_deps_topic      ON topic_dependencies(topic_id);
CREATE INDEX idx_deps_depends_on ON topic_dependencies(depends_on_id);

-- ── Cross-Branch Relationships ──────────────────────────────
CREATE TABLE topic_cross_links (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  topic_a_id  UUID NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  topic_b_id  UUID NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  link_type   VARCHAR(40) DEFAULT 'related',  -- 'related','extends','enables','same_concept'
  description TEXT,
  UNIQUE(topic_a_id, topic_b_id)
);

CREATE INDEX idx_xlinks_a ON topic_cross_links(topic_a_id);
CREATE INDEX idx_xlinks_b ON topic_cross_links(topic_b_id);

-- ── User Progress ───────────────────────────────────────────
CREATE TABLE user_progress (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  topic_id        UUID NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  branch_id       UUID NOT NULL REFERENCES branches(id),
  status          progress_status DEFAULT 'learned',
  xp_earned       INTEGER DEFAULT 0,
  -- learning metadata
  started_at      TIMESTAMPTZ,
  learned_at      TIMESTAMPTZ DEFAULT NOW(),
  reviewed_at     TIMESTAMPTZ,
  review_count    SMALLINT DEFAULT 0,
  confidence      SMALLINT DEFAULT 5 CHECK (confidence BETWEEN 1 AND 10),
  notes           TEXT,
  -- for statistics
  was_first_learn BOOLEAN DEFAULT true,  -- false if re-learned after reset
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, topic_id)
);

CREATE INDEX idx_progress_user     ON user_progress(user_id);
CREATE INDEX idx_progress_topic    ON user_progress(topic_id);
CREATE INDEX idx_progress_branch   ON user_progress(user_id, branch_id);
CREATE INDEX idx_progress_learned  ON user_progress(learned_at DESC);
CREATE INDEX idx_progress_status   ON user_progress(user_id, status);

-- ── XP Events ───────────────────────────────────────────────
CREATE TABLE xp_events (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_type  VARCHAR(60) NOT NULL,  -- 'topic_learned','badge_earned','streak_bonus','review_bonus'
  xp_delta    INTEGER NOT NULL,
  metadata    JSONB DEFAULT '{}',   -- { topic_id, badge_id, streak_days, ... }
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_xp_user    ON xp_events(user_id);
CREATE INDEX idx_xp_created ON xp_events(created_at DESC);
CREATE INDEX idx_xp_type    ON xp_events(event_type);

-- ── Badges (definitions) ────────────────────────────────────
CREATE TABLE badges (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug            VARCHAR(80) UNIQUE NOT NULL,
  name            VARCHAR(120) NOT NULL,
  description     TEXT,
  icon            VARCHAR(10),
  color_hex       VARCHAR(7),
  rarity          rarity_tier DEFAULT 'common',
  xp_bonus        INTEGER DEFAULT 0,
  -- trigger logic
  trigger_type    badge_trigger NOT NULL,
  trigger_config  JSONB NOT NULL DEFAULT '{}',
  -- e.g.: {"min_xp": 1000}
  --       {"topic_count": 10}
  --       {"branch_slug": "analog", "min_pct": 80}
  --       {"streak_days": 7}
  --       {"topic_slugs": ["hv-design-10kv"]}
  is_active       BOOLEAN DEFAULT true,
  is_hidden       BOOLEAN DEFAULT false,  -- surprise badges
  sort_order      INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_badges_slug    ON badges(slug);
CREATE INDEX idx_badges_trigger ON badges(trigger_type);

-- ── User Badges ─────────────────────────────────────────────
CREATE TABLE user_badges (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  badge_id    UUID NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
  earned_at   TIMESTAMPTZ DEFAULT NOW(),
  metadata    JSONB DEFAULT '{}',
  UNIQUE(user_id, badge_id)
);

CREATE INDEX idx_user_badges_user  ON user_badges(user_id);
CREATE INDEX idx_user_badges_badge ON user_badges(badge_id);
CREATE INDEX idx_user_badges_time  ON user_badges(earned_at DESC);

-- ── Monthly Rankings ────────────────────────────────────────
CREATE TABLE monthly_rankings (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  year                SMALLINT NOT NULL,
  month               SMALLINT NOT NULL,
  -- score components
  xp_this_month       INTEGER DEFAULT 0,
  topics_this_month   INTEGER DEFAULT 0,
  rare_topics_month   INTEGER DEFAULT 0,
  streak_days         INTEGER DEFAULT 0,
  badges_earned       INTEGER DEFAULT 0,
  -- computed score
  monthly_score       NUMERIC(10,2) DEFAULT 0,
  -- rank positions
  global_rank         INTEGER,
  percentile_rank     NUMERIC(5,2),
  -- snapshots
  total_xp_snapshot   INTEGER DEFAULT 0,
  level_snapshot      rank_tier DEFAULT 'intern',
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, year, month)
);

CREATE INDEX idx_rankings_period ON monthly_rankings(year DESC, month DESC, monthly_score DESC);
CREATE INDEX idx_rankings_user   ON monthly_rankings(user_id);
CREATE INDEX idx_rankings_rank   ON monthly_rankings(year, month, global_rank);

-- ── Engineer Profiles (extended public data) ────────────────
CREATE TABLE engineer_profiles (
  user_id              UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  headline             VARCHAR(200),
  years_experience     SMALLINT,
  current_company      VARCHAR(120),
  current_role         VARCHAR(120),
  expertise_areas      TEXT[],
  target_role          VARCHAR(120),
  -- salary data
  salary_currency      VARCHAR(3) DEFAULT 'USD',
  salary_range_min     INTEGER,
  salary_range_max     INTEGER,
  country_code         VARCHAR(2),
  -- social proof
  github_stats         JSONB DEFAULT '{}',
  -- radar chart cache
  skill_radar_cache    JSONB DEFAULT '{}',
  -- preferences
  preferred_branches   UUID[],
  learning_goals       TEXT[],
  notify_leaderboard   BOOLEAN DEFAULT true,
  notify_streak        BOOLEAN DEFAULT true,
  updated_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ── User Follows ────────────────────────────────────────────
CREATE TABLE user_follows (
  follower_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY(follower_id, following_id)
);

-- ── Roadmap Versions (for admin editing / history) ──────────
CREATE TABLE roadmap_versions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  branch_id     UUID NOT NULL REFERENCES branches(id),
  version       VARCHAR(20) NOT NULL,
  snapshot_json JSONB NOT NULL,  -- full branch+topics snapshot
  change_notes  TEXT,
  created_by    UUID REFERENCES users(id),
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_roadmap_versions_branch ON roadmap_versions(branch_id, created_at DESC);

-- ── Search Index (materialized view) ───────────────────────
CREATE MATERIALIZED VIEW search_index AS
SELECT
  t.id,
  'topic'   AS entity_type,
  t.name,
  t.slug,
  t.description,
  b.slug    AS branch_slug,
  b.name    AS branch_name,
  t.difficulty_score,
  t.rarity_tier,
  t.min_level,
  to_tsvector('english',
    t.name || ' ' ||
    COALESCE(t.short_name,'') || ' ' ||
    COALESCE(t.description,'') || ' ' ||
    b.name
  ) AS search_vec
FROM topics t
JOIN branches b ON t.branch_id = b.id
WHERE t.status = 'published'
UNION ALL
SELECT
  b.id,
  'branch' AS entity_type,
  b.name,
  b.slug,
  b.description,
  b.slug,
  b.name,
  b.avg_difficulty::smallint,
  'common'::rarity_tier,
  'intern'::rank_tier,
  to_tsvector('english', b.name || ' ' || COALESCE(b.description,''))
FROM branches b
WHERE b.is_active = true;

CREATE INDEX idx_search_vec  ON search_index USING GIN(search_vec);
CREATE INDEX idx_search_type ON search_index(entity_type);

-- ── Functions ───────────────────────────────────────────────

-- Calculate rank tier from XP
CREATE OR REPLACE FUNCTION xp_to_rank(xp INTEGER)
RETURNS rank_tier AS $$
BEGIN
  RETURN CASE
    WHEN xp < 500    THEN 'intern'::rank_tier
    WHEN xp < 1500   THEN 'junior'::rank_tier
    WHEN xp < 3000   THEN 'mid'::rank_tier
    WHEN xp < 5500   THEN 'senior'::rank_tier
    WHEN xp < 8000   THEN 'lead'::rank_tier
    WHEN xp < 12000  THEN 'staff'::rank_tier
    ELSE 'distinguished'::rank_tier
  END;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Recalculate user stats (called after any progress change)
CREATE OR REPLACE FUNCTION recalculate_user_stats(p_user_id UUID)
RETURNS VOID AS $$
DECLARE
  v_total_xp          INTEGER;
  v_topics_learned    INTEGER;
  v_rare_count        INTEGER;
  v_total_users       INTEGER;
  v_users_above       INTEGER;
  v_percentile        NUMERIC(5,2);
BEGIN
  -- Sum XP from all earned topics
  SELECT COALESCE(SUM(xp_earned), 0) INTO v_total_xp
  FROM user_progress WHERE user_id = p_user_id AND status = 'learned';

  -- Count learned topics
  SELECT COUNT(*) INTO v_topics_learned
  FROM user_progress WHERE user_id = p_user_id AND status = 'learned';

  -- Count rare+ topics
  SELECT COUNT(*) INTO v_rare_count
  FROM user_progress up
  JOIN topics t ON t.id = up.topic_id
  WHERE up.user_id = p_user_id
    AND up.status = 'learned'
    AND t.rarity_tier IN ('rare','elite','legendary');

  -- Compute global percentile
  SELECT COUNT(*) INTO v_total_users FROM users WHERE deleted_at IS NULL AND is_banned = false;
  SELECT COUNT(*) INTO v_users_above FROM users WHERE total_xp > v_total_xp AND deleted_at IS NULL;

  IF v_total_users > 0 THEN
    v_percentile := ROUND((1.0 - v_users_above::NUMERIC / v_total_users) * 100, 2);
  ELSE
    v_percentile := 0;
  END IF;

  UPDATE users SET
    total_xp             = v_total_xp,
    current_level        = xp_to_rank(v_total_xp),
    topics_learned       = v_topics_learned,
    rare_topics_count    = v_rare_count,
    global_percentile    = v_percentile,
    last_activity        = NOW(),
    updated_at           = NOW()
  WHERE id = p_user_id;
END;
$$ LANGUAGE plpgsql;

-- Update topic rarity (run nightly via cron)
CREATE OR REPLACE FUNCTION refresh_topic_rarity()
RETURNS VOID AS $$
DECLARE
  v_total_users INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_total_users FROM users WHERE deleted_at IS NULL;
  IF v_total_users = 0 THEN RETURN; END IF;

  UPDATE topics t SET
    global_known_count = sub.cnt,
    global_known_pct   = ROUND(sub.cnt::NUMERIC / v_total_users * 100, 2),
    rarity_tier = CASE
      WHEN sub.cnt::NUMERIC / v_total_users > 0.60 THEN 'ubiquitous'::rarity_tier
      WHEN sub.cnt::NUMERIC / v_total_users > 0.35 THEN 'common'::rarity_tier
      WHEN sub.cnt::NUMERIC / v_total_users > 0.15 THEN 'uncommon'::rarity_tier
      WHEN sub.cnt::NUMERIC / v_total_users > 0.05 THEN 'rare'::rarity_tier
      WHEN sub.cnt::NUMERIC / v_total_users > 0.01 THEN 'elite'::rarity_tier
      ELSE 'legendary'::rarity_tier
    END,
    rarity_percentile = ROUND((1.0 - sub.cnt::NUMERIC / v_total_users) * 100, 2)
  FROM (
    SELECT topic_id, COUNT(DISTINCT user_id) AS cnt
    FROM user_progress WHERE status = 'learned'
    GROUP BY topic_id
  ) sub
  WHERE t.id = sub.topic_id;
END;
$$ LANGUAGE plpgsql;

-- Monthly score calculation
CREATE OR REPLACE FUNCTION calculate_monthly_score(
  p_xp_month   INTEGER,
  p_topics     INTEGER,
  p_rare       INTEGER,
  p_streak     INTEGER,
  p_badges     INTEGER
) RETURNS NUMERIC AS $$
BEGIN
  RETURN (
    p_xp_month * 1.0
    + p_topics  * 50.0
    + p_rare    * 200.0
    + p_streak  * 10.0
    + p_badges  * 150.0
  );
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to all timestamped tables
DO $$
DECLARE
  t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['users','branches','topics','user_progress','monthly_rankings','engineer_profiles']
  LOOP
    EXECUTE format('
      CREATE TRIGGER set_updated_at
      BEFORE UPDATE ON %I
      FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at()', t);
  END LOOP;
END $$;

-- ── Views ───────────────────────────────────────────────────

-- Public user card (no sensitive fields)
CREATE VIEW v_user_public AS
SELECT
  u.id, u.username, u.display_name, u.avatar_url, u.bio,
  u.location, u.website_url, u.github_url,
  u.total_xp, u.current_level, u.global_percentile,
  u.topics_learned, u.rare_topics_count,
  u.current_streak, u.longest_streak, u.last_activity,
  u.is_public, u.created_at,
  ep.headline, ep.years_experience, ep.current_company,
  ep.current_role, ep.expertise_areas, ep.country_code
FROM users u
LEFT JOIN engineer_profiles ep ON ep.user_id = u.id
WHERE u.deleted_at IS NULL AND u.is_banned = false;

-- Branch progress per user
CREATE VIEW v_branch_progress AS
SELECT
  up.user_id,
  up.branch_id,
  b.name     AS branch_name,
  b.slug     AS branch_slug,
  COUNT(*)                                            AS topics_learned,
  b.total_topics,
  ROUND(COUNT(*)::NUMERIC / NULLIF(b.total_topics,0) * 100, 1) AS pct_complete,
  COALESCE(SUM(up.xp_earned),0)                       AS xp_in_branch,
  MAX(up.learned_at)                                  AS last_learned
FROM user_progress up
JOIN branches b ON b.id = up.branch_id
WHERE up.status = 'learned'
GROUP BY up.user_id, up.branch_id, b.name, b.slug, b.total_topics;

-- Leaderboard this month
CREATE VIEW v_leaderboard_current_month AS
SELECT
  mr.*,
  u.username, u.display_name, u.avatar_url,
  u.current_level, u.total_xp,
  ep.current_role, ep.country_code, ep.expertise_areas
FROM monthly_rankings mr
JOIN users u ON u.id = mr.user_id
LEFT JOIN engineer_profiles ep ON ep.user_id = mr.user_id
WHERE mr.year = EXTRACT(YEAR FROM NOW())
  AND mr.month = EXTRACT(MONTH FROM NOW())
  AND u.deleted_at IS NULL AND u.is_banned = false
ORDER BY mr.monthly_score DESC;
