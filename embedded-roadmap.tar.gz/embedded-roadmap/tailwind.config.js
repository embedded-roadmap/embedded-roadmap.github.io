const { fontFamily } = require('tailwindcss/defaultTheme')

/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: ['./src/**/*.{ts,tsx,js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans:    ['DM Sans', ...fontFamily.sans],
        mono:    ['Space Mono', 'Consolas', ...fontFamily.mono],
        display: ['Syne', 'DM Sans', ...fontFamily.sans],
      },
      colors: {
        'surface-0': 'rgb(var(--surface-0) / <alpha-value>)',
        'surface-1': 'rgb(var(--surface-1) / <alpha-value>)',
        'surface-2': 'rgb(var(--surface-2) / <alpha-value>)',
        'surface-3': 'rgb(var(--surface-3) / <alpha-value>)',
        'surface-4': 'rgb(var(--surface-4) / <alpha-value>)',
        'brand-cyan':    '#38bdf8',
        'brand-indigo':  '#818cf8',
        'brand-emerald': '#34d399',
        'brand-amber':   '#fbbf24',
        'brand-rose':    '#fb7185',
        'border':        'rgba(99,179,237,0.12)',
        'border-strong': 'rgba(99,179,237,0.25)',
      },
      boxShadow: {
        'card':        '0 1px 3px rgba(0,0,0,0.4), 0 1px 2px rgba(0,0,0,0.3)',
        'card-hover':  '0 4px 16px rgba(0,0,0,0.5), 0 0 0 1px rgba(99,179,237,0.15)',
        'glow-cyan':   '0 0 20px rgba(56,189,248,0.2), 0 0 40px rgba(56,189,248,0.08)',
        'glow-indigo': '0 0 20px rgba(129,140,248,0.2)',
      },
      backgroundImage: {
        'grid-pattern': 'linear-gradient(rgba(56,189,248,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(56,189,248,0.03) 1px, transparent 1px)',
        'radial-glow':  'radial-gradient(ellipse at top, rgba(56,189,248,0.08) 0%, transparent 60%)',
      },
      animation: {
        'fade-up':    'fadeUp 0.3s ease forwards',
        'glow-pulse': 'glowPulse 3s ease-in-out infinite',
      },
      keyframes: {
        fadeUp:    { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        glowPulse: { '0%, 100%': { opacity: '0.6' }, '50%': { opacity: '1' } },
      },
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
    require('@tailwindcss/forms'),
  ],
}
