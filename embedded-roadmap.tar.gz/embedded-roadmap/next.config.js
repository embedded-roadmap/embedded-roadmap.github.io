/** @type {import('next').NextConfig} */
const nextConfig = {
  output:'standalone',
  experimental:{serverComponentsExternalPackages:['pg','bcryptjs']},
  images:{remotePatterns:[{protocol:'https',hostname:'**.githubusercontent.com'},{protocol:'https',hostname:'**.googleusercontent.com'},{protocol:'https',hostname:'lh3.googleusercontent.com'},{protocol:'https',hostname:'media.licdn.com'}],formats:['image/avif','image/webp']},
  async headers(){return[{source:'/(.*)',headers:[{key:'X-Frame-Options',value:'SAMEORIGIN'},{key:'X-Content-Type-Options',value:'nosniff'},{key:'Referrer-Policy',value:'strict-origin-when-cross-origin'}]}]},
  webpack:(config)=>{config.externals=[...(config.externals??[]),'pg-native'];return config},
}
module.exports=nextConfig
