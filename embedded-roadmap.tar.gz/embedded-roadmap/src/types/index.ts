// src/types/index.ts — Complete canonical TypeScript domain model

export type UserRole       = 'user'|'admin'|'moderator'
export type TopicStatus    = 'draft'|'published'|'archived'|'deprecated'
export type DifficultyTier = 'foundational'|'intermediate'|'advanced'|'expert'|'elite'|'legendary'
export type RarityTier     = 'ubiquitous'|'common'|'uncommon'|'rare'|'elite'|'legendary'
export type NodeType       = 'concept'|'skill'|'project'|'certification'|'tool'|'standard'|'milestone'
export type DepType        = 'requires'|'recommends'|'enhances'|'conflicts'
export type BadgeTrigger   = 'topic_count'|'xp_threshold'|'branch_complete'|'streak'|'rare_topic'|'level_up'|'manual'
export type ProgressStatus = 'not_started'|'learning'|'learned'|'reviewing'|'skipped'
export type RankTier       = 'intern'|'junior'|'mid'|'senior'|'lead'|'staff'|'distinguished'
export type BranchDomain   = 'hardware'|'firmware'|'system'|'specialization'|'industry'
export type OpenToWorkStatus = 'not_looking'|'open_to_work'|'hiring'|'freelance'
export type CvTemplateId   = 'precision'|'vector'|'circuit'|'minimal'

export const RANK_XP_THRESHOLDS: Record<RankTier,number> = {
  intern:0,junior:500,mid:1500,senior:3000,lead:5500,staff:8000,distinguished:12000
}
export const RANK_LABELS: Record<RankTier,string> = {
  intern:'Intern Engineer',junior:'Junior Engineer',mid:'Mid-Level Engineer',
  senior:'Senior Engineer',lead:'Lead Engineer',staff:'Staff Engineer',distinguished:'Distinguished Engineer'
}
export const RARITY_LABELS: Record<RarityTier,string> = {
  ubiquitous:'Ubiquitous',common:'Common',uncommon:'Uncommon',rare:'Rare',elite:'Elite',legendary:'Legendary'
}
export function xpToRank(xp:number):RankTier{
  if(xp>=12000)return'distinguished';if(xp>=8000)return'staff';if(xp>=5500)return'lead'
  if(xp>=3000)return'senior';if(xp>=1500)return'mid';if(xp>=500)return'junior';return'intern'
}
export function xpToNextRank(xp:number):{nextRank:RankTier|null;xpNeeded:number;xpProgress:number;pct:number}{
  const entries=Object.entries(RANK_XP_THRESHOLDS)as[RankTier,number][]
  const next=entries.find(([,v])=>v>xp)
  if(!next)return{nextRank:null,xpNeeded:0,xpProgress:0,pct:100}
  const cur=xpToRank(xp);const curThresh=RANK_XP_THRESHOLDS[cur]
  const range=next[1]-curThresh;const prog=xp-curThresh
  return{nextRank:next[0],xpNeeded:next[1]-xp,xpProgress:prog,pct:Math.min(100,(prog/range)*100)}
}

export interface User{id:string;username:string;email:string|null;displayName:string|null;avatarUrl:string|null;bio:string|null;location:string|null;websiteUrl:string|null;linkedinUrl:string|null;role:UserRole;isPublic:boolean;isBanned:boolean;emailVerifiedAt:string|null;onboardingDone:boolean;totalXp:number;currentLevel:RankTier;globalPercentile:number;topicsLearned:number;rareTopicsCount:number;badgesCount:number;currentStreak:number;longestStreak:number;lastStreakDate:string|null;monthlyScore:number;headline?:string|null;currentRole?:string|null;currentCompany?:string|null;targetRole?:string|null;yearsExperience?:number|null;expertiseAreas?:string[];countryCode?:string|null;lastSeenAt:string|null;deletedAt:string|null;createdAt:string;updatedAt:string}
export type PublicUser=Pick<User,'id'|'username'|'displayName'|'avatarUrl'|'bio'|'location'|'totalXp'|'currentLevel'|'globalPercentile'|'topicsLearned'|'rareTopicsCount'|'currentStreak'|'longestStreak'|'badgesCount'|'headline'|'currentRole'|'currentCompany'|'expertiseAreas'|'countryCode'>
export interface Branch{id:string;slug:string;name:string;description:string|null;domain:BranchDomain;icon:string|null;color:string|null;sortOrder:number;topicCount:number;isPublished:boolean;createdAt:string;updatedAt:string}
export interface TopicResource{id:string;topicId:string;title:string;url:string;type:string;isFree:boolean;quality:number}
export interface TopicDependency{topicId:string;prerequisiteId:string;depType:DepType}
export interface Topic{id:string;branchId:string;branchSlug?:string;branchName?:string;slug:string;name:string;description:string|null;longDescription:string|null;status:TopicStatus;nodeType:NodeType;difficultyTier:DifficultyTier;difficulty:number;level:number;xpBase:number;rarityTier:RarityTier;rarityPct:number;keyConcepts:string[];tools:string[];standards:string[];estimatedHours:number|null;salaryImpact:number;industryTags:string[];dependencies?:TopicDependency[];resources?:TopicResource[];createdAt:string;updatedAt:string}
export interface UserProgress{id:string;userId:string;topicId:string;topicName?:string;topicSlug?:string;branchSlug?:string;branchName?:string;rarityTier?:RarityTier;status:ProgressStatus;xpEarned:number;attempts:number;notes:string|null;markedAt:string;updatedAt:string}
export interface BranchProgress{userId:string;branchSlug:string;branchName:string;domain:BranchDomain;topicsTotal:number;topicsLearned:number;pctComplete:number}
export interface Badge{id:string;slug:string;name:string;description:string|null;icon:string;rarity:RarityTier;triggerType:BadgeTrigger;triggerValue:Record<string,unknown>;xpReward:number;isActive:boolean;sortOrder:number;createdAt:string}
export interface UserBadge{id:string;userId:string;badgeId:string;badge?:Badge;earnedAt:string}
export interface LeaderboardEntry{rank:number;userId:string;username:string;displayName:string|null;currentLevel:RankTier;totalXp:number;topicsLearned:number;rareTopicsCount:number;currentStreak:number;monthlyScore:number;isCurrentUser?:boolean}
export interface MonthlyRanking{userId:string;year:number;month:number;rank:number|null;monthlyScore:number;xpGained:number;topicsLearned:number;badgesEarned:number;rareTopics:number;streakDays:number}
export interface RadarDomain{domain:string;label:string;score:number;maxScore:number;topicsLearned:number;topicsTotal:number}
export interface SpecializationHeatmap{branchSlug:string;branchName:string;domain:BranchDomain;pctComplete:number;topicsLearned:number;topicsTotal:number;color:string}
export interface AnalyticsSummary{totalXp:number;currentLevel:RankTier;globalPercentile:number;topicsLearned:number;rareSkills:number;badgesEarned:number;currentStreak:number;longestStreak:number;monthlyScore:number;radarData:RadarDomain[];heatmap:SpecializationHeatmap[];xpHistory:{date:string;xp:number}[];recentActivity:UserProgress[]}
export interface CvEducation{id:string;institution:string;degree:string|null;field:string|null;startYear:number|null;endYear:number|null;gpa:string|null;honors:string|null;relevantCourses:string[];sortOrder:number}
export interface CvCertification{id:string;name:string;issuer:string|null;issuedDate:string|null;expiryDate:string|null;credentialId:string|null;url:string|null;sortOrder:number}
export interface CvExperience{id:string;company:string;title:string;location:string|null;startDate:string;endDate:string|null;isCurrent:boolean;description:string|null;highlights:string[];techStack:string[];domains:string[];sortOrder:number}
export interface CvProject{id:string;userId?:string;title:string;description:string|null;techStack:string[];hardwareStack:string[];firmwareStack:string[];relatedTopicSlugs:string[];repoUrl:string|null;projectUrl:string|null;platform:'github'|'gitlab'|'hackaday'|'personal'|'other';imageUrl:string|null;videoUrl:string|null;isFeatured:boolean;isPublic:boolean;startDate:string|null;endDate:string|null;createdAt?:string;updatedAt?:string}
export interface CvPublication{id:string;title:string;venue:string|null;year:number|null;url:string|null;doi:string|null;authors:string[];sortOrder:number}
export interface CvPatent{id:string;title:string;patentNumber:string|null;filingDate:string|null;grantDate:string|null;jurisdiction:string|null;url:string|null;inventors:string[];sortOrder:number}
export interface CvAward{id:string;title:string;issuer:string|null;year:number|null;description:string|null;sortOrder:number}
export interface CvReference{id:string;name:string;title:string|null;company:string|null;email:string|null;phone:string|null;relationship:string|null;isPublic:boolean;sortOrder:number}
export interface CvManualSkill{id:string;category:string;skills:string[];sortOrder:number}
export interface CvLanguage{id:string;name:string;level:'native'|'professional'|'conversational'|'basic';sortOrder:number}
export interface CvSocialLinks{linkedin:string|null;github:string|null;hackaday:string|null;gitlab:string|null;website:string|null;email:string|null}
export interface EngineerCv{id:string;userId:string;status:'draft'|'published';templateId:CvTemplateId;fullName:string|null;title:string|null;email:string|null;phone:string|null;location:string|null;summary:string|null;openToWork:OpenToWorkStatus;socialLinks:CvSocialLinks;education:CvEducation[];certifications:CvCertification[];experience:CvExperience[];projects:CvProject[];publications:CvPublication[];patents:CvPatent[];awards:CvAward[];references:CvReference[];manualSkills:CvManualSkill[];languages:CvLanguage[];shareToken:string|null;shareEnabled:boolean;lastGeneratedAt:string|null;createdAt:string;updatedAt:string}
export interface UserPrivacySettings{userId:string;isPublic:boolean;showPercentile:boolean;showXp:boolean;showSalaryEstimates:boolean;showStreak:boolean;showBadges:boolean;showProjects:boolean;allowRecruiterView:boolean;openToWork:OpenToWorkStatus;gdprDataExportRequested:boolean;gdprDeleteRequested:boolean;updatedAt:string}
export interface RecruiterProfile{user:PublicUser;cv:EngineerCv|null;privacy:Pick<UserPrivacySettings,'showPercentile'|'showXp'|'showStreak'|'showBadges'|'showProjects'>;topSkills:Array<{name:string;rarity:RarityTier;xpEarned:number;branchName:string}>;radarData:RadarDomain[];specializationHeatmap:SpecializationHeatmap[];openToWork:OpenToWorkStatus;projects:CvProject[];stats:{totalXp:number;globalPercentile:number;topicsLearned:number;rareSkills:number;badgesEarned:number;currentStreak:number;longestStreak:number}}
export interface DonationConfig{stripePublishableKey:string|null;buyMeCoffeeUrl:string|null;patreonUrl:string|null;githubSponsorsUrl:string|null;goal:{current:number;target:number;label:string}|null}
export interface OnboardingState{step:number;experience:'student'|'junior'|'mid'|'senior'|'lead'|null;goals:string[];interests:string[];selectedPaths:string[];completedAt:string|null}
export interface SearchResult{topicId:string;topicSlug:string;topicName:string;branchSlug:string;branchName:string;description:string|null;rarityTier:RarityTier;difficultyTier:DifficultyTier;rank:number}
export interface PaginatedResponse<T>{data:T[];total:number;page:number;pageSize:number;hasMore:boolean}
export interface RoadmapNodeData{topic:Topic;isLearned:boolean;isLearning:boolean;isLocked:boolean;xpEarned:number}
export interface ProgressStatusMap{[topicId:string]:{status:ProgressStatus;xpEarned:number}}
