// src/middleware.ts
// Route protection: dashboard requires auth, public routes are open

import { withAuth } from 'next-auth/middleware'
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export default withAuth(
  function middleware(req) {
    const { pathname } = req.nextUrl
    const token = req.nextauth?.token

    // Redirect logged-in users away from auth pages
    if (token && (pathname.startsWith('/login') || pathname.startsWith('/register'))) {
      return NextResponse.redirect(new URL('/dashboard', req.url))
    }

    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        const { pathname } = req.nextUrl
        // Protected routes require auth
        const protectedPrefixes = [
          '/dashboard', '/roadmap', '/cv', '/badges',
          '/leaderboard', '/projects', '/settings', '/admin',
        ]
        const isProtected = protectedPrefixes.some(p => pathname.startsWith(p))
        if (isProtected) return !!token
        return true
      },
    },
  }
)

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/roadmap/:path*',
    '/cv/:path*',
    '/badges/:path*',
    '/leaderboard/:path*',
    '/projects/:path*',
    '/settings/:path*',
    '/admin/:path*',
    '/login',
    '/register',
  ],
}
