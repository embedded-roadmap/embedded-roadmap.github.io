// src/hooks/index.ts — Custom hooks for EmbeddedRoadmap

import { useEffect, useCallback, useState, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useProgressStore } from '@/stores/progress'
import { useRoadmapStore } from '@/stores/roadmap'
import { useUserStore } from '@/stores/user'
import type { SearchResult } from '@/types'

// ── useProgress — sync progress on auth ──────────────────────

export function useProgress() {
  const { data: session } = useSession()
  const { progress, branchProgress, fetchProgress, markTopic, isLearned, isLearning } = useProgressStore()

  useEffect(() => {
    if (session?.user?.id) fetchProgress()
  }, [session?.user?.id])

  return { progress, branchProgress, fetchProgress, markTopic, isLearned, isLearning }
}

// ── useUser — fetch and cache user profile ────────────────────

export function useUser() {
  const { data: session } = useSession()
  const { profile, loading, fetchProfile, updateProfile, clearProfile } = useUserStore()

  useEffect(() => {
    if (session?.user?.id) fetchProfile()
    if (!session) clearProfile()
  }, [session?.user?.id])

  return { user: profile, loading, updateProfile, refetch: fetchProfile }
}

// ── useRoadmap — load branch on mount ────────────────────────

export function useRoadmap(branchSlug?: string) {
  const store = useRoadmapStore()

  useEffect(() => {
    if (branchSlug && branchSlug !== store.activeBranchSlug) {
      store.loadBranch(branchSlug)
    }
  }, [branchSlug])

  useEffect(() => {
    if (store.branches.length === 0) store.fetchBranches()
  }, [])

  return store
}

// ── useDebounce ───────────────────────────────────────────────

export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState(value)
  useEffect(() => {
    const id = setTimeout(() => setDebouncedValue(value), delay)
    return () => clearTimeout(id)
  }, [value, delay])
  return debouncedValue
}

// ── useSearch — topic search with debounce ────────────────────

export function useSearch(q: string, limit = 10) {
  const debounced = useDebounce(q, 250)
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)
  const abortRef = useRef<AbortController | null>(null)

  useEffect(() => {
    if (debounced.trim().length < 2) { setResults([]); return }
    abortRef.current?.abort()
    abortRef.current = new AbortController()
    setLoading(true)

    fetch(`/api/search?q=${encodeURIComponent(debounced)}&limit=${limit}`, {
      signal: abortRef.current.signal,
    })
      .then(r => r.json())
      .then(({ data }) => { if (data?.results) setResults(data.results) })
      .catch(e => { if (e.name !== 'AbortError') console.error(e) })
      .finally(() => setLoading(false))

    return () => abortRef.current?.abort()
  }, [debounced, limit])

  return { results, loading }
}

// ── useXp — XP animation ─────────────────────────────────────

export function useXp(targetXp: number) {
  const [displayXp, setDisplayXp] = useState(0)
  const prevRef = useRef(0)

  useEffect(() => {
    const start = prevRef.current
    const end = targetXp
    if (start === end) return
    const duration = 800
    const startTime = Date.now()

    const tick = () => {
      const elapsed = Date.now() - startTime
      const progress = Math.min(elapsed / duration, 1)
      // easeOut
      const eased = 1 - Math.pow(1 - progress, 3)
      setDisplayXp(Math.round(start + (end - start) * eased))
      if (progress < 1) requestAnimationFrame(tick)
      else prevRef.current = end
    }
    requestAnimationFrame(tick)
  }, [targetXp])

  return displayXp
}

// ── useLocalStorage ───────────────────────────────────────────

export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === 'undefined') return initialValue
    try {
      const item = window.localStorage.getItem(key)
      return item ? JSON.parse(item) : initialValue
    } catch { return initialValue }
  })

  const setValue = useCallback((value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value
      setStoredValue(valueToStore)
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, JSON.stringify(valueToStore))
      }
    } catch (e) { console.error(e) }
  }, [key, storedValue])

  return [storedValue, setValue] as const
}
