'use client'
// src/components/roadmap/RoadmapGraph.tsx
import ReactFlow, {
  Background, Controls, MiniMap, BackgroundVariant,
  NodeTypes, useNodesState, useEdgesState,
  type Node, type Edge,
} from 'reactflow'
import 'reactflow/dist/style.css'
import { useCallback, useEffect } from 'react'
import { TopicNode } from './TopicNode'
import { useRoadmapStore } from '@/stores/roadmap'
import { useProgressStore } from '@/stores/progress'

const NODE_TYPES: NodeTypes = { topicNode: TopicNode }

export function RoadmapGraph() {
  const { nodes: storeNodes, edges: storeEdges, loading, selectTopic } = useRoadmapStore()
  const { progress, isLearned, isLearning } = useProgressStore()

  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])

  // Sync store nodes with progress status
  useEffect(() => {
    const enriched = storeNodes.map(n => ({
      ...n,
      data: {
        ...n.data,
        isLearned: isLearned(n.id),
        isLearning: isLearning(n.id),
        xpEarned: progress.get(n.id)?.xpEarned ?? 0,
      },
    }))
    setNodes(enriched)
    setEdges(storeEdges)
  }, [storeNodes, storeEdges, progress])

  const onNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    selectTopic(node.id)
  }, [selectTopic])

  if (loading) return (
    <div className="flex-1 flex items-center justify-center">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-brand-cyan border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-slate-500">Loading roadmap…</p>
      </div>
    </div>
  )

  return (
    <div className="flex-1 relative">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={onNodeClick}
        nodeTypes={NODE_TYPES}
        fitView
        fitViewOptions={{ padding: 0.3, maxZoom: 1.2 }}
        minZoom={0.3}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
      >
        <Background
          variant={BackgroundVariant.Dots}
          gap={24}
          size={1}
          color="rgba(56,189,248,0.1)"
        />
        <Controls
          showInteractive={false}
          className="!bottom-6 !left-6"
        />
        <MiniMap
          nodeColor={(n) => {
            if (n.data?.isLearned)  return '#34d399'
            if (n.data?.isLearning) return '#fbbf24'
            return '#1a2234'
          }}
          maskColor="rgba(6,10,16,0.7)"
          className="!bottom-6 !right-6 !w-36 !h-24"
        />
      </ReactFlow>
    </div>
  )
}
