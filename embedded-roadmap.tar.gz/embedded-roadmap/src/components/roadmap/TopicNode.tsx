'use client'
// src/components/roadmap/TopicNode.tsx
import { memo } from 'react'
import { Handle, Position, type NodeProps } from 'reactflow'
import { Lock, CheckCircle, BookOpen, Zap } from 'lucide-react'
import type { Topic, RarityTier } from '@/types'

const RARITY_BORDER: Record<RarityTier, string> = {
  ubiquitous: 'border-slate-600',
  common:     'border-slate-500',
  uncommon:   'border-emerald-500/60',
  rare:       'border-cyan-400/70',
  elite:      'border-indigo-400/80',
  legendary:  'border-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.3)]',
}

const RARITY_DOT: Record<RarityTier, string> = {
  ubiquitous: 'bg-slate-600',
  common:     'bg-slate-500',
  uncommon:   'bg-emerald-500',
  rare:       'bg-cyan-400',
  elite:      'bg-indigo-400',
  legendary:  'bg-amber-400',
}

const DIFF_LABEL = ['', 'Intro', 'Basic', 'Intermediate', 'Advanced', 'Expert', 'Master', 'Elite']

type TopicNodeData = {
  topic: Topic
  isLearned: boolean
  isLearning: boolean
  isLocked: boolean
  xpEarned: number
}

function TopicNodeInner({ data, selected }: NodeProps<TopicNodeData>) {
  const { topic, isLearned, isLearning, isLocked, xpEarned } = data

  const rarity = topic.rarityTier ?? 'common'
  const borderClass = RARITY_BORDER[rarity]
  const dotClass = RARITY_DOT[rarity]

  let stateClass = 'bg-surface-2 hover:bg-surface-3'
  if (isLearned)  stateClass = 'bg-emerald-500/10 border-emerald-500/60'
  if (isLearning) stateClass = 'bg-amber-500/10 border-amber-500/60'
  if (isLocked)   stateClass = 'bg-surface-1 opacity-50'
  if (selected)   stateClass += ' ring-1 ring-brand-cyan ring-offset-1 ring-offset-surface-0'

  return (
    <>
      <Handle type="target" position={Position.Left}
        className="!w-2 !h-2 !bg-surface-4 !border-border-strong" />

      <div className={`relative rounded-lg border transition-all duration-150 ${borderClass} ${stateClass} cursor-pointer select-none px-3 py-2.5 min-w-[180px] max-w-[220px]`}>
        {/* Header row */}
        <div className="flex items-center gap-2">
          {/* State icon */}
          <div className="shrink-0">
            {isLearned  && <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />}
            {isLearning && <BookOpen    className="w-3.5 h-3.5 text-amber-400" />}
            {isLocked   && <Lock        className="w-3.5 h-3.5 text-slate-600" />}
            {!isLearned && !isLearning && !isLocked && (
              <div className={`w-2 h-2 rounded-full ${dotClass} shrink-0 mt-0.5`} />
            )}
          </div>

          {/* Topic name */}
          <span className="text-xs font-medium text-slate-200 leading-tight">{topic.name}</span>
        </div>

        {/* Meta row */}
        <div className="flex items-center justify-between mt-1.5 gap-2">
          <span className="text-[10px] text-slate-600 truncate">
            {topic.difficultyTier ? DIFF_LABEL[topic.difficultyTier] ?? '' : ''}
          </span>
          {isLearned && xpEarned > 0 && (
            <span className="flex items-center gap-0.5 text-[10px] text-brand-cyan whitespace-nowrap">
              <Zap className="w-2.5 h-2.5" />+{xpEarned}
            </span>
          )}
          {!isLearned && topic.xpBase && (
            <span className="flex items-center gap-0.5 text-[10px] text-slate-600 whitespace-nowrap">
              <Zap className="w-2.5 h-2.5" />{topic.xpBase}
            </span>
          )}
        </div>

        {/* Legendary shimmer */}
        {rarity === 'legendary' && (
          <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-transparent via-amber-400/5 to-transparent pointer-events-none" />
        )}
      </div>

      <Handle type="source" position={Position.Right}
        className="!w-2 !h-2 !bg-surface-4 !border-border-strong" />
    </>
  )
}

export const TopicNode = memo(TopicNodeInner)
