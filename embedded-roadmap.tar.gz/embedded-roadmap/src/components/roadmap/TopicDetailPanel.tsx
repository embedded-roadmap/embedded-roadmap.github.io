'use client'
// src/components/roadmap/TopicDetailPanel.tsx
import { useEffect, useState } from 'react'
import { X, CheckCircle, BookOpen, ExternalLink, Zap, Star, Lock, Play, SkipForward, RotateCcw } from 'lucide-react'
import type { Topic, RarityTier } from '@/types'
import { useProgressStore } from '@/stores/progress'
import { useRoadmapStore } from '@/stores/roadmap'
import { toast } from 'sonner'

const RARITY_STYLE: Record<RarityTier, { label: string; color: string; bg: string }> = {
  ubiquitous: { label: 'Ubiquitous', color: 'text-slate-400', bg: 'bg-slate-400/10' },
  common:     { label: 'Common',     color: 'text-slate-300', bg: 'bg-slate-300/10' },
  uncommon:   { label: 'Uncommon',   color: 'text-emerald-400', bg: 'bg-emerald-400/10' },
  rare:       { label: 'Rare',       color: 'text-cyan-400',    bg: 'bg-cyan-400/10' },
  elite:      { label: 'Elite',      color: 'text-indigo-400',  bg: 'bg-indigo-400/10' },
  legendary:  { label: 'Legendary',  color: 'text-amber-400',   bg: 'bg-amber-400/10' },
}

export function TopicDetailPanel() {
  const { getSelectedTopic, selectTopic } = useRoadmapStore()
  const { markTopic, isLearned, isLearning, progress } = useProgressStore()
  const [marking, setMarking] = useState(false)
  const [quiz, setQuiz] = useState<{ question: string; options: string[]; answer: number }[] | null>(null)
  const [loadingQuiz, setLoadingQuiz] = useState(false)

  const topic = getSelectedTopic()
  if (!topic) return null

  const learned  = isLearned(topic.id)
  const learning = isLearning(topic.id)
  const prog     = progress.get(topic.id)
  const rarity   = RARITY_STYLE[topic.rarityTier ?? 'common']

  const mark = async (status: 'learning' | 'learned' | 'skipped') => {
    setMarking(true)
    await markTopic(topic.id, status)
    const label = { learning: 'Marked as in progress', learned: `✓ Learned! +${topic.xpBase ?? 0} XP`, skipped: 'Skipped' }
    toast.success(label[status])
    setMarking(false)
  }

  const loadQuiz = async () => {
    setLoadingQuiz(true)
    try {
      const res = await fetch(`/api/ai/quiz?topicSlug=${topic.slug}`)
      const { data } = await res.json()
      if (data?.quiz) setQuiz(data.quiz)
    } catch { toast.error('Quiz unavailable') }
    finally { setLoadingQuiz(false) }
  }

  return (
    <div className="w-80 shrink-0 bg-[#0a1020] border-l border-[rgba(99,179,237,0.12)] overflow-y-auto flex flex-col">
      {/* Header */}
      <div className="flex items-start justify-between p-4 border-b border-[rgba(99,179,237,0.1)]">
        <div className="flex-1 min-w-0 pr-3">
          <h3 className="font-semibold text-slate-100 text-sm leading-tight">{topic.name}</h3>
          <div className="flex items-center gap-2 mt-1.5">
            <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium ${rarity.bg} ${rarity.color}`}>
              {rarity.label}
            </span>
            {topic.xpBase && (
              <span className="flex items-center gap-0.5 text-[10px] text-slate-500">
                <Zap className="w-3 h-3" />{topic.xpBase} base XP
              </span>
            )}
          </div>
        </div>
        <button onClick={() => selectTopic(null)}
          className="p-1 rounded text-slate-500 hover:text-slate-300 hover:bg-surface-3 transition-all shrink-0">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Status bar */}
      {(learned || learning) && (
        <div className={`px-4 py-2.5 text-xs font-medium flex items-center gap-2 ${learned ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
          {learned
            ? <><CheckCircle className="w-3.5 h-3.5" /> Learned{prog?.xpEarned ? ` · +${prog.xpEarned} XP earned` : ''}</>
            : <><BookOpen className="w-3.5 h-3.5" /> In Progress</>
          }
        </div>
      )}

      {/* Body */}
      <div className="flex-1 p-4 space-y-4 overflow-y-auto">
        {/* Description */}
        {topic.description && (
          <div>
            <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">Overview</h4>
            <p className="text-sm text-slate-400 leading-relaxed">{topic.description}</p>
          </div>
        )}

        {/* Key concepts */}
        {topic.keyConcepts && topic.keyConcepts.length > 0 && (
          <div>
            <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">Key Concepts</h4>
            <ul className="space-y-1">
              {topic.keyConcepts.map((c, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-slate-400">
                  <span className="text-brand-cyan mt-0.5">·</span>
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Resources */}
        {topic.resources && topic.resources.length > 0 && (
          <div>
            <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">Resources</h4>
            <div className="space-y-2">
              {topic.resources.slice(0, 5).map((r, i) => (
                <a key={i} href={(r as Record<string, unknown>).url as string} target="_blank" rel="noopener"
                  className="flex items-start gap-2 text-xs text-brand-cyan hover:text-cyan-300 transition-colors group">
                  <ExternalLink className="w-3 h-3 mt-0.5 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                  <span className="line-clamp-2">{(r as Record<string, unknown>).title as string}</span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Estimated time */}
        {topic.estimatedHours && (
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Star className="w-3.5 h-3.5" />
            Est. {topic.estimatedHours}h to learn
          </div>
        )}

        {/* AI Quiz button */}
        {learned && !quiz && (
          <button onClick={loadQuiz} disabled={loadingQuiz}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-brand-indigo/30 text-brand-indigo text-xs font-medium hover:bg-brand-indigo/10 transition-all disabled:opacity-60">
            <Star className="w-3.5 h-3.5" />
            {loadingQuiz ? 'Loading quiz…' : 'Test your knowledge'}
          </button>
        )}

        {/* Quiz */}
        {quiz && <QuizSection questions={quiz} />}
      </div>

      {/* Action buttons */}
      <div className="p-4 border-t border-[rgba(99,179,237,0.1)] space-y-2">
        {!learned && (
          <button onClick={() => mark('learned')} disabled={marking}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-brand-emerald text-[#060a10] text-sm font-semibold hover:bg-emerald-400 transition-colors disabled:opacity-60">
            <CheckCircle className="w-4 h-4" />
            {marking ? 'Saving…' : `Mark as Learned (+${topic.xpBase ?? 0} XP)`}
          </button>
        )}
        {learned && (
          <button onClick={() => mark('learning')} disabled={marking}
            className="w-full flex items-center justify-center gap-2 py-2 rounded-lg border border-amber-500/30 text-amber-400 text-xs font-medium hover:bg-amber-500/10 transition-all">
            <RotateCcw className="w-3.5 h-3.5" /> Mark as revisiting
          </button>
        )}
        {!learned && !learning && (
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => mark('learning')} disabled={marking}
              className="flex items-center justify-center gap-1.5 py-2 rounded-lg border border-amber-500/30 text-amber-400 text-xs font-medium hover:bg-amber-500/10 transition-all">
              <Play className="w-3 h-3" /> Start
            </button>
            <button onClick={() => mark('skipped')} disabled={marking}
              className="flex items-center justify-center gap-1.5 py-2 rounded-lg border border-slate-700 text-slate-500 text-xs hover:text-slate-400 transition-all">
              <SkipForward className="w-3 h-3" /> Skip
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

function QuizSection({ questions }: { questions: { question: string; options: string[]; answer: number }[] }) {
  const [current, setCurrent] = useState(0)
  const [selected, setSelected] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [done, setDone] = useState(false)

  const q = questions[current]

  const choose = (i: number) => {
    if (selected !== null) return
    setSelected(i)
    if (i === q.answer) setScore(s => s + 1)
    setTimeout(() => {
      if (current < questions.length - 1) {
        setCurrent(c => c + 1)
        setSelected(null)
      } else {
        setDone(true)
      }
    }, 1200)
  }

  if (done) return (
    <div className="text-center py-4">
      <div className="text-2xl font-bold text-brand-cyan">{score}/{questions.length}</div>
      <div className="text-sm text-slate-400 mt-1">
        {score === questions.length ? '🎯 Perfect score!' : score >= questions.length * 0.6 ? '✓ Good job!' : '📚 Keep studying'}
      </div>
    </div>
  )

  return (
    <div className="space-y-3">
      <div className="flex justify-between text-[11px] text-slate-600 mb-1">
        <span>Question {current + 1} of {questions.length}</span>
        <span>Score: {score}</span>
      </div>
      <p className="text-sm text-slate-200 leading-relaxed">{q.question}</p>
      <div className="space-y-1.5">
        {q.options.map((opt, i) => (
          <button key={i} onClick={() => choose(i)}
            className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-all ${
              selected === null ? 'border border-border hover:border-brand-cyan/40 hover:bg-surface-3 text-slate-300' :
              i === q.answer ? 'border border-brand-emerald/60 bg-brand-emerald/10 text-emerald-400' :
              selected === i  ? 'border border-red-500/50 bg-red-500/10 text-red-400' :
              'border border-border text-slate-500'
            }`}
          >
            <span className="font-mono text-[10px] mr-2">{String.fromCharCode(65 + i)}.</span>
            {opt}
          </button>
        ))}
      </div>
    </div>
  )
}
