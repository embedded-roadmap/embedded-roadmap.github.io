// src/lib/api.ts — Shared API utilities
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import type { ZodSchema } from 'zod'

export const ok = <T>(data: T, status = 200) =>
  NextResponse.json({ data, ok: true }, { status })
export const created = <T>(data: T) =>
  NextResponse.json({ data, ok: true }, { status: 201 })
export const err = (message: string, status = 400) =>
  NextResponse.json({ error: message, ok: false }, { status })
export const notFound = (entity = 'Resource') =>
  NextResponse.json({ error: `${entity} not found`, ok: false }, { status: 404 })
export const unauthorized = (msg = 'Unauthorized') =>
  NextResponse.json({ error: msg, ok: false }, { status: 401 })
export const forbidden = (msg = 'Forbidden') =>
  NextResponse.json({ error: msg, ok: false }, { status: 403 })
export const serverError = (e: unknown, msg = 'Internal server error') => {
  console.error('[API]', e)
  return NextResponse.json({ error: msg, ok: false }, { status: 500 })
}

export async function parseBody<T>(req: NextRequest, schema: ZodSchema<T>): Promise<{data:T}|{error:string}> {
  try {
    const json = await req.json()
    const r = schema.safeParse(json)
    if (!r.success) return { error: r.error.errors.map(e=>`${e.path.join('.')}: ${e.message}`).join(', ') }
    return { data: r.data }
  } catch { return { error: 'Invalid JSON' } }
}

export const parseQuery = (req: NextRequest, k: string, d: string) => req.nextUrl.searchParams.get(k) ?? d
export const parseQueryInt = (req: NextRequest, k: string, d: number) => { const v=req.nextUrl.searchParams.get(k); return v?isNaN(parseInt(v))?d:parseInt(v):d }

type AuthCtx = { session:{user:{id:string;username:string;email?:string|null;role:string;totalXp:number;currentLevel:string}}; params:Record<string,string> }
type RouteHandler = (req: NextRequest, ctx: AuthCtx) => Promise<NextResponse>

export function withAuth(handler: RouteHandler) {
  return async (req: NextRequest, ctx: {params?:Record<string,string>}={}) => {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return unauthorized()
    return handler(req, { session: session as AuthCtx['session'], params: ctx.params??{} })
  }
}

export function withAdmin(handler: RouteHandler) {
  return async (req: NextRequest, ctx: {params?:Record<string,string>}={}) => {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return unauthorized()
    if (session.user.role!=='admin') return forbidden()
    return handler(req, { session: session as AuthCtx['session'], params: ctx.params??{} })
  }
}

const _rlMap = new Map<string,{count:number;resetAt:number}>()
export function rateLimit(id: string, max: number, windowMs: number) {
  const now = Date.now(); const cur = _rlMap.get(id)
  if (!cur||cur.resetAt<=now) { _rlMap.set(id,{count:1,resetAt:now+windowMs}); return {ok:true,remaining:max-1} }
  if (cur.count>=max) return {ok:false,remaining:0}
  cur.count++; return {ok:true,remaining:max-cur.count}
}

export const paginationParams = (req: NextRequest) => {
  const page = parseQueryInt(req,'page',1); const limit = Math.min(parseQueryInt(req,'limit',20),100)
  return { page, limit, offset:(page-1)*limit }
}
