// src/lib/auth/index.ts — Full NextAuth configuration
import { type NextAuthOptions, type DefaultSession } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import GoogleProvider from 'next-auth/providers/google'
import GithubProvider from 'next-auth/providers/github'
import bcrypt from 'bcryptjs'
import { query, queryOne, execute } from '@/lib/db'

declare module 'next-auth' {
  interface Session {
    user: DefaultSession['user'] & {
      id: string; username: string; role: string
      totalXp: number; currentLevel: string; isNewUser?: boolean
    }
  }
  interface User {
    id: string; username: string; role: string
    totalXp: number; currentLevel: string; isNewUser?: boolean
  }
}
declare module 'next-auth/jwt' {
  interface JWT {
    id: string; username: string; role: string
    totalXp: number; currentLevel: string; isNewUser?: boolean
  }
}

export function validateUsername(u: string): string | null {
  if (u.length < 3) return 'Min 3 chars'
  if (u.length > 30) return 'Max 30 chars'
  if (!/^[a-z0-9_-]+$/.test(u)) return 'Lowercase, numbers, _ and - only'
  return null
}
export function validatePassword(p: string): string | null {
  if (p.length < 8) return 'Min 8 chars'
  return null
}

async function upsertOAuthUser(provider: string, providerAccountId: string, email: string|null, name: string|null, image: string|null) {
  const existing = await queryOne<Record<string,unknown>>(
    `SELECT u.* FROM users u JOIN oauth_accounts oa ON oa.user_id=u.id WHERE oa.provider=$1 AND oa.provider_account_id=$2`,
    [provider, providerAccountId])
  if (existing) return existing
  let user: Record<string,unknown>|null = email
    ? await queryOne<Record<string,unknown>>(`SELECT * FROM users WHERE email=$1 AND deleted_at IS NULL`,[email])
    : null
  if (!user) {
    const base = (email?.split('@')[0]??name??'engineer').toLowerCase().replace(/[^a-z0-9_]/g,'_').slice(0,20)
    let username = base; let suffix = 1
    while (await queryOne(`SELECT id FROM users WHERE username=$1`,[username])) username=`${base}${suffix++}`
    const rows = await query<Record<string,unknown>>(
      `INSERT INTO users(username,email,display_name,avatar_url,password_hash,email_verified_at)VALUES($1,$2,$3,$4,'',NOW())RETURNING *`,
      [username,email,name,image])
    user = rows[0]
  }
  await execute(`INSERT INTO oauth_accounts(user_id,provider,provider_account_id)VALUES($1,$2,$3)ON CONFLICT DO NOTHING`,
    [(user as Record<string,unknown>).id,provider,providerAccountId])
  return user as Record<string,unknown>
}

export const authOptions: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: 'jwt', maxAge: 30*24*60*60 },
  pages: { signIn: '/login', error: '/login', newUser: '/onboarding' },
  providers: [
    CredentialsProvider({
      id: 'credentials', name: 'Email',
      credentials: { email:{label:'Email',type:'email'}, password:{label:'Password',type:'password'} },
      async authorize(creds) {
        if (!creds?.email||!creds?.password) return null
        const user = await queryOne<Record<string,unknown>>(
          `SELECT * FROM users WHERE (email=$1 OR username=$1) AND deleted_at IS NULL AND is_banned=false`,
          [creds.email.toLowerCase()])
        if (!user) return null
        const valid = await bcrypt.compare(creds.password, user.password_hash as string)
        if (!valid) return null
        await execute(`UPDATE users SET last_seen_at=NOW() WHERE id=$1`,[user.id])
        return { id:user.id as string, email:user.email as string, name:(user.display_name??user.username) as string,
          username:user.username as string, role:user.role as string??'user',
          totalXp:Number(user.total_xp??0), currentLevel:user.current_level as string??'intern' }
      },
    }),
    ...(process.env.GOOGLE_CLIENT_ID?[GoogleProvider({clientId:process.env.GOOGLE_CLIENT_ID,clientSecret:process.env.GOOGLE_CLIENT_SECRET!})]:[]),
    ...(process.env.GITHUB_CLIENT_ID?[GithubProvider({clientId:process.env.GITHUB_CLIENT_ID,clientSecret:process.env.GITHUB_CLIENT_SECRET!})]:[]),
    ...(process.env.LINKEDIN_CLIENT_ID?[{id:'linkedin',name:'LinkedIn',type:'oauth' as const,
      clientId:process.env.LINKEDIN_CLIENT_ID,clientSecret:process.env.LINKEDIN_CLIENT_SECRET,
      authorization:{url:'https://www.linkedin.com/oauth/v2/authorization',params:{scope:'openid profile email'}},
      token:'https://www.linkedin.com/oauth/v2/accessToken',userinfo:'https://api.linkedin.com/v2/userinfo',
      profile(p:Record<string,unknown>){return{id:p.sub as string,name:`${p.given_name} ${p.family_name}`.trim(),email:p.email as string,image:p.picture as string}}}]:[]),
    ...(process.env.FACEBOOK_CLIENT_ID?[{id:'facebook',name:'Facebook',type:'oauth' as const,
      clientId:process.env.FACEBOOK_CLIENT_ID,clientSecret:process.env.FACEBOOK_CLIENT_SECRET,
      authorization:{url:'https://www.facebook.com/v18.0/dialog/oauth',params:{scope:'email public_profile'}},
      token:'https://graph.facebook.com/oauth/access_token',
      userinfo:{url:'https://graph.facebook.com/me',params:{fields:'id,name,email,picture'}},
      profile(p:Record<string,unknown>){return{id:p.id as string,name:p.name as string,email:p.email as string,image:((p.picture as Record<string,unknown>)?.data as Record<string,unknown>)?.url as string}}}]:[]),
  ],
  callbacks: {
    async signIn({user,account}) {
      if (account?.provider!=='credentials') {
        try {
          const dbUser = await upsertOAuthUser(account!.provider,account!.providerAccountId,user.email??null,user.name??null,user.image??null)
          user.id=dbUser.id as string; user.username=dbUser.username as string
          user.role=dbUser.role as string??'user'; user.totalXp=Number(dbUser.total_xp??0)
          user.currentLevel=dbUser.current_level as string??'intern'
          user.isNewUser = !dbUser.email_verified_at
        } catch(e){ console.error('OAuth error:',e); return false }
      }
      return true
    },
    async jwt({token,user,trigger,session}) {
      if (user) { token.id=user.id; token.username=user.username; token.role=user.role; token.totalXp=user.totalXp; token.currentLevel=user.currentLevel; token.isNewUser=user.isNewUser }
      if (trigger==='update'&&session?.refreshStats) {
        const d = await queryOne<Record<string,unknown>>(`SELECT total_xp,current_level FROM users WHERE id=$1`,[token.id])
        if (d) { token.totalXp=Number(d.total_xp); token.currentLevel=d.current_level as string }
      }
      return token
    },
    async session({session,token}) {
      session.user.id=token.id; session.user.username=token.username; session.user.role=token.role
      session.user.totalXp=token.totalXp; session.user.currentLevel=token.currentLevel; session.user.isNewUser=token.isNewUser
      return session
    },
  },
  events: {
    async signIn({user}) {
      await execute(`INSERT INTO user_privacy_settings(user_id)VALUES($1)ON CONFLICT DO NOTHING`,[user.id]).catch(()=>{})
      await execute(`INSERT INTO engineer_cvs(user_id)VALUES($1)ON CONFLICT DO NOTHING`,[user.id]).catch(()=>{})
    },
  },
}
