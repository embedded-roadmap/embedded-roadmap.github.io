// src/lib/auth/providers.ts
// OAuth provider configurations — all 4 providers: Google, GitHub, LinkedIn, Facebook

import GoogleProvider from 'next-auth/providers/google'
import GithubProvider from 'next-auth/providers/github'
import type { OAuthConfig, OAuthUserConfig } from 'next-auth/providers'

// ── LinkedIn Provider (manual, since next-auth v4 uses OAuth2) ──
export function LinkedInProvider(options: OAuthUserConfig<Record<string, unknown>>): OAuthConfig<Record<string, unknown>> {
  return {
    id: 'linkedin',
    name: 'LinkedIn',
    type: 'oauth',
    version: '2.0',
    authorization: {
      url: 'https://www.linkedin.com/oauth/v2/authorization',
      params: { scope: 'openid profile email' },
    },
    token: 'https://www.linkedin.com/oauth/v2/accessToken',
    userinfo: 'https://api.linkedin.com/v2/userinfo',
    profile(profile: Record<string, unknown>) {
      return {
        id: profile.sub as string,
        name: `${profile.given_name ?? ''} ${profile.family_name ?? ''}`.trim(),
        email: profile.email as string,
        image: profile.picture as string ?? null,
      }
    },
    style: {
      logo: '/logos/linkedin.svg',
      logoDark: '/logos/linkedin.svg',
      bg: '#0A66C2',
      text: '#fff',
    },
    options,
  }
}

// ── Facebook Provider ──────────────────────────────────────────
export function FacebookProvider(options: OAuthUserConfig<Record<string, unknown>>): OAuthConfig<Record<string, unknown>> {
  return {
    id: 'facebook',
    name: 'Facebook',
    type: 'oauth',
    version: '2.0',
    authorization: {
      url: 'https://www.facebook.com/v18.0/dialog/oauth',
      params: { scope: 'email public_profile' },
    },
    token: 'https://graph.facebook.com/oauth/access_token',
    userinfo: {
      url: 'https://graph.facebook.com/me',
      params: { fields: 'id,name,email,picture' },
    },
    profile(profile: Record<string, unknown>) {
      const picture = profile.picture as Record<string, unknown>
      return {
        id: profile.id as string,
        name: profile.name as string,
        email: profile.email as string ?? null,
        image: (picture?.data as Record<string, unknown>)?.url as string ?? null,
      }
    },
    style: {
      logo: '/logos/facebook.svg',
      logoDark: '/logos/facebook.svg',
      bg: '#1877F2',
      text: '#fff',
    },
    options,
  }
}

// ── Build providers array from env ─────────────────────────────
export function buildProviders() {
  const providers = []

  if (process.env.GOOGLE_CLIENT_ID) {
    providers.push(GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      profile(profile) {
        return {
          id: profile.sub,
          name: profile.name,
          email: profile.email,
          image: profile.picture,
        }
      },
    }))
  }

  if (process.env.GITHUB_CLIENT_ID) {
    providers.push(GithubProvider({
      clientId: process.env.GITHUB_CLIENT_ID,
      clientSecret: process.env.GITHUB_CLIENT_SECRET!,
      profile(profile) {
        return {
          id: profile.id.toString(),
          name: profile.name ?? profile.login,
          email: profile.email,
          image: profile.avatar_url,
          username: profile.login,
        }
      },
    }))
  }

  if (process.env.LINKEDIN_CLIENT_ID) {
    providers.push(LinkedInProvider({
      clientId: process.env.LINKEDIN_CLIENT_ID,
      clientSecret: process.env.LINKEDIN_CLIENT_SECRET!,
    }))
  }

  if (process.env.FACEBOOK_CLIENT_ID) {
    providers.push(FacebookProvider({
      clientId: process.env.FACEBOOK_CLIENT_ID,
      clientSecret: process.env.FACEBOOK_CLIENT_SECRET!,
    }))
  }

  return providers
}
