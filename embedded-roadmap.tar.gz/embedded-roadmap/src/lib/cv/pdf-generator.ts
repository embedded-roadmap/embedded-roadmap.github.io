// src/lib/cv/pdf-generator.ts
// Vector PDF generation for engineering CVs using @react-pdf/renderer concepts
// Outputs HTML string → Puppeteer/Chrome headless for true vector PDF
// In this codebase we use a pure HTML approach (no extra deps) for portability.

import type { EngineerCv, CvSkillSection, CvTemplateId, RarityTier } from '@/types'
import { RARITY_LABELS, RANK_LABELS } from '@/types'

// ── Template registry ─────────────────────────────────────────

export type PdfRenderOptions = {
  template: CvTemplateId
  theme: 'light' | 'dark'
  includeRoadmapStats: boolean
  includeRarityBadges: boolean
  atsMode: boolean          // strip colors/graphics for pure ATS parsing
}

const DEFAULT_OPTIONS: PdfRenderOptions = {
  template: 'precision',
  theme: 'light',
  includeRoadmapStats: true,
  includeRarityBadges: true,
  atsMode: false,
}

// ── Main generator ────────────────────────────────────────────

export function generateCvHtml(cv: EngineerCv, roadmapData: {
  learnedTopics: Array<{ name: string; rarity: RarityTier; branchName: string }>
  earnedBadges: Array<{ name: string; icon: string; rarity: RarityTier }>
  totalXp: number
  globalPercentile: number
  topicsLearned: number
  rareSkillsCount: number
  currentLevel: string
}, options: Partial<PdfRenderOptions> = {}): string {
  const opts = { ...DEFAULT_OPTIONS, ...options }

  const templateFn: Record<CvTemplateId, typeof renderPrecisionTemplate> = {
    precision: renderPrecisionTemplate,
    vector:    renderVectorTemplate,
    circuit:   renderCircuitTemplate,
    minimal:   renderMinimalTemplate,
  }

  return (templateFn[opts.template] ?? renderPrecisionTemplate)(cv, roadmapData, opts)
}

// ── Template: PRECISION (default — clean professional) ────────

function renderPrecisionTemplate(
  cv: EngineerCv,
  rd: ReturnType<typeof generateCvHtml> extends string ? never : Parameters<typeof generateCvHtml>[1],
  opts: PdfRenderOptions
): string {
  const accentColor = opts.atsMode ? '#000000' : '#0f4c81'
  const ruleColor   = opts.atsMode ? '#cccccc' : '#0f4c81'

  const skills = buildSkillsText(cv, rd)
  const experienceHtml = (cv.experience ?? []).map(e => `
    <div class="exp-item" style="margin-bottom:12pt">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-weight:600;font-size:10.5pt">${e.title}</span>
        <span style="color:#666;font-size:9pt">${formatDateRange(e.startDate, e.endDate, e.isCurrent)}</span>
      </div>
      <div style="color:${accentColor};font-size:9.5pt;margin-bottom:3pt">${e.company}${e.location ? ` · ${e.location}` : ''}</div>
      ${e.description ? `<p style="font-size:9pt;margin:3pt 0;color:#333">${e.description}</p>` : ''}
      ${(e.highlights ?? []).length > 0 ? `
        <ul style="margin:3pt 0 0 12pt;padding:0">
          ${e.highlights.map(h => `<li style="font-size:9pt;color:#333;margin-bottom:2pt">${h}</li>`).join('')}
        </ul>` : ''}
      ${(e.techStack ?? []).length > 0 ? `
        <div style="margin-top:4pt;font-size:8.5pt;color:#555">
          <span style="font-weight:600">Stack:</span> ${e.techStack.join(' · ')}
        </div>` : ''}
    </div>`).join('')

  const educationHtml = (cv.education ?? []).map(e => `
    <div style="margin-bottom:8pt">
      <div style="display:flex;justify-content:space-between">
        <span style="font-weight:600;font-size:10pt">${e.institution}</span>
        <span style="color:#666;font-size:9pt">${e.startYear}${e.endYear ? `–${e.endYear}` : '–present'}</span>
      </div>
      <div style="color:#444;font-size:9pt">${e.degree}${e.field ? `, ${e.field}` : ''}${e.gpa ? ` · GPA: ${e.gpa}` : ''}${e.honors ? ` · ${e.honors}` : ''}</div>
    </div>`).join('')

  const certsHtml = (cv.certifications ?? []).map(c => `
    <div style="margin-bottom:5pt;font-size:9pt">
      <span style="font-weight:600">${c.name}</span>
      <span style="color:#666"> · ${c.issuer}${c.issuedDate ? ` (${new Date(c.issuedDate).getFullYear()})` : ''}</span>
    </div>`).join('')

  const projectsHtml = (cv.projects ?? []).filter(p => p.isFeatured || !cv.projects.some(x => x.isFeatured)).slice(0, 4).map(p => `
    <div style="margin-bottom:10pt">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-weight:600;font-size:10pt">${p.title}</span>
        ${p.repoUrl ? `<span style="font-size:8.5pt;color:${accentColor}">${p.repoUrl.replace('https://', '')}</span>` : ''}
      </div>
      ${p.description ? `<p style="font-size:9pt;color:#333;margin:2pt 0 4pt">${p.description}</p>` : ''}
      ${(p.techStack ?? []).length > 0 ? `<div style="font-size:8.5pt;color:#555"><span style="font-weight:600">Tech:</span> ${p.techStack.join(', ')}</div>` : ''}
      ${(p.hardwareStack ?? []).length > 0 ? `<div style="font-size:8.5pt;color:#555"><span style="font-weight:600">HW:</span> ${p.hardwareStack.join(', ')}</div>` : ''}
    </div>`).join('')

  const pubsHtml = (cv.publications ?? []).map(p => `
    <div style="margin-bottom:6pt;font-size:9pt">
      <span style="font-weight:600">${p.title}</span>
      <span style="color:#666"> · ${p.venue}, ${p.year}</span>
      ${p.doi ? `<span style="color:${accentColor}"> · DOI: ${p.doi}</span>` : ''}
    </div>`).join('')

  const patentsHtml = (cv.patents ?? []).map(p => `
    <div style="margin-bottom:6pt;font-size:9pt">
      <span style="font-weight:600">${p.title}</span>
      <span style="color:#666"> · ${p.patentNumber}${p.jurisdiction ? ` (${p.jurisdiction})` : ''}${p.grantDate ? `, granted ${new Date(p.grantDate).getFullYear()}` : ''}</span>
    </div>`).join('')

  const awardsHtml = (cv.awards ?? []).map(a => `
    <div style="margin-bottom:5pt;font-size:9pt">
      <span style="font-weight:600">${a.title}</span>
      <span style="color:#666"> · ${a.issuer}, ${a.year}</span>
    </div>`).join('')

  const statsHtml = opts.includeRoadmapStats && !opts.atsMode ? `
    <div style="background:#f0f7ff;border:1pt solid ${accentColor};border-radius:4pt;padding:8pt 10pt;margin-top:8pt;font-size:8.5pt">
      <div style="font-weight:700;color:${accentColor};margin-bottom:4pt;font-size:9pt">EmbeddedRoadmap Statistics</div>
      <div style="display:flex;gap:16pt;flex-wrap:wrap">
        <span>Level: <strong>${rd.currentLevel}</strong></span>
        <span>XP: <strong>${rd.totalXp.toLocaleString()}</strong></span>
        <span>Topics: <strong>${rd.topicsLearned}</strong></span>
        <span>Rare Skills: <strong>${rd.rareSkillsCount}</strong></span>
        <span>Percentile: <strong>Top ${(100 - rd.globalPercentile).toFixed(1)}%</strong></span>
      </div>
    </div>` : ''

  const openToWorkBadge = cv.openToWork !== 'not_looking' ? `
    <span style="display:inline-block;background:${cv.openToWork === 'open_to_work' ? '#16a34a' : cv.openToWork === 'hiring' ? '#2563eb' : '#7c3aed'};color:white;padding:2pt 8pt;border-radius:12pt;font-size:8pt;font-weight:600;margin-left:8pt">
      ${cv.openToWork === 'open_to_work' ? '✓ Open to Work' : cv.openToWork === 'hiring' ? '🔍 Hiring' : '⚡ Freelance Available'}
    </span>` : ''

  const socialHtml = buildSocialLinksText(cv)

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${cv.fullName ?? 'Engineering CV'} — CV</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html { font-family: 'Segoe UI', Calibri, Arial, sans-serif; font-size: 10pt; color: #1a1a1a; background: #fff; }
  body { padding: 20mm 16mm 16mm; max-width: 210mm; margin: 0 auto; }
  h2 { font-size: 10.5pt; font-weight: 700; color: ${accentColor}; text-transform: uppercase;
       letter-spacing: 0.08em; border-bottom: 1.5pt solid ${ruleColor}; padding-bottom: 3pt; margin: 14pt 0 8pt; }
  .header { margin-bottom: 12pt; }
  .name { font-size: 22pt; font-weight: 700; color: #0a0a0a; line-height: 1.1; }
  .title-line { font-size: 12pt; color: ${accentColor}; font-weight: 400; margin: 3pt 0 5pt; }
  .contact-line { font-size: 9pt; color: #444; margin-top: 4pt; }
  .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 0 24pt; }
  .skill-cat { margin-bottom: 7pt; }
  .skill-cat-label { font-weight: 700; font-size: 9pt; color: #333; }
  .skill-list { font-size: 9pt; color: #444; margin-top: 2pt; }
  @media print {
    body { padding: 15mm 12mm 12mm; }
    @page { size: A4; margin: 0; }
  }
</style>
</head>
<body>

<div class="header">
  <div class="name">${cv.fullName ?? ''}${openToWorkBadge}</div>
  <div class="title-line">${cv.title ?? ''}</div>
  <div class="contact-line">
    ${[cv.email, cv.phone, cv.location].filter(Boolean).join('  ·  ')}
    ${socialHtml}
  </div>
</div>

${cv.summary ? `
<h2>Professional Summary</h2>
<p style="font-size:9.5pt;color:#333;line-height:1.5">${cv.summary}</p>
` : ''}

${statsHtml}

${experienceHtml.trim() ? `<h2>Work Experience</h2>${experienceHtml}` : ''}

<div class="two-col">
  <div>
    ${skills.technical.trim() ? `
    <h2>Technical Skills</h2>
    ${skills.technical}
    ` : ''}
    ${certsHtml.trim() ? `<h2>Certifications</h2>${certsHtml}` : ''}
  </div>
  <div>
    ${educationHtml.trim() ? `<h2>Education</h2>${educationHtml}` : ''}
    ${skills.languages ? `<h2>Languages</h2><div style="font-size:9pt">${skills.languages}</div>` : ''}
  </div>
</div>

${projectsHtml.trim() ? `<h2>Engineering Projects</h2>${projectsHtml}` : ''}
${pubsHtml.trim() ? `<h2>Publications</h2>${pubsHtml}` : ''}
${patentsHtml.trim() ? `<h2>Patents</h2>${patentsHtml}` : ''}
${awardsHtml.trim() ? `<h2>Awards & Recognition</h2>${awardsHtml}` : ''}

</body>
</html>`
}

// ── Template: VECTOR (two-column sidebar) ─────────────────────

function renderVectorTemplate(
  cv: EngineerCv,
  rd: Parameters<typeof generateCvHtml>[1],
  opts: PdfRenderOptions
): string {
  const sidebar = opts.atsMode ? '#f5f5f5' : '#0f1f3d'
  const sidebarText = opts.atsMode ? '#000' : '#e2e8f0'
  const accent = '#38bdf8'

  const skills = buildSkillsText(cv, rd)

  const sidebarContent = `
    <div style="color:${sidebarText}">
      <div style="font-size:9.5pt;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin:0 0 8pt;padding-bottom:4pt;border-bottom:1pt solid rgba(255,255,255,0.15)">Contact</div>
      <div style="font-size:8.5pt;line-height:1.8">
        ${cv.email ? `<div>✉ ${cv.email}</div>` : ''}
        ${cv.phone ? `<div>☎ ${cv.phone}</div>` : ''}
        ${cv.location ? `<div>📍 ${cv.location}</div>` : ''}
        ${cv.socialLinks?.linkedin ? `<div>in ${cv.socialLinks.linkedin.replace('https://linkedin.com/in/', '')}</div>` : ''}
        ${cv.socialLinks?.github ? `<div>⌥ ${cv.socialLinks.github.replace('https://github.com/', '')}</div>` : ''}
      </div>

      <div style="font-size:9.5pt;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin:14pt 0 8pt;padding-bottom:4pt;border-bottom:1pt solid rgba(255,255,255,0.15)">Skills</div>
      <div style="font-size:8.5pt;line-height:1.9">${skills.sidebarList}</div>

      ${(cv.certifications ?? []).length > 0 ? `
        <div style="font-size:9.5pt;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin:14pt 0 8pt;padding-bottom:4pt;border-bottom:1pt solid rgba(255,255,255,0.15)">Certifications</div>
        ${cv.certifications.map(c => `<div style="font-size:8pt;margin-bottom:4pt"><strong>${c.name}</strong><br/><span style="opacity:0.7">${c.issuer}</span></div>`).join('')}
      ` : ''}

      ${opts.includeRoadmapStats ? `
        <div style="font-size:9.5pt;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin:14pt 0 8pt;padding-bottom:4pt;border-bottom:1pt solid rgba(255,255,255,0.15)">Platform Stats</div>
        <div style="font-size:8pt;line-height:2">
          <div>Level: <strong>${rd.currentLevel}</strong></div>
          <div>XP: <strong>${rd.totalXp.toLocaleString()}</strong></div>
          <div>Percentile: <strong>Top ${(100 - rd.globalPercentile).toFixed(0)}%</strong></div>
          <div>Rare Skills: <strong>${rd.rareSkillsCount}</strong></div>
        </div>
      ` : ''}
    </div>`

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${cv.fullName ?? ''} — CV</title>
<style>
  * { margin:0;padding:0;box-sizing:border-box }
  html { font-family: 'Segoe UI', Arial, sans-serif; font-size:10pt; color:#1a1a1a; background:#fff }
  body { display:grid; grid-template-columns:220pt 1fr; min-height:297mm }
  .sidebar { background:${sidebar}; padding:20pt 14pt; }
  .main { padding:20pt 16pt; }
  h2 { font-size:10pt;font-weight:700;color:#0f1f3d;text-transform:uppercase;letter-spacing:0.08em;
       border-bottom:1.5pt solid #0f1f3d;padding-bottom:3pt;margin:12pt 0 7pt }
  .name { font-size:20pt;font-weight:700;line-height:1.1;color:#0a0a0a }
  .title-line { font-size:11pt;color:${accent};margin:3pt 0 }
  @media print { @page { size:A4; margin:0 } body { margin:0 } }
</style>
</head>
<body>
  <div class="sidebar">${sidebarContent}</div>
  <div class="main">
    <div style="margin-bottom:14pt">
      <div class="name">${cv.fullName ?? ''}</div>
      <div class="title-line">${cv.title ?? ''}</div>
      ${cv.openToWork !== 'not_looking' ? `<span style="background:#16a34a;color:#fff;padding:2pt 8pt;border-radius:12pt;font-size:8pt;font-weight:600">✓ ${cv.openToWork === 'open_to_work' ? 'Open to Work' : cv.openToWork === 'hiring' ? 'Hiring' : 'Freelance Available'}</span>` : ''}
    </div>

    ${cv.summary ? `<h2>Summary</h2><p style="font-size:9.5pt;color:#333;line-height:1.5">${cv.summary}</p>` : ''}

    ${cv.experience?.length ? `
    <h2>Experience</h2>
    ${cv.experience.map(e => `
      <div style="margin-bottom:10pt">
        <div style="display:flex;justify-content:space-between">
          <strong style="font-size:10.5pt">${e.title}</strong>
          <span style="color:#666;font-size:9pt">${formatDateRange(e.startDate, e.endDate, e.isCurrent)}</span>
        </div>
        <div style="color:#2563eb;font-size:9.5pt;margin-bottom:3pt">${e.company}</div>
        ${e.description ? `<p style="font-size:9pt;color:#333">${e.description}</p>` : ''}
        ${e.highlights?.length ? `<ul style="margin:4pt 0 0 14pt">${e.highlights.map(h => `<li style="font-size:9pt">${h}</li>`).join('')}</ul>` : ''}
      </div>`).join('')}
    ` : ''}

    ${cv.projects?.filter(p => p.isFeatured).slice(0, 3).length ? `
    <h2>Projects</h2>
    ${cv.projects.filter(p => p.isFeatured).slice(0, 3).map(p => `
      <div style="margin-bottom:9pt">
        <strong>${p.title}</strong>${p.repoUrl ? ` <span style="font-size:8.5pt;color:#2563eb">${p.repoUrl.replace('https://', '')}</span>` : ''}
        ${p.description ? `<p style="font-size:9pt;color:#333;margin:2pt 0">${p.description}</p>` : ''}
        ${p.techStack?.length ? `<div style="font-size:8.5pt;color:#666">Tech: ${p.techStack.join(', ')}</div>` : ''}
      </div>`).join('')}
    ` : ''}

    ${cv.education?.length ? `
    <h2>Education</h2>
    ${cv.education.map(e => `
      <div style="margin-bottom:7pt">
        <div style="display:flex;justify-content:space-between">
          <strong>${e.institution}</strong>
          <span style="color:#666;font-size:9pt">${e.startYear}–${e.endYear ?? 'present'}</span>
        </div>
        <div style="font-size:9pt;color:#444">${e.degree}${e.field ? ', ' + e.field : ''}${e.gpa ? ' · GPA: ' + e.gpa : ''}</div>
      </div>`).join('')}
    ` : ''}
  </div>
</body>
</html>`
}

// ── Template: CIRCUIT (engineering aesthetic) ─────────────────

function renderCircuitTemplate(cv: EngineerCv, rd: Parameters<typeof generateCvHtml>[1], opts: PdfRenderOptions): string {
  // Same structure as precision but with circuit-board aesthetic headers
  return renderPrecisionTemplate(cv, rd, { ...opts, template: 'precision' })
    .replace(/color: #0f4c81/g, 'color: #0ea5e9')
    .replace(/border-bottom: 1.5pt solid #0f4c81/g, 'border-bottom: 1.5pt solid #0ea5e9')
}

// ── Template: MINIMAL (ATS-pure) ──────────────────────────────

function renderMinimalTemplate(cv: EngineerCv, rd: Parameters<typeof generateCvHtml>[1], opts: PdfRenderOptions): string {
  return renderPrecisionTemplate(cv, rd, { ...opts, atsMode: true })
}

// ── Shared helpers ────────────────────────────────────────────

function buildSkillsText(cv: EngineerCv, rd: Parameters<typeof generateCvHtml>[1]) {
  // Group roadmap topics by category
  const roadmapTopicsByBranch: Record<string, string[]> = {}
  for (const t of rd.learnedTopics ?? []) {
    const branch = t.branchName
    ;(roadmapTopicsByBranch[branch] ??= []).push(t.name)
  }

  let technical = ''
  const allSkillItems: string[] = []

  // Auto-populated from roadmap (most important)
  for (const [branch, names] of Object.entries(roadmapTopicsByBranch).slice(0, 8)) {
    const topNames = names.slice(0, 6).join(', ')
    technical += `
      <div class="skill-cat">
        <div class="skill-cat-label">${branch}</div>
        <div class="skill-list">${topNames}${names.length > 6 ? ` +${names.length - 6} more` : ''}</div>
      </div>`
    allSkillItems.push(...names.slice(0, 4))
  }

  // Manual skill categories
  for (const cat of cv.skills?.manualSkills ?? []) {
    technical += `
      <div class="skill-cat">
        <div class="skill-cat-label">${cat.category}</div>
        <div class="skill-list">${cat.skills.join(', ')}</div>
      </div>`
    allSkillItems.push(...cat.skills.slice(0, 3))
  }

  const sidebarList = allSkillItems.map(s => `<div>• ${s}</div>`).join('')

  const langMap: Record<string, string> = { native: 'Native', professional: 'Professional', conversational: 'Conversational', basic: 'Basic' }
  const languages = (cv.skills?.languages ?? [])
    .map(l => `${l.name} (${langMap[l.level] ?? l.level})`).join(' · ')

  return { technical, sidebarList, languages }
}

function buildSocialLinksText(cv: EngineerCv): string {
  const links = cv.socialLinks ?? {}
  const parts: string[] = []
  if (links.linkedin) parts.push(`LinkedIn: ${links.linkedin.replace('https://linkedin.com/in/', 'in/')}`)
  if (links.github)   parts.push(`GitHub: ${links.github.replace('https://github.com/', 'gh/')}`)
  if (links.hackaday) parts.push(`Hackaday: ${links.hackaday}`)
  if (links.website)  parts.push(links.website)
  return parts.length > 0 ? `<br/>${parts.join('  ·  ')}` : ''
}

function formatDateRange(start: string, end: string | null | undefined, isCurrent: boolean): string {
  const fmt = (d: string) => {
    try {
      return new Date(d).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    } catch { return d }
  }
  return `${fmt(start)} – ${isCurrent || !end ? 'Present' : fmt(end)}`
}
