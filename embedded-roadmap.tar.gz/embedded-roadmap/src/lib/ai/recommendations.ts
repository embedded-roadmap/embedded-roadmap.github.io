// src/lib/ai/recommendations.ts
// AI-powered learning path advisor using OpenAI

import OpenAI from 'openai'
import type { Topic, User, AIRecommendation, AICareerAnalysis, RankTier } from '@/types'
import { RANK_LABELS } from '@/types'
import { xpToNextRank } from '@/lib/algorithms/gamification'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
const MODEL = process.env.OPENAI_MODEL ?? 'gpt-4o-mini'

// ── Rate-limiting guard ────────────────────────────────────────

const callCache = new Map<string, { result: unknown; expires: number }>()

function getCached<T>(key: string): T | null {
  const entry = callCache.get(key)
  if (entry && entry.expires > Date.now()) return entry.result as T
  return null
}

function setCache<T>(key: string, result: T, ttlMs = 60 * 60 * 1000): void {
  callCache.set(key, { result, expires: Date.now() + ttlMs })
}

// ── Next Best Topic ────────────────────────────────────────────

/**
 * AI-powered "next best topic" recommendation.
 * Falls back to algorithmic recommendation if OpenAI unavailable.
 */
export async function getNextTopicRecommendations(
  user: User,
  learnedTopics: Topic[],
  availableTopics: Topic[],
  targetRole?: string
): Promise<AIRecommendation[]> {
  const cacheKey = `next:${user.id}:${learnedTopics.length}`
  const cached = getCached<AIRecommendation[]>(cacheKey)
  if (cached) return cached

  // Algorithmic fallback (always available)
  const algorithmic = algorithmicRecommendations(user, learnedTopics, availableTopics)

  if (!process.env.OPENAI_API_KEY) return algorithmic

  try {
    const learnedSummary = learnedTopics
      .sort((a, b) => b.difficultyScore - a.difficultyScore)
      .slice(0, 20)
      .map(t => `${t.name} (${t.difficultyTier}, branch: ${t.branch?.name ?? t.branchId})`)
      .join(', ')

    const candidateSummary = availableTopics
      .filter(t => !learnedTopics.find(l => l.id === t.id))
      .sort((a, b) => (b.industryValue + b.marketDemand) - (a.industryValue + a.marketDemand))
      .slice(0, 30)
      .map(t => `[${t.id.slice(0, 8)}] ${t.name} (diff:${t.difficultyScore}, val:${t.industryValue}, branch:${t.branch?.name ?? ''})`)
      .join('\n')

    const { nextRank, xpNeeded } = xpToNextRank(user.totalXp)
    const targetInfo = targetRole ? `Target role: ${targetRole}.` : ''

    const completion = await openai.chat.completions.create({
      model: MODEL,
      max_tokens: 800,
      response_format: { type: 'json_object' },
      messages: [{
        role: 'system',
        content: `You are an expert electronics and embedded systems career advisor.
Analyze the engineer's profile and recommend their next learning topics.
Respond ONLY in JSON format: { "recommendations": [{ "topicId": "...", "reason": "...", "urgency": "next|soon|when_ready", "careerImpact": "...", "estimatedDays": number, "skillGapScore": number }] }
skillGapScore is 0-100 (how much this fills a gap in their knowledge).
Limit to 5 recommendations. Be specific and technical.`
      }, {
        role: 'user',
        content: `Engineer profile:
- Level: ${RANK_LABELS[user.currentLevel]} (${user.totalXp} XP)
- To next rank (${nextRank ? RANK_LABELS[nextRank] : 'max'}): ${xpNeeded} XP needed
- Topics learned: ${user.topicsLearned} total, ${user.rareTopicsCount} rare
- Streak: ${user.currentStreak} days
- Global percentile: ${user.globalPercentile}%
- ${targetInfo}

Recently learned topics:
${learnedSummary}

Available candidate topics (pick from these IDs):
${candidateSummary}

Recommend the 5 highest-impact next topics for this engineer's career growth.`
      }],
    })

    const parsed = JSON.parse(completion.choices[0].message.content ?? '{}')
    const recs = parsed.recommendations ?? []

    // Map AI topic IDs back to full topics
    const result: AIRecommendation[] = recs
      .map((r: Record<string, unknown>) => {
        const topicId = (r.topicId as string).slice(0, 8)
        const topic = availableTopics.find(t => t.id.startsWith(topicId))
        if (!topic) return null
        return {
          topicId: topic.id,
          topic,
          reason: r.reason as string,
          urgency: r.urgency as 'next' | 'soon' | 'when_ready',
          skillGapScore: r.skillGapScore as number,
          careerImpact: r.careerImpact as string,
          estimatedDays: r.estimatedDays as number,
        }
      })
      .filter(Boolean) as AIRecommendation[]

    // Blend AI + algorithmic (AI first)
    const blended = result.length >= 3 ? result : [...result, ...algorithmic].slice(0, 5)
    setCache(cacheKey, blended, 30 * 60 * 1000) // 30min cache
    return blended

  } catch (err) {
    console.error('[AI] Recommendation failed, using algorithmic fallback:', err)
    return algorithmic
  }
}

/**
 * Algorithmic fallback: rank available topics by composite score
 */
function algorithmicRecommendations(
  user: User,
  learned: Topic[],
  available: Topic[]
): AIRecommendation[] {
  const learnedIds = new Set(learned.map(t => t.id))
  const { nextRank } = xpToNextRank(user.totalXp)

  const scored = available
    .filter(t => !learnedIds.has(t.id))
    .map(t => {
      // Score = industry value + market demand + rarity bonus - difficulty penalty if too hard
      const rarityBonus = t.rarityTier === 'rare' ? 20 : t.rarityTier === 'elite' ? 10 : 0
      const difficultyFit = Math.max(0, 100 - Math.abs(t.difficultyScore - (user.totalXp / 150)))
      const score = t.industryValue * 0.4 + t.marketDemand * 0.3 + difficultyFit * 0.2 + rarityBonus * 0.1
      return { topic: t, score }
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)

  return scored.map(({ topic, score }) => ({
    topicId: topic.id,
    topic,
    reason: `High industry value (${topic.industryValue}/100) and strong market demand`,
    urgency: score > 70 ? 'next' : score > 40 ? 'soon' : 'when_ready',
    skillGapScore: Math.round(score),
    careerImpact: `${topic.rarityTier === 'rare' || topic.rarityTier === 'elite' ? 'Rare skill — ' : ''}adds ${topic.xpReward} XP`,
    estimatedDays: Math.round((topic.estimatedHours ?? topic.difficultyScore / 2) / 2),
  }))
}

// ── Full Career Analysis ──────────────────────────────────────

export async function getCareerAnalysis(
  user: User,
  learnedTopics: Topic[],
  targetRole?: string
): Promise<AICareerAnalysis> {
  const cacheKey = `career:${user.id}:${user.totalXp}`
  const cached = getCached<AICareerAnalysis>(cacheKey)
  if (cached) return cached

  const algorithmic = algorithmicCareerAnalysis(user, learnedTopics, targetRole)

  if (!process.env.OPENAI_API_KEY) return algorithmic

  try {
    const topicNames = learnedTopics.map(t => t.name).join(', ')
    const { nextRank, xpNeeded } = xpToNextRank(user.totalXp)

    const completion = await openai.chat.completions.create({
      model: MODEL,
      max_tokens: 1200,
      response_format: { type: 'json_object' },
      messages: [{
        role: 'system',
        content: `You are a senior electronics and embedded systems engineering career coach.
Analyze the engineer's knowledge and provide career guidance.
Respond ONLY in JSON:
{
  "currentStrengths": ["..."],
  "criticalGaps": ["..."],
  "careerInsight": "...",
  "estimatedTimeToNextLevel": number,
  "salaryInsight": "..."
}
Be specific to embedded/electronics engineering. Reference actual technologies and standards.`
      }, {
        role: 'user',
        content: `Engineer: ${RANK_LABELS[user.currentLevel]}, ${user.totalXp} XP, ${user.topicsLearned} topics
Known topics (sample): ${topicNames.slice(0, 500)}
Rare skills: ${user.rareTopicsCount}
Target: ${targetRole ?? nextRank ? RANK_LABELS[nextRank!] : 'Distinguished Engineer'}
XP to next level: ${xpNeeded}
Global percentile: ${user.globalPercentile}%`
      }],
    })

    const parsed = JSON.parse(completion.choices[0].message.content ?? '{}')
    const result: AICareerAnalysis = {
      currentStrengths: parsed.currentStrengths ?? algorithmic.currentStrengths,
      criticalGaps:     parsed.criticalGaps ?? algorithmic.criticalGaps,
      recommendedPath:  algorithmic.recommendedPath,  // use algorithmic for topics
      careerInsight:    parsed.careerInsight ?? algorithmic.careerInsight,
      estimatedTimeToNextLevel: parsed.estimatedTimeToNextLevel ?? algorithmic.estimatedTimeToNextLevel,
      salaryInsight:    parsed.salaryInsight ?? algorithmic.salaryInsight,
    }

    setCache(cacheKey, result, 60 * 60 * 1000) // 1hr cache
    return result
  } catch {
    return algorithmic
  }
}

function algorithmicCareerAnalysis(
  user: User,
  learned: Topic[],
  targetRole?: string
): AICareerAnalysis {
  const { nextRank, xpNeeded } = xpToNextRank(user.totalXp)

  const topBranches = learned
    .reduce((acc, t) => {
      const key = t.branchId
      acc[key] = (acc[key] ?? 0) + t.industryValue
      return acc
    }, {} as Record<string, number>)

  const strengths = Object.entries(topBranches)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([b]) => learned.find(t => t.branchId === b)?.branch?.name ?? b)

  const gaps = nextRank === 'staff' || nextRank === 'distinguished'
    ? ['Mixed-signal IC design', 'ASIC/FPGA design flow', 'DDR signal integrity']
    : ['RTOS kernel internals', 'Bootloader development', 'Power supply design']

  const daysToNext = Math.ceil(xpNeeded / 150)  // avg 150 XP/day for active learner

  return {
    currentStrengths: strengths.length > 0 ? strengths : ['General electronics fundamentals'],
    criticalGaps: gaps,
    recommendedPath: [],
    careerInsight: `At ${RANK_LABELS[user.currentLevel]} level with ${user.globalPercentile}th percentile standing. ${xpNeeded > 0 ? `${xpNeeded} XP to reach ${RANK_LABELS[nextRank!]}.` : 'Maximum rank achieved.'}`,
    estimatedTimeToNextLevel: daysToNext,
    salaryInsight: `Engineers at ${RANK_LABELS[user.currentLevel]} level in embedded systems typically earn $${SALARY_RANGES[user.currentLevel]} (USD, varies by location and domain).`,
  }
}

const SALARY_RANGES: Record<RankTier, string> = {
  intern:        '45,000–70,000',
  junior:        '65,000–90,000',
  mid:           '90,000–120,000',
  senior:        '120,000–160,000',
  lead:          '150,000–200,000',
  staff:         '180,000–240,000',
  distinguished: '220,000–350,000+',
}

// ── Quiz generation ───────────────────────────────────────────

export interface QuizQuestion {
  question: string
  options: string[]
  correctIndex: number
  explanation: string
  difficulty: 'easy' | 'medium' | 'hard'
}

export async function generateQuiz(topic: Topic, count = 5): Promise<QuizQuestion[]> {
  if (!process.env.OPENAI_API_KEY) return []

  const cacheKey = `quiz:${topic.id}:${count}`
  const cached = getCached<QuizQuestion[]>(cacheKey)
  if (cached) return cached

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      max_tokens: 1500,
      response_format: { type: 'json_object' },
      messages: [{
        role: 'system',
        content: `Generate ${count} multiple-choice quiz questions about the given electronics/embedded systems topic.
Respond ONLY in JSON: { "questions": [{ "question": "...", "options": ["A","B","C","D"], "correctIndex": 0, "explanation": "...", "difficulty": "easy|medium|hard" }] }
Questions must be technically accurate, practical, and test real engineering understanding.`
      }, {
        role: 'user',
        content: `Topic: ${topic.name}
Description: ${topic.description ?? ''}
Difficulty: ${topic.difficultyTier}
Key areas: ${[...(topic.tools ?? []), ...(topic.interviewTopics ?? [])].join(', ')}`
      }],
    })

    const parsed = JSON.parse(completion.choices[0].message.content ?? '{}')
    const result = parsed.questions ?? []
    setCache(cacheKey, result, 24 * 60 * 60 * 1000) // 24hr cache
    return result
  } catch {
    return []
  }
}
