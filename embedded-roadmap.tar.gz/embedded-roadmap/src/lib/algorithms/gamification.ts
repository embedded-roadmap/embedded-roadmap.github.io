// src/lib/algorithms/gamification.ts
// Core gamification engine: XP calculation, ranking, percentile, badge evaluation

import type {
  RankTier, RarityTier, DifficultyTier, Topic,
  GamificationResult, Badge
} from '@/types'
import { RANK_XP_THRESHOLDS } from '@/types'

// ══════════════════════════════════════════════════════════════
//  XP CALCULATION
// ══════════════════════════════════════════════════════════════

/**
 * Compute XP reward for a topic.
 * Matches the PostgreSQL generated column logic, but available client/server-side.
 */
export function computeTopicXP(topic: Pick<Topic,
  'difficultyScore' | 'mathComplexity' | 'industryValue' | 'rarityTier'
>): number {
  const base = topic.difficultyScore * 4 + topic.mathComplexity * 2
  const rarityBonus = RARITY_XP_BONUS[topic.rarityTier] ?? 0
  const industryBonus = topic.industryValue > 80 ? 60 : topic.industryValue > 60 ? 30 : 0
  return Math.max(30, Math.min(800, base + rarityBonus + industryBonus))
}

const RARITY_XP_BONUS: Record<RarityTier, number> = {
  ubiquitous: 0,
  common:     0,
  uncommon:   20,
  rare:       60,
  elite:      120,
  legendary:  200,
}

/**
 * Streak multiplier: each consecutive day adds a small bonus
 */
export function streakMultiplier(streakDays: number): number {
  if (streakDays < 3)  return 1.0
  if (streakDays < 7)  return 1.05
  if (streakDays < 14) return 1.10
  if (streakDays < 30) return 1.15
  if (streakDays < 90) return 1.20
  return 1.25
}

/**
 * Apply streak multiplier and round to integer
 */
export function applyStreak(baseXp: number, streakDays: number): number {
  return Math.round(baseXp * streakMultiplier(streakDays))
}

// ══════════════════════════════════════════════════════════════
//  RANK CALCULATION
// ══════════════════════════════════════════════════════════════

export function xpToRank(xp: number): RankTier {
  const tiers = Object.entries(RANK_XP_THRESHOLDS).reverse() as [RankTier, number][]
  for (const [tier, threshold] of tiers) {
    if (xp >= threshold) return tier
  }
  return 'intern'
}

export function xpToNextRank(xp: number): { nextRank: RankTier | null; xpNeeded: number; xpIntoCurrentRank: number; pct: number } {
  const currentRank = xpToRank(xp)
  const tiers = Object.entries(RANK_XP_THRESHOLDS) as [RankTier, number][]
  const currentIdx = tiers.findIndex(([r]) => r === currentRank)

  if (currentIdx === tiers.length - 1) {
    // Distinguished — max rank
    return { nextRank: null, xpNeeded: 0, xpIntoCurrentRank: xp - tiers[currentIdx][1], pct: 100 }
  }

  const currentThreshold = tiers[currentIdx][1]
  const nextThreshold = tiers[currentIdx + 1][1]
  const xpIntoCurrentRank = xp - currentThreshold
  const rangeSize = nextThreshold - currentThreshold
  const pct = Math.min(100, Math.round((xpIntoCurrentRank / rangeSize) * 100))

  return {
    nextRank: tiers[currentIdx + 1][0],
    xpNeeded: nextThreshold - xp,
    xpIntoCurrentRank,
    pct,
  }
}

// ══════════════════════════════════════════════════════════════
//  PERCENTILE CALCULATION
// ══════════════════════════════════════════════════════════════

/**
 * Statistical model for global percentile estimation.
 * Uses a log-normal distribution model based on engineering community data.
 * When real DB user counts are small, this provides realistic estimates.
 */
export function estimateGlobalPercentile(userXp: number): number {
  // Modeled from engineering community distributions
  // Median engineer (~2 yrs exp) ≈ 1200 XP
  const MEDIAN_XP = 1200
  const LOG_SIGMA = 1.1  // spread of the distribution

  if (userXp <= 0) return 0

  const logX = Math.log(userXp)
  const logMedian = Math.log(MEDIAN_XP)
  const z = (logX - logMedian) / LOG_SIGMA

  // Approximate normal CDF
  const pct = normalCDF(z) * 100
  return Math.min(99.9, Math.max(0.1, Math.round(pct * 10) / 10))
}

/** Standard normal CDF approximation (Abramowitz & Stegun) */
function normalCDF(z: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(z))
  const poly = t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))))
  const cdf = 1 - (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * z * z) * poly
  return z >= 0 ? cdf : 1 - cdf
}

/**
 * Estimate what % of engineers globally know a topic,
 * based on difficulty score and industry value.
 */
export function estimateTopicKnownPct(topic: Pick<Topic, 'difficultyScore' | 'industryValue' | 'minLevel'>): number {
  // Base: higher difficulty → fewer engineers know it
  const diffFactor = Math.exp(-topic.difficultyScore / 35)

  // Industry value correction: high-demand topics are learned more
  const demandCorrection = 1 + (topic.industryValue - 50) / 200

  // Level factor: advanced topics have exponentially fewer knowers
  const levelFactor = LEVEL_KNOWN_FACTOR[topic.minLevel] ?? 0.5

  const rawPct = diffFactor * demandCorrection * levelFactor * 100
  return Math.min(98, Math.max(0.1, Math.round(rawPct * 10) / 10))
}

const LEVEL_KNOWN_FACTOR: Record<RankTier, number> = {
  intern:        0.90,
  junior:        0.65,
  mid:           0.40,
  senior:        0.20,
  lead:          0.08,
  staff:         0.03,
  distinguished: 0.008,
}

export function knownPctToRarity(pct: number): RarityTier {
  if (pct > 60)  return 'ubiquitous'
  if (pct > 35)  return 'common'
  if (pct > 15)  return 'uncommon'
  if (pct > 5)   return 'rare'
  if (pct > 1)   return 'elite'
  return 'legendary'
}

// ══════════════════════════════════════════════════════════════
//  MONTHLY SCORE ALGORITHM
// ══════════════════════════════════════════════════════════════

export interface MonthlyScoreComponents {
  xpThisMonth: number
  topicsLearned: number
  rareTopicsLearned: number
  streakDays: number
  badgesEarned: number
}

export function calculateMonthlyScore(c: MonthlyScoreComponents): number {
  return (
    c.xpThisMonth   * 1.0
    + c.topicsLearned  * 50.0
    + c.rareTopicsLearned * 200.0
    + c.streakDays       * 10.0
    + c.badgesEarned     * 150.0
  )
}

// ══════════════════════════════════════════════════════════════
//  SPECIALIZATION SCORE
// ══════════════════════════════════════════════════════════════

/**
 * Measures depth vs breadth.
 * High score = deep specialist. Low score = broad generalist.
 */
export function calculateSpecializationScore(
  branchProgress: Array<{ topicsLearned: number; totalTopics: number; xpInBranch: number }>
): number {
  if (branchProgress.length === 0) return 0

  const pcts = branchProgress.map(b => b.topicsLearned / Math.max(b.totalTopics, 1))
  const totalXp = branchProgress.reduce((sum, b) => sum + b.xpInBranch, 0)
  if (totalXp === 0) return 0

  // Entropy-based measure: high entropy = generalist, low entropy = specialist
  const weights = branchProgress.map(b => b.xpInBranch / totalXp)
  const entropy = weights.reduce((e, w) => w > 0 ? e - w * Math.log2(w) : e, 0)
  const maxEntropy = Math.log2(branchProgress.length)
  const normalizedEntropy = maxEntropy > 0 ? entropy / maxEntropy : 0

  // Specialization = 1 - entropy (inverse), scaled to 0-100
  // Also factor in depth (highest single-branch pct)
  const maxPct = Math.max(...pcts)
  const specializationRaw = (1 - normalizedEntropy) * 0.6 + maxPct * 0.4
  return Math.round(specializationRaw * 100)
}

/**
 * Consistency score: based on streak and recent activity pattern
 */
export function calculateConsistencyScore(
  currentStreak: number,
  longestStreak: number,
  totalTopics: number,
  accountAgeDays: number
): number {
  if (accountAgeDays === 0) return 0
  const streakScore = Math.min(100, (currentStreak / Math.max(longestStreak, 1)) * 40 + (longestStreak / 30) * 30)
  const activityRate = Math.min(30, totalTopics / Math.max(accountAgeDays / 30, 1))
  const activityScore = activityRate * 1
  return Math.round(Math.min(100, streakScore + activityScore))
}

// ══════════════════════════════════════════════════════════════
//  DIFFICULTY SCORING ALGORITHM
// ══════════════════════════════════════════════════════════════

/**
 * Dynamic difficulty: base score + adjustments for market signal.
 * Run periodically to keep scores fresh.
 */
export function computeDynamicDifficulty(topic: {
  difficultyScore: number
  mathComplexity: number
  practicalComplexity: number
  industryValue: number
}): DifficultyTier {
  const composite = (
    topic.difficultyScore * 0.5
    + topic.mathComplexity * 0.2
    + topic.practicalComplexity * 0.3
  )
  if (composite < 20) return 'foundational'
  if (composite < 40) return 'intermediate'
  if (composite < 60) return 'advanced'
  if (composite < 75) return 'expert'
  if (composite < 90) return 'elite'
  return 'legendary'
}

// ══════════════════════════════════════════════════════════════
//  TOPIC UNLOCK LOGIC
// ══════════════════════════════════════════════════════════════

export interface UnlockStatus {
  isUnlocked: boolean
  isLocked: boolean
  missingPrereqs: string[]
  lockReason: string | null
}

export function computeUnlockStatus(
  topic: Topic,
  learnedTopicIds: Set<string>,
  userLevel: RankTier
): UnlockStatus {
  const missingPrereqs: string[] = []

  // Level check
  const levelOrder: RankTier[] = ['intern', 'junior', 'mid', 'senior', 'lead', 'staff', 'distinguished']
  const userLevelIdx = levelOrder.indexOf(userLevel)
  const topicLevelIdx = levelOrder.indexOf(topic.minLevel)

  if (topicLevelIdx > userLevelIdx + 1) {
    return {
      isUnlocked: false,
      isLocked: true,
      missingPrereqs: [],
      lockReason: `Requires ${topic.minLevel} level (you are ${userLevel})`,
    }
  }

  // Hard dependency check
  const hardDeps = (topic.dependencies ?? []).filter(d => d.depType === 'requires' && d.strength >= 80)
  for (const dep of hardDeps) {
    if (!learnedTopicIds.has(dep.dependsOnId)) {
      missingPrereqs.push(dep.dependsOn?.name ?? dep.dependsOnId)
    }
  }

  if (missingPrereqs.length > 0) {
    return {
      isUnlocked: false,
      isLocked: true,
      missingPrereqs,
      lockReason: `Requires: ${missingPrereqs.join(', ')}`,
    }
  }

  return { isUnlocked: true, isLocked: false, missingPrereqs: [], lockReason: null }
}

// ══════════════════════════════════════════════════════════════
//  FULL GAMIFICATION PIPELINE (called after topic mark)
// ══════════════════════════════════════════════════════════════

export async function runGamificationPipeline(
  userId: string,
  topicId: string,
  xpEarned: number,
  currentXp: number,
  streakDays: number
): Promise<GamificationResult> {
  const { BadgeQueries, UserQueries } = await import('@/lib/db/queries')

  const xpWithStreak = applyStreak(xpEarned, streakDays)
  const newTotalXp = currentXp + xpWithStreak

  const previousLevel = xpToRank(currentXp)
  const newLevel = xpToRank(newTotalXp)
  const leveledUp = previousLevel !== newLevel

  // Check badges
  const newBadges = await BadgeQueries.checkAndGrantBadges(userId)

  // Recalculate user stats
  await UserQueries.recalculateStats(userId)

  // Get fresh percentile
  const updatedUser = await UserQueries.findById(userId)

  return {
    xpGained: xpWithStreak,
    newTotalXp,
    leveledUp,
    newLevel: leveledUp ? newLevel : null,
    badgesEarned: newBadges,
    newGlobalPercentile: updatedUser?.globalPercentile ?? estimateGlobalPercentile(newTotalXp),
  }
}
