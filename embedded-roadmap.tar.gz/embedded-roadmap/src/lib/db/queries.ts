// src/lib/db/queries.ts — Complete production DAL (auto-overwritten)
import { query, queryOne, execute, transaction, rowsToCamel } from './index'
import type { User, Branch, Topic, UserProgress, BranchProgress, Badge, UserBadge, LeaderboardEntry, SearchResult } from '@/types'
import { xpToRank } from '@/types'

function toSnake(s: string): string { return s.replace(/[A-Z]/g, c => `_${c.toLowerCase()}`) }

export const UserQueries = {
  async findById(id: string): Promise<User|null> {
    const rows = await query<Record<string,unknown>>(`SELECT u.*,ep.headline,ep.years_experience,ep.current_company,ep.current_role,ep.expertise_areas,ep.country_code,ep.target_role FROM users u LEFT JOIN engineer_profiles ep ON ep.user_id=u.id WHERE u.id=$1 AND u.deleted_at IS NULL`,[id])
    return rows[0]?rowsToCamel<User>(rows)[0]:null
  },
  async findByUsername(username: string): Promise<User|null> {
    const rows = await query<Record<string,unknown>>(`SELECT u.*,ep.headline,ep.years_experience,ep.current_company,ep.current_role,ep.expertise_areas,ep.country_code,ep.target_role FROM users u LEFT JOIN engineer_profiles ep ON ep.user_id=u.id WHERE u.username=$1 AND u.deleted_at IS NULL`,[username])
    return rows[0]?rowsToCamel<User>(rows)[0]:null
  },
  async findByEmail(email: string): Promise<User|null> {
    const rows = await query<Record<string,unknown>>(`SELECT * FROM users WHERE email=$1 AND deleted_at IS NULL`,[email.toLowerCase()])
    return rows[0]?rowsToCamel<User>(rows)[0]:null
  },
  async create(data:{username:string;email:string;passwordHash?:string;displayName?:string;avatarUrl?:string}): Promise<User> {
    return transaction(async(client)=>{
      const r=await client.query(`INSERT INTO users(username,email,password_hash,display_name,avatar_url)VALUES($1,$2,$3,$4,$5)RETURNING *`,[data.username,data.email.toLowerCase(),data.passwordHash??'',data.displayName??data.username,data.avatarUrl??null])
      if(!r.rows[0])throw new Error('User creation failed')
      await client.query(`INSERT INTO engineer_profiles(user_id)VALUES($1)ON CONFLICT DO NOTHING`,[r.rows[0].id])
      await client.query(`INSERT INTO user_privacy_settings(user_id)VALUES($1)ON CONFLICT DO NOTHING`,[r.rows[0].id])
      await client.query(`INSERT INTO engineer_cvs(user_id)VALUES($1)ON CONFLICT DO NOTHING`,[r.rows[0].id])
      return rowsToCamel<User>([r.rows[0]])[0]
    })
  },
  async updateStreak(userId: string): Promise<void> {
    await execute(`UPDATE users SET current_streak=CASE WHEN last_streak_date=CURRENT_DATE-1 THEN current_streak+1 WHEN last_streak_date=CURRENT_DATE THEN current_streak ELSE 1 END,longest_streak=GREATEST(longest_streak,CASE WHEN last_streak_date=CURRENT_DATE-1 THEN current_streak+1 ELSE 1 END),last_streak_date=CURRENT_DATE WHERE id=$1`,[userId])
  },
  async updateProfile(userId: string, data: Record<string,unknown>): Promise<void> {
    const userFields:Record<string,unknown>={};const profileFields:Record<string,unknown>={}
    const pKeys=new Set(['headline','yearsExperience','currentCompany','currentRole','expertiseAreas','countryCode','targetRole'])
    for(const[k,v]of Object.entries(data)){if(v!==undefined){if(pKeys.has(k))profileFields[toSnake(k)]=v;else userFields[toSnake(k)]=v}}
    if(Object.keys(userFields).length>0){const sets=Object.keys(userFields).map((k,i)=>`${k}=$${i+2}`).join(', ');await execute(`UPDATE users SET ${sets} WHERE id=$1`,[userId,...Object.values(userFields)])}
    if(Object.keys(profileFields).length>0){const cols=Object.keys(profileFields).join(', ');const ph=Object.keys(profileFields).map((_,i)=>`$${i+2}`).join(', ');const sets=Object.keys(profileFields).map((k,i)=>`${k}=$${i+2}`).join(', ');await execute(`INSERT INTO engineer_profiles(user_id,${cols})VALUES($1,${ph})ON CONFLICT(user_id)DO UPDATE SET ${sets}`,[userId,...Object.values(profileFields)])}
  },
  async setOnboardingDone(userId: string): Promise<void> { await execute(`UPDATE users SET onboarding_done=true WHERE id=$1`,[userId]) },
  async upsertOnboarding(userId: string, data: Record<string,unknown>): Promise<void> {
    await execute(`INSERT INTO user_onboarding(user_id,step,experience,goals,interests,selected_paths)VALUES($1,$2,$3,$4,$5,$6)ON CONFLICT(user_id)DO UPDATE SET step=$2,experience=$3,goals=$4,interests=$5,selected_paths=$6`,[userId,data.step??0,data.experience??null,data.goals??[],data.interests??[],data.selectedPaths??[]])
  },
  async completeOnboarding(userId: string): Promise<void> {
    await execute(`UPDATE user_onboarding SET completed_at=NOW() WHERE user_id=$1`,[userId])
    await execute(`UPDATE users SET onboarding_done=true WHERE id=$1`,[userId])
  },
  async getOnboarding(userId: string): Promise<Record<string,unknown>|null> {
    return queryOne(`SELECT * FROM user_onboarding WHERE user_id=$1`,[userId])
  },
}

export const BranchQueries = {
  async getAll(publishedOnly=true): Promise<Branch[]> {
    const rows=await query<Record<string,unknown>>(`SELECT * FROM branches ${publishedOnly?'WHERE is_published=true':''} ORDER BY sort_order,name`)
    return rowsToCamel<Branch>(rows)
  },
  async getBySlug(slug: string): Promise<Branch|null> {
    const row=await queryOne<Record<string,unknown>>(`SELECT * FROM branches WHERE slug=$1`,[slug])
    return row?rowsToCamel<Branch>([row])[0]:null
  },
}

export const TopicQueries = {
  async getByBranch(branchSlug: string, withDeps=false): Promise<Topic[]> {
    const rows=await query<Record<string,unknown>>(`SELECT t.*,b.slug AS branch_slug,b.name AS branch_name FROM topics t JOIN branches b ON b.id=t.branch_id WHERE b.slug=$1 AND t.status='published' ORDER BY t.level,t.difficulty`,[branchSlug])
    const topics=rowsToCamel<Topic>(rows)
    if(!withDeps||topics.length===0)return topics
    const ids=topics.map(t=>t.id)
    const [deps,res]=await Promise.all([
      query<Record<string,unknown>>(`SELECT * FROM topic_dependencies WHERE topic_id=ANY($1::uuid[])`,[ids]),
      query<Record<string,unknown>>(`SELECT * FROM topic_resources WHERE topic_id=ANY($1::uuid[]) ORDER BY sort_order`,[ids]),
    ])
    const depMap=new Map<string,unknown[]>();for(const d of rowsToCamel(deps)){const td=d as Record<string,unknown>;(depMap.get(td.topicId as string)??depMap.set(td.topicId as string,[]).get(td.topicId as string)!).push(d)}
    const resMap=new Map<string,unknown[]>();for(const r of res){const tr=r as Record<string,unknown>;const tid=tr.topic_id as string;(resMap.get(tid)??resMap.set(tid,[]).get(tid)!).push(r)}
    return topics.map(t=>({...t,dependencies:depMap.get(t.id)??[],resources:rowsToCamel(resMap.get(t.id)??[])}))
  },
  async getBySlug(slug: string): Promise<Topic|null> {
    const rows=await query<Record<string,unknown>>(`SELECT t.*,b.slug AS branch_slug,b.name AS branch_name FROM topics t JOIN branches b ON b.id=t.branch_id WHERE t.slug=$1 AND t.status='published'`,[slug])
    if(!rows[0])return null
    const topic=rowsToCamel<Topic>(rows)[0]
    const[deps,resources]=await Promise.all([query<Record<string,unknown>>(`SELECT * FROM topic_dependencies WHERE topic_id=$1`,[topic.id]),query<Record<string,unknown>>(`SELECT * FROM topic_resources WHERE topic_id=$1 ORDER BY quality DESC`,[topic.id])])
    return{...topic,dependencies:rowsToCamel(deps),resources:rowsToCamel(resources)}
  },
  async search(q: string, limit=20): Promise<SearchResult[]> {
    const rows=await query<Record<string,unknown>>(`SELECT t.id AS topic_id,t.slug AS topic_slug,t.name AS topic_name,b.slug AS branch_slug,b.name AS branch_name,t.description,t.rarity_tier,t.difficulty_tier,ts_rank(t.search_vector,plainto_tsquery('english',$1)) AS rank FROM topics t JOIN branches b ON b.id=t.branch_id WHERE t.status='published' AND (t.search_vector@@plainto_tsquery('english',$1) OR t.name ILIKE $2) ORDER BY rank DESC,t.difficulty LIMIT $3`,[q,`%${q}%`,limit])
    return rowsToCamel<SearchResult>(rows)
  },
}

export const ProgressQueries = {
  async getUserProgress(userId: string): Promise<UserProgress[]> {
    const rows=await query<Record<string,unknown>>(`SELECT up.*,t.name AS topic_name,t.slug AS topic_slug,t.rarity_tier,b.slug AS branch_slug,b.name AS branch_name FROM user_progress up JOIN topics t ON t.id=up.topic_id JOIN branches b ON b.id=t.branch_id WHERE up.user_id=$1 ORDER BY up.updated_at DESC`,[userId])
    return rowsToCamel<UserProgress>(rows)
  },
  async getRecentProgress(userId: string, limit=10): Promise<UserProgress[]> {
    const rows=await query<Record<string,unknown>>(`SELECT up.*,t.name AS topic_name,t.slug AS topic_slug,t.rarity_tier,b.slug AS branch_slug,b.name AS branch_name FROM user_progress up JOIN topics t ON t.id=up.topic_id JOIN branches b ON b.id=t.branch_id WHERE up.user_id=$1 AND up.status IN('learned','reviewing') ORDER BY up.updated_at DESC LIMIT $2`,[userId,limit])
    return rowsToCamel<UserProgress>(rows)
  },
  async getBranchProgress(userId: string): Promise<BranchProgress[]> {
    const rows=await query<Record<string,unknown>>(`SELECT b.slug AS branch_slug,b.name AS branch_name,b.domain,COUNT(t.id)::int AS topics_total,COUNT(up.topic_id)FILTER(WHERE up.status IN('learned','reviewing'))::int AS topics_learned,ROUND(COUNT(up.topic_id)FILTER(WHERE up.status IN('learned','reviewing'))::numeric/NULLIF(COUNT(t.id),0)*100,1) AS pct_complete FROM branches b JOIN topics t ON t.branch_id=b.id AND t.status='published' LEFT JOIN user_progress up ON up.topic_id=t.id AND up.user_id=$1 WHERE b.is_published=true GROUP BY b.id,b.slug,b.name,b.domain ORDER BY pct_complete DESC NULLS LAST`,[userId])
    return rowsToCamel<BranchProgress>(rows)
  },
  async markTopic(userId: string, topicId: string, status: string): Promise<UserProgress> {
    const topic=await queryOne<{xp_base:number;rarity_tier:string}>(`SELECT xp_base,rarity_tier FROM topics WHERE id=$1`,[topicId])
    if(!topic)throw new Error('Topic not found')
    const xpEarned=status==='learned'||status==='reviewing'?topic.xp_base:0
    const rows=await query<Record<string,unknown>>(`INSERT INTO user_progress(user_id,topic_id,status,xp_earned)VALUES($1,$2,$3,$4)ON CONFLICT(user_id,topic_id)DO UPDATE SET status=$3,xp_earned=CASE WHEN $3 IN('learned','reviewing') THEN $4 ELSE 0 END,updated_at=NOW(),attempts=user_progress.attempts+1 RETURNING *`,[userId,topicId,status,xpEarned])
    if(xpEarned>0)await execute(`INSERT INTO xp_events(user_id,amount,source,source_id,description)VALUES($1,$2,'topic_learned',$3,'Learned topic')`,[userId,xpEarned,topicId])
    await UserQueries.updateStreak(userId)
    await BadgeQueries.checkAndAwardBadges(userId).catch(()=>{})
    return rowsToCamel<UserProgress>(rows)[0]
  },
}

export const BadgeQueries = {
  async getAllBadges(): Promise<Badge[]> {
    const rows=await query<Record<string,unknown>>(`SELECT * FROM badges WHERE is_active=true ORDER BY sort_order`)
    return rowsToCamel<Badge>(rows)
  },
  async getUserBadges(userId: string): Promise<UserBadge[]> {
    const rows=await query<Record<string,unknown>>(`SELECT ub.*,b.slug,b.name,b.description,b.icon,b.rarity,b.xp_reward FROM user_badges ub JOIN badges b ON b.id=ub.badge_id WHERE ub.user_id=$1 ORDER BY ub.earned_at DESC`,[userId])
    return rowsToCamel<UserBadge>(rows)
  },
  async checkAndAwardBadges(userId: string): Promise<void> {
    const user=await queryOne<Record<string,unknown>>(`SELECT total_xp,topics_learned,rare_topics_count,current_streak,current_level FROM users WHERE id=$1`,[userId])
    if(!user)return
    const allBadges=await BadgeQueries.getAllBadges()
    const earned=new Set((await BadgeQueries.getUserBadges(userId)).map(ub=>ub.badgeId))
    for(const badge of allBadges){
      if(earned.has(badge.id))continue
      let q=false;const tv=badge.triggerValue
      switch(badge.triggerType){
        case'topic_count':q=Number(user.topics_learned)>=Number(tv.count??0);break
        case'xp_threshold':q=Number(user.total_xp)>=Number(tv.xp??0);break
        case'streak':q=Number(user.current_streak)>=Number(tv.days??0);break
        case'rare_topic':if(tv.rarity==='rare')q=Number(user.rare_topics_count)>=1;break
        case'level_up':q=user.current_level===tv.level;break
      }
      if(q){
        await execute(`INSERT INTO user_badges(user_id,badge_id)VALUES($1,$2)ON CONFLICT DO NOTHING`,[userId,badge.id])
        if(badge.xpReward>0)await execute(`INSERT INTO xp_events(user_id,amount,source,source_id,description)VALUES($1,$2,'badge',$3,$4)`,[userId,badge.xpReward,badge.id,`Badge: ${badge.name}`])
        await execute(`UPDATE users SET badges_count=(SELECT COUNT(*) FROM user_badges WHERE user_id=$1) WHERE id=$1`,[userId])
      }
    }
  },
}

export const RankingQueries = {
  async getLeaderboard(period: 'monthly'|'alltime', limit=50, currentUserId?: string): Promise<LeaderboardEntry[]> {
    if(period==='monthly'){
      const rows=await query<Record<string,unknown>>(`SELECT *,($1::uuid IS NOT NULL AND user_id=$1) AS is_current_user FROM v_leaderboard_current_month ORDER BY rank LIMIT $2`,[currentUserId??null,limit])
      return rowsToCamel<LeaderboardEntry>(rows)
    }
    const rows=await query<Record<string,unknown>>(`SELECT u.id AS user_id,u.username,u.display_name,u.current_level,u.total_xp,u.topics_learned,u.rare_topics_count,u.current_streak,u.monthly_score,RANK()OVER(ORDER BY u.total_xp DESC)::int AS rank,($1::uuid IS NOT NULL AND u.id=$1) AS is_current_user FROM users u WHERE u.deleted_at IS NULL AND u.is_banned=false AND u.is_public=true ORDER BY u.total_xp DESC LIMIT $2`,[currentUserId??null,limit])
    return rowsToCamel<LeaderboardEntry>(rows)
  },
}

export const AnalyticsQueries = {
  async getRadarData(userId: string) {
    const rows=await query<Record<string,unknown>>(`SELECT b.domain,COUNT(t.id)::int AS topics_total,COUNT(up.topic_id)FILTER(WHERE up.status IN('learned','reviewing'))::int AS topics_learned,ROUND(COUNT(up.topic_id)FILTER(WHERE up.status IN('learned','reviewing'))::numeric/NULLIF(COUNT(t.id),0)*100) AS score FROM branches b JOIN topics t ON t.branch_id=b.id AND t.status='published' LEFT JOIN user_progress up ON up.topic_id=t.id AND up.user_id=$1 WHERE b.is_published=true GROUP BY b.domain ORDER BY b.domain`,[userId])
    const labels:Record<string,string>={hardware:'Hardware',firmware:'Firmware',system:'Systems',specialization:'Specialization',industry:'Industry'}
    return rows.map(r=>({domain:r.domain as string,label:labels[r.domain as string]??r.domain as string,score:Number(r.score??0),maxScore:100,topicsLearned:Number(r.topics_learned),topicsTotal:Number(r.topics_total)}))
  },
  async getXpHistory(userId: string, days=30) {
    const rows=await query<Record<string,unknown>>(`SELECT DATE(created_at) AS date,SUM(amount)::int AS xp FROM xp_events WHERE user_id=$1 AND created_at>=NOW()-INTERVAL '${days} days' GROUP BY DATE(created_at) ORDER BY date`,[userId])
    return rowsToCamel<{date:string;xp:number}>(rows)
  },
  async getHeatmap(userId: string) {
    const rows=await query<Record<string,unknown>>(`SELECT b.slug AS branch_slug,b.name AS branch_name,b.domain,b.color,COUNT(t.id)::int AS topics_total,COUNT(up.topic_id)FILTER(WHERE up.status IN('learned','reviewing'))::int AS topics_learned,ROUND(COUNT(up.topic_id)FILTER(WHERE up.status IN('learned','reviewing'))::numeric/NULLIF(COUNT(t.id),0)*100,1) AS pct_complete FROM branches b JOIN topics t ON t.branch_id=b.id AND t.status='published' LEFT JOIN user_progress up ON up.topic_id=t.id AND up.user_id=$1 WHERE b.is_published=true GROUP BY b.id,b.slug,b.name,b.domain,b.color ORDER BY pct_complete DESC NULLS LAST`,[userId])
    return rowsToCamel<{branchSlug:string;branchName:string;domain:string;color:string;topicsTotal:number;topicsLearned:number;pctComplete:number}>(rows)
  },
  async getTopSkills(userId: string, limit=15) {
    const rows=await query<Record<string,unknown>>(`SELECT t.name,t.rarity_tier,b.name AS branch_name,up.xp_earned FROM user_progress up JOIN topics t ON t.id=up.topic_id JOIN branches b ON b.id=t.branch_id WHERE up.user_id=$1 AND up.status IN('learned','reviewing') ORDER BY CASE t.rarity_tier WHEN 'legendary' THEN 1 WHEN 'elite' THEN 2 WHEN 'rare' THEN 3 WHEN 'uncommon' THEN 4 WHEN 'common' THEN 5 ELSE 6 END,up.xp_earned DESC LIMIT $2`,[userId,limit])
    return rowsToCamel<{name:string;rarityTier:string;branchName:string;xpEarned:number}>(rows)
  },
}
