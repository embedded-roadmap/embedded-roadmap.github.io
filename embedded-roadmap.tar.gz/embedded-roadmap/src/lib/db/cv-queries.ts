// src/lib/db/cv-queries.ts
// Data access layer for CV, Projects, Privacy Settings

import { query, queryOne, execute, transaction, rowsToCamel } from './index'
import type {
  EngineerCv, CvEducation, CvExperience, CvProject, CvCertification,
  CvPublication, CvPatent, CvAward, CvReference, UserPrivacySettings,
  OpenToWorkStatus, RecruiterProfile, CvTemplateId
} from '@/types'
import { nanoid } from 'nanoid'

// ══════════════════════════════════════════════════════════════
//  ENGINEER CV
// ══════════════════════════════════════════════════════════════

export const CvQueries = {

  /** Get or create a user's CV record */
  async getOrCreate(userId: string): Promise<EngineerCv> {
    const existing = await CvQueries.getByUserId(userId)
    if (existing) return existing

    const rows = await query<Record<string, unknown>>(
      `INSERT INTO engineer_cvs (user_id) VALUES ($1)
       ON CONFLICT (user_id) DO NOTHING
       RETURNING *`, [userId])

    return rows[0]
      ? rowsToCamel<EngineerCv>(rows)[0]
      : (await CvQueries.getByUserId(userId))!
  },

  async getByUserId(userId: string): Promise<EngineerCv | null> {
    const row = await queryOne<Record<string, unknown>>(
      `SELECT * FROM engineer_cvs WHERE user_id = $1`, [userId])
    return row ? rowsToCamel<EngineerCv>([row])[0] : null
  },

  async getByShareToken(token: string): Promise<EngineerCv | null> {
    const row = await queryOne<Record<string, unknown>>(
      `SELECT c.*, u.username, u.display_name, u.avatar_url, u.total_xp,
              u.current_level, u.global_percentile, u.topics_learned, u.rare_topics_count
       FROM engineer_cvs c
       JOIN users u ON u.id = c.user_id
       WHERE c.share_token = $1 AND c.share_enabled = true`, [token])
    return row ? rowsToCamel<EngineerCv>([row])[0] : null
  },

  /** Full CV including all nested sections */
  async getFullCv(userId: string): Promise<Record<string, unknown> | null> {
    const row = await queryOne<{ get_full_cv: Record<string, unknown> }>(
      `SELECT get_full_cv($1)`, [userId])
    return row?.get_full_cv ?? null
  },

  async updatePersonal(userId: string, data: Partial<{
    fullName: string; title: string; email: string; phone: string;
    location: string; summary: string; openToWork: OpenToWorkStatus;
    socialLinks: Record<string, string | null>; templateId: CvTemplateId;
    status: 'draft' | 'published'
  }>): Promise<void> {
    const fieldMap: Record<string, string> = {
      fullName: 'full_name', title: 'title', email: 'email', phone: 'phone',
      location: 'location', summary: 'summary', openToWork: 'open_to_work',
      socialLinks: 'social_links', templateId: 'template_id', status: 'status',
    }

    const sets: string[] = []
    const values: unknown[] = [userId]

    for (const [key, dbCol] of Object.entries(fieldMap)) {
      const val = (data as Record<string, unknown>)[key]
      if (val !== undefined) {
        values.push(typeof val === 'object' ? JSON.stringify(val) : val)
        sets.push(`${dbCol} = $${values.length}`)
      }
    }

    if (sets.length === 0) return

    await execute(
      `UPDATE engineer_cvs SET ${sets.join(', ')} WHERE user_id = $1`, values)

    // Mirror open_to_work to privacy settings
    if (data.openToWork !== undefined) {
      await execute(
        `INSERT INTO user_privacy_settings (user_id, open_to_work) VALUES ($1, $2)
         ON CONFLICT (user_id) DO UPDATE SET open_to_work = $2`,
        [userId, data.openToWork])
    }
  },

  async enableShare(userId: string): Promise<string> {
    const token = nanoid(32)
    await execute(
      `UPDATE engineer_cvs SET share_token = $2, share_enabled = true WHERE user_id = $1`,
      [userId, token])
    return token
  },

  async disableShare(userId: string): Promise<void> {
    await execute(
      `UPDATE engineer_cvs SET share_enabled = false WHERE user_id = $1`, [userId])
  },

  async markGenerated(userId: string): Promise<void> {
    await execute(
      `UPDATE engineer_cvs SET last_generated_at = NOW() WHERE user_id = $1`, [userId])
  },
}

// ══════════════════════════════════════════════════════════════
//  CV SECTION CRUD — generic helper
// ══════════════════════════════════════════════════════════════

type TableName = 'cv_education' | 'cv_certifications' | 'cv_experience' | 'cv_projects'
  | 'cv_publications' | 'cv_patents' | 'cv_awards' | 'cv_references'
  | 'cv_manual_skills' | 'cv_languages'

async function getCvId(userId: string): Promise<string | null> {
  const row = await queryOne<{ id: string }>(`SELECT id FROM engineer_cvs WHERE user_id = $1`, [userId])
  return row?.id ?? null
}

export const CvSectionQueries = {

  // ── Education ──────────────────────────────────────────────

  async getEducation(userId: string): Promise<CvEducation[]> {
    const cvId = await getCvId(userId)
    if (!cvId) return []
    const rows = await query<Record<string, unknown>>(
      `SELECT * FROM cv_education WHERE cv_id = $1 ORDER BY sort_order, start_year DESC`, [cvId])
    return rowsToCamel<CvEducation>(rows)
  },

  async upsertEducation(userId: string, data: Omit<CvEducation, 'id'> & { id?: string }): Promise<CvEducation> {
    const cvId = await getCvId(userId)
    if (!cvId) throw new Error('No CV record')
    const { id, institution, degree, field, startYear, endYear, gpa, honors, relevant_courses } = data as Record<string, unknown>
    const rows = await query<Record<string, unknown>>(
      `INSERT INTO cv_education (id, cv_id, institution, degree, field, start_year, end_year, gpa, honors, relevant_courses)
       VALUES (COALESCE($1::uuid, uuid_generate_v4()), $2, $3, $4, $5, $6, $7, $8, $9, $10)
       ON CONFLICT (id) DO UPDATE SET
         institution=$3, degree=$4, field=$5, start_year=$6, end_year=$7, gpa=$8, honors=$9, relevant_courses=$10
       RETURNING *`,
      [id ?? null, cvId, institution, degree, field, startYear, endYear, gpa, honors, relevant_courses ?? []])
    return rowsToCamel<CvEducation>(rows)[0]
  },

  // ── Certifications ─────────────────────────────────────────

  async getCertifications(userId: string): Promise<CvCertification[]> {
    const cvId = await getCvId(userId)
    if (!cvId) return []
    const rows = await query<Record<string, unknown>>(
      `SELECT * FROM cv_certifications WHERE cv_id = $1 ORDER BY issued_date DESC`, [cvId])
    return rowsToCamel<CvCertification>(rows)
  },

  async upsertCertification(userId: string, data: Partial<CvCertification>): Promise<CvCertification> {
    const cvId = await getCvId(userId)
    if (!cvId) throw new Error('No CV record')
    const rows = await query<Record<string, unknown>>(
      `INSERT INTO cv_certifications (id, cv_id, name, issuer, issued_date, expiry_date, credential_id, url)
       VALUES (COALESCE($1::uuid, uuid_generate_v4()), $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (id) DO UPDATE SET name=$3, issuer=$4, issued_date=$5, expiry_date=$6, credential_id=$7, url=$8
       RETURNING *`,
      [data.id ?? null, cvId, data.name, data.issuer, data.issuedDate, data.expiryDate, data.credentialId, data.url])
    return rowsToCamel<CvCertification>(rows)[0]
  },

  // ── Work Experience ────────────────────────────────────────

  async getExperience(userId: string): Promise<CvExperience[]> {
    const cvId = await getCvId(userId)
    if (!cvId) return []
    const rows = await query<Record<string, unknown>>(
      `SELECT * FROM cv_experience WHERE cv_id = $1 ORDER BY is_current DESC, start_date DESC`, [cvId])
    return rowsToCamel<CvExperience>(rows)
  },

  async upsertExperience(userId: string, data: Partial<CvExperience>): Promise<CvExperience> {
    const cvId = await getCvId(userId)
    if (!cvId) throw new Error('No CV record')
    const rows = await query<Record<string, unknown>>(
      `INSERT INTO cv_experience (id, cv_id, company, title, location, start_date, end_date, is_current, description, highlights, tech_stack, domains)
       VALUES (COALESCE($1::uuid, uuid_generate_v4()), $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       ON CONFLICT (id) DO UPDATE SET
         company=$3, title=$4, location=$5, start_date=$6, end_date=$7, is_current=$8,
         description=$9, highlights=$10, tech_stack=$11, domains=$12
       RETURNING *`,
      [data.id ?? null, cvId, data.company, data.title, data.location,
       data.startDate, data.endDate, data.isCurrent ?? false,
       data.description, data.highlights ?? [], data.techStack ?? [], data.domains ?? []])
    return rowsToCamel<CvExperience>(rows)[0]
  },

  // ── Delete any section item ────────────────────────────────

  async deleteItem(table: TableName, id: string, userId: string): Promise<boolean> {
    // Security: verify ownership through cv_id → user_id join
    if (table === 'cv_projects') {
      const result = await execute(`DELETE FROM cv_projects WHERE id = $1 AND user_id = $2`, [id, userId])
      return (result.rowCount ?? 0) > 0
    }
    const result = await execute(
      `DELETE FROM ${table} t
       USING engineer_cvs c
       WHERE t.id = $1 AND t.cv_id = c.id AND c.user_id = $2`, [id, userId])
    return (result.rowCount ?? 0) > 0
  },
}

// ══════════════════════════════════════════════════════════════
//  PROJECTS
// ══════════════════════════════════════════════════════════════

export const ProjectQueries = {

  async getByUser(userId: string): Promise<CvProject[]> {
    const rows = await query<Record<string, unknown>>(
      `SELECT * FROM cv_projects WHERE user_id = $1 AND is_public = true
       ORDER BY is_featured DESC, start_date DESC NULLS LAST`, [userId])
    return rowsToCamel<CvProject>(rows)
  },

  async upsert(userId: string, data: Partial<CvProject>): Promise<CvProject> {
    const cvId = await getCvId(userId)
    const rows = await query<Record<string, unknown>>(
      `INSERT INTO cv_projects (id, user_id, cv_id, title, description, tech_stack, hardware_stack,
         firmware_stack, related_topic_slugs, repo_url, project_url, platform, image_url, video_url,
         is_featured, is_public, start_date, end_date)
       VALUES (COALESCE($1::uuid, uuid_generate_v4()), $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
       ON CONFLICT (id) DO UPDATE SET
         title=$4, description=$5, tech_stack=$6, hardware_stack=$7, firmware_stack=$8,
         related_topic_slugs=$9, repo_url=$10, project_url=$11, platform=$12, image_url=$13,
         video_url=$14, is_featured=$15, is_public=$16, start_date=$17, end_date=$18, updated_at=NOW()
       RETURNING *`,
      [data.id ?? null, userId, cvId ?? null, data.title, data.description,
       data.techStack ?? [], data.hardwareStack ?? [], data.firmwareStack ?? [],
       data.relatedTopicSlugs ?? [], data.repoUrl, data.projectUrl,
       data.platform ?? 'github', data.imageUrl, data.videoUrl,
       data.isFeatured ?? false, data.isFeatured !== false,
       data.startDate, data.endDate])
    return rowsToCamel<CvProject>(rows)[0]
  },
}

// ══════════════════════════════════════════════════════════════
//  PRIVACY SETTINGS
// ══════════════════════════════════════════════════════════════

export const PrivacyQueries = {

  async get(userId: string): Promise<UserPrivacySettings> {
    const row = await queryOne<Record<string, unknown>>(
      `INSERT INTO user_privacy_settings (user_id) VALUES ($1)
       ON CONFLICT (user_id) DO NOTHING;
       SELECT * FROM user_privacy_settings WHERE user_id = $1`, [userId])
    // Handle the multi-statement return
    const rows = await query<Record<string, unknown>>(
      `SELECT * FROM user_privacy_settings WHERE user_id = $1`, [userId])
    if (rows.length === 0) {
      await execute(`INSERT INTO user_privacy_settings (user_id) VALUES ($1) ON CONFLICT DO NOTHING`, [userId])
      return PrivacyQueries.get(userId)
    }
    return rowsToCamel<UserPrivacySettings>(rows)[0]
  },

  async update(userId: string, data: Partial<UserPrivacySettings>): Promise<void> {
    const fieldMap: Record<string, string> = {
      isPublic: 'is_public', showPercentile: 'show_percentile', showXp: 'show_xp',
      showSalaryEstimates: 'show_salary_estimates', showStreak: 'show_streak',
      showBadges: 'show_badges', showProjects: 'show_projects',
      allowRecruiterView: 'allow_recruiter_view', openToWork: 'open_to_work',
    }

    const sets: string[] = []
    const values: unknown[] = [userId]

    for (const [key, col] of Object.entries(fieldMap)) {
      const val = (data as Record<string, unknown>)[key]
      if (val !== undefined) {
        values.push(val)
        sets.push(`${col} = $${values.length}`)
      }
    }

    if (sets.length === 0) return

    await execute(
      `INSERT INTO user_privacy_settings (user_id, ${sets.map(s => s.split(' = ')[0]).join(', ')})
       VALUES ($1, ${values.slice(1).map((_, i) => `$${i + 2}`).join(', ')})
       ON CONFLICT (user_id) DO UPDATE SET ${sets.join(', ')}`,
      values)

    // Sync is_public to users table
    if (data.isPublic !== undefined) {
      await execute(`UPDATE users SET is_public = $2 WHERE id = $1`, [userId, data.isPublic])
    }
  },

  async requestDataExport(userId: string): Promise<void> {
    await execute(
      `UPDATE user_privacy_settings SET gdpr_data_export_requested = true WHERE user_id = $1`, [userId])
  },

  async requestAccountDeletion(userId: string): Promise<void> {
    await execute(
      `UPDATE user_privacy_settings SET gdpr_delete_requested = true WHERE user_id = $1`, [userId])
    // Soft-delete the user account after 30 days (handled by cron)
    await execute(
      `UPDATE users SET deleted_at = NOW() + INTERVAL '30 days' WHERE id = $1`, [userId])
  },
}

// ══════════════════════════════════════════════════════════════
//  RECRUITER PROFILE BUILDER
// ══════════════════════════════════════════════════════════════

export const RecruiterQueries = {

  async buildProfile(username: string): Promise<RecruiterProfile | null> {
    // Get user + privacy check
    const userRow = await queryOne<Record<string, unknown>>(
      `SELECT u.*, ep.headline, ep.current_role, ep.expertise_areas, ep.country_code,
              ep.years_experience, ep.current_company, ep.target_role
       FROM users u
       LEFT JOIN engineer_profiles ep ON ep.user_id = u.id
       LEFT JOIN user_privacy_settings ps ON ps.user_id = u.id
       WHERE u.username = $1 AND u.deleted_at IS NULL AND u.is_banned = false
         AND (ps.allow_recruiter_view = true OR ps.allow_recruiter_view IS NULL)`,
      [username])

    if (!userRow) return null

    const userId = userRow.id as string

    // Get privacy settings
    const privacy = await query<Record<string, unknown>>(
      `SELECT * FROM user_privacy_settings WHERE user_id = $1`, [userId])
    const ps = privacy[0] ? rowsToCamel<UserPrivacySettings>([privacy[0]])[0] : null

    // Get CV
    const cvRow = await queryOne<Record<string, unknown>>(
      `SELECT * FROM engineer_cvs WHERE user_id = $1`, [userId])

    // Get top skills (rarest topics learned)
    const topSkillsRows = await query<Record<string, unknown>>(
      `SELECT t.name, t.rarity_tier, up.xp_earned
       FROM user_progress up
       JOIN topics t ON t.id = up.topic_id
       WHERE up.user_id = $1 AND up.status = 'learned'
       ORDER BY
         CASE t.rarity_tier
           WHEN 'legendary' THEN 1 WHEN 'elite' THEN 2 WHEN 'rare' THEN 3
           WHEN 'uncommon' THEN 4 WHEN 'common' THEN 5 ELSE 6
         END,
         up.xp_earned DESC
       LIMIT 15`, [userId])

    // Branch heatmap
    const heatmapRows = await query<Record<string, unknown>>(
      `SELECT * FROM v_branch_progress WHERE user_id = $1 ORDER BY pct_complete DESC LIMIT 12`, [userId])

    // Radar data (by domain)
    const radarRows = await query<Record<string, unknown>>(
      `SELECT b.domain,
         COUNT(up.topic_id)::int AS learned,
         COUNT(t.id)::int AS total
       FROM branches b
       LEFT JOIN topics t ON t.branch_id = b.id AND t.status = 'published'
       LEFT JOIN user_progress up ON up.topic_id = t.id AND up.user_id = $1 AND up.status = 'learned'
       GROUP BY b.domain
       ORDER BY b.domain`, [userId])

    // Projects
    const projectRows = await query<Record<string, unknown>>(
      `SELECT * FROM cv_projects
       WHERE user_id = $1 AND is_public = true AND (is_featured = true OR TRUE)
       ORDER BY is_featured DESC, start_date DESC LIMIT 8`, [userId])

    // Open to work badge
    const openToWork = (cvRow?.open_to_work as OpenToWorkStatus) ?? 'not_looking'

    const user = rowsToCamel<Record<string, unknown>>([userRow])[0]

    return {
      user: user as unknown as import('@/types').PublicUser,
      cv: cvRow ? rowsToCamel<EngineerCv>([cvRow])[0] : null,
      topSkills: rowsToCamel<{ name: string; rarity: import('@/types').RarityTier; xpEarned: number }>(topSkillsRows),
      radarData: radarRows.map(r => ({
        domain: r.domain as string,
        score: Math.round((Number(r.learned) / Math.max(Number(r.total), 1)) * 100),
        maxScore: 100,
      })),
      specializationHeatmap: heatmapRows.map(r => ({
        branch: r.branch_slug as string,
        pct: Number(r.pct_complete),
        topicCount: Number(r.topics_learned),
      })),
      openToWork,
      projects: rowsToCamel<CvProject>(projectRows),
      stats: {
        totalXp: ps?.showXp !== false ? Number(userRow.total_xp) : 0,
        globalPercentile: ps?.showPercentile !== false ? Number(userRow.global_percentile) : 0,
        topicsLearned: Number(userRow.topics_learned),
        rareSkills: Number(userRow.rare_topics_count),
        badgesEarned: 0,  // populated separately if needed
        currentStreak: ps?.showStreak !== false ? Number(userRow.current_streak) : 0,
        longestStreak: ps?.showStreak !== false ? Number(userRow.longest_streak) : 0,
      },
    }
  },
}
