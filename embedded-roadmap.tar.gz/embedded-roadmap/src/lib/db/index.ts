// src/lib/db/index.ts
// Production PostgreSQL connection pool with query helpers

import { Pool, PoolClient, QueryResult, QueryResultRow } from 'pg'

declare global {
  // Prevent multiple pool instances in dev (hot reload)
  var _pgPool: Pool | undefined
}

function createPool(): Pool {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 20,                  // max connections in pool
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000,
    ssl: process.env.NODE_ENV === 'production'
      ? { rejectUnauthorized: false }
      : false,
  })

  pool.on('error', (err) => {
    console.error('[DB Pool] Unexpected error on idle client:', err.message)
  })

  pool.on('connect', () => {
    if (process.env.NODE_ENV === 'development') {
      console.log('[DB] New client connected')
    }
  })

  return pool
}

// Singleton pool — reuse across hot reloads in dev
export const pool =
  process.env.NODE_ENV === 'development'
    ? (global._pgPool ??= createPool())
    : createPool()

if (process.env.NODE_ENV === 'development') {
  global._pgPool = pool
}

// ── Query helpers ────────────────────────────────────────────

/** Execute a query and return typed rows */
export async function query<T extends QueryResultRow = QueryResultRow>(
  sql: string,
  params?: unknown[]
): Promise<T[]> {
  const start = Date.now()
  try {
    const res: QueryResult<T> = await pool.query(sql, params)
    if (process.env.NODE_ENV === 'development') {
      const dur = Date.now() - start
      if (dur > 200) console.warn(`[DB] Slow query (${dur}ms):`, sql.slice(0, 80))
    }
    return res.rows
  } catch (err: unknown) {
    console.error('[DB] Query error:', (err as Error).message, '\nSQL:', sql.slice(0, 200))
    throw err
  }
}

/** Execute and return the first row, or null */
export async function queryOne<T extends QueryResultRow = QueryResultRow>(
  sql: string,
  params?: unknown[]
): Promise<T | null> {
  const rows = await query<T>(sql, params)
  return rows[0] ?? null
}

/** Execute a query with no return value */
export async function execute(sql: string, params?: unknown[]): Promise<QueryResult> {
  return pool.query(sql, params)
}

/** Run multiple queries in a single transaction */
export async function transaction<T>(
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const result = await fn(client)
    await client.query('COMMIT')
    return result
  } catch (err) {
    await client.query('ROLLBACK')
    throw err
  } finally {
    client.release()
  }
}

// ── Utility: snake_case row → camelCase ──────────────────────

export function toCamel(row: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const key of Object.keys(row)) {
    const camel = key.replace(/_([a-z])/g, (_, c) => c.toUpperCase())
    out[camel] = row[key]
  }
  return out
}

export function rowsToCamel<T>(rows: Record<string, unknown>[]): T[] {
  return rows.map(toCamel) as T[]
}

/** Build a parameterized WHERE IN clause */
export function inClause(arr: string[], startIdx = 1): { clause: string; params: string[] } {
  const params = arr.map((v, i) => `$${i + startIdx}`)
  return { clause: `(${params.join(',')})`, params: arr }
}

/** Paginated query helper */
export function paginationClause(page: number, pageSize: number): { limit: number; offset: number; clause: string } {
  const safeSize = Math.min(Math.max(pageSize, 1), 100)
  const safePage = Math.max(page, 1)
  const offset = (safePage - 1) * safeSize
  return { limit: safeSize, offset, clause: `LIMIT ${safeSize} OFFSET ${offset}` }
}

// ── Health check ─────────────────────────────────────────────

export async function dbHealth(): Promise<{ ok: boolean; latencyMs: number }> {
  const start = Date.now()
  try {
    await pool.query('SELECT 1')
    return { ok: true, latencyMs: Date.now() - start }
  } catch {
    return { ok: false, latencyMs: -1 }
  }
}
