// src/stores/roadmap.ts
import { create } from 'zustand'
import type { Branch, Topic, RoadmapNode, RoadmapEdge } from '@/types'
import type { Node, Edge } from 'reactflow'

interface RoadmapState {
  branches: Branch[]
  activeBranchSlug: string | null
  topics: Topic[]
  nodes: Node[]
  edges: Edge[]
  selectedTopicId: string | null
  loading: boolean
  // Actions
  fetchBranches: () => Promise<void>
  loadBranch: (slug: string) => Promise<void>
  selectTopic: (id: string | null) => void
  getSelectedTopic: () => Topic | null
}

function buildReactFlowGraph(topics: Topic[]): { nodes: Node[]; edges: Edge[] } {
  // Assign positions using a layered layout
  // Group by level (1–7)
  const byLevel: Record<number, Topic[]> = {}
  for (const t of topics) {
    const lvl = t.level ?? 1
    ;(byLevel[lvl] ??= []).push(t)
  }

  const LEVEL_GAP_X = 260
  const NODE_GAP_Y = 100
  const NODE_WIDTH = 220

  const nodes: Node[] = []
  const positionMap: Record<string, { x: number; y: number }> = {}

  for (const [lvlStr, group] of Object.entries(byLevel)) {
    const lvl = parseInt(lvlStr)
    const x = (lvl - 1) * LEVEL_GAP_X
    const totalHeight = group.length * NODE_GAP_Y
    const startY = -totalHeight / 2

    group.forEach((topic, i) => {
      const pos = { x, y: startY + i * NODE_GAP_Y }
      positionMap[topic.id] = pos
      nodes.push({
        id: topic.id,
        type: 'topicNode',
        position: pos,
        data: { topic },
        style: { width: NODE_WIDTH },
      })
    })
  }

  // Build edges from dependencies
  const edges: Edge[] = []
  for (const topic of topics) {
    for (const dep of (topic.dependencies ?? [])) {
      if (positionMap[dep.prerequisiteId]) {
        edges.push({
          id: `${dep.prerequisiteId}-${topic.id}`,
          source: dep.prerequisiteId,
          target: topic.id,
          type: 'smoothstep',
          animated: false,
          style: { stroke: 'rgba(56,189,248,0.2)', strokeWidth: 1.5 },
        })
      }
    }
  }

  return { nodes, edges }
}

export const useRoadmapStore = create<RoadmapState>()((set, get) => ({
  branches: [],
  activeBranchSlug: null,
  topics: [],
  nodes: [],
  edges: [],
  selectedTopicId: null,
  loading: false,

  async fetchBranches() {
    try {
      const res = await fetch('/api/branches')
      const { data } = await res.json()
      if (data?.branches) set({ branches: data.branches })
    } catch (e) { console.error('fetchBranches', e) }
  },

  async loadBranch(slug) {
    set({ loading: true, activeBranchSlug: slug, selectedTopicId: null })
    try {
      const res = await fetch(`/api/branches/${slug}`)
      const { data } = await res.json()
      if (data?.topics) {
        const { nodes, edges } = buildReactFlowGraph(data.topics)
        set({ topics: data.topics, nodes, edges, loading: false })
      }
    } catch (e) {
      console.error('loadBranch', e)
      set({ loading: false })
    }
  },

  selectTopic: (id) => set({ selectedTopicId: id }),

  getSelectedTopic: () => {
    const { topics, selectedTopicId } = get()
    return topics.find(t => t.id === selectedTopicId) ?? null
  },
}))
