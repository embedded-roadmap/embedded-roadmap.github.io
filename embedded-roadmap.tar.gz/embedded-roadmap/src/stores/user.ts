// src/stores/user.ts
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User } from '@/types'

interface UserState {
  profile: User | null
  loading: boolean
  lastFetched: number | null
  fetchProfile: () => Promise<void>
  updateProfile: (data: Partial<User>) => Promise<void>
  clearProfile: () => void
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      profile: null,
      loading: false,
      lastFetched: null,

      async fetchProfile() {
        if (get().loading) return
        if (get().lastFetched && Date.now() - (get().lastFetched ?? 0) < 30_000) return
        set({ loading: true })
        try {
          const res = await fetch('/api/users/me')
          const { data } = await res.json()
          if (data?.user) set({ profile: data.user, lastFetched: Date.now() })
        } catch (e) { console.error('fetchProfile', e) }
        finally { set({ loading: false }) }
      },

      async updateProfile(updates: Partial<User>) {
        set(state => ({ profile: state.profile ? { ...state.profile, ...updates } : null }))
        try {
          const res = await fetch('/api/users/me', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates),
          })
          const { data } = await res.json()
          if (data?.user) set({ profile: data.user, lastFetched: Date.now() })
        } catch (e) { console.error('updateProfile', e) }
      },

      clearProfile: () => set({ profile: null, lastFetched: null }),
    }),
    {
      name: 'er-user',
      partialize: (state) => ({ profile: state.profile, lastFetched: state.lastFetched }),
    }
  )
)
