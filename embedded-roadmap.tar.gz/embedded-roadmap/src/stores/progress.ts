// src/stores/progress.ts
import { create } from 'zustand'
import { persist, subscribeWithSelector } from 'zustand/middleware'
import type { UserProgress, Topic, Branch } from '@/types'

interface ProgressState {
  // data
  progress: Map<string, UserProgress>       // topicId → progress
  branchProgress: Map<string, { pct: number; learned: number; total: number }>
  lastFetched: number | null
  // actions
  fetchProgress: () => Promise<void>
  markTopic: (topicId: string, status: 'learning' | 'learned' | 'skipped') => Promise<void>
  isLearned: (topicId: string) => boolean
  isLearning: (topicId: string) => boolean
}

export const useProgressStore = create<ProgressState>()(
  subscribeWithSelector(
    persist(
      (set, get) => ({
        progress: new Map(),
        branchProgress: new Map(),
        lastFetched: null,

        async fetchProgress() {
          // Stale-while-revalidate: skip if fetched <60s ago
          if (get().lastFetched && Date.now() - (get().lastFetched ?? 0) < 60_000) return

          try {
            const res = await fetch('/api/progress')
            const { data } = await res.json()
            if (!data?.progress) return

            const map = new Map<string, UserProgress>()
            for (const p of data.progress) map.set(p.topicId, p)

            const branchMap = new Map<string, { pct: number; learned: number; total: number }>()
            for (const b of (data.branchProgress ?? [])) {
              branchMap.set(b.branchSlug, { pct: b.pctComplete ?? 0, learned: b.topicsLearned ?? 0, total: b.topicsTotal ?? 0 })
            }

            set({ progress: map, branchProgress: branchMap, lastFetched: Date.now() })
          } catch (e) { console.error('fetchProgress', e) }
        },

        async markTopic(topicId, status) {
          // Optimistic update
          const prev = get().progress.get(topicId)
          set(state => {
            const m = new Map(state.progress)
            m.set(topicId, { ...prev, topicId, status, updatedAt: new Date().toISOString() } as UserProgress)
            return { progress: m }
          })

          try {
            const res = await fetch('/api/progress', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ topicId, status }),
            })
            const { data } = await res.json()
            if (data?.progress) {
              set(state => {
                const m = new Map(state.progress)
                m.set(topicId, data.progress)
                return { progress: m, lastFetched: null } // invalidate cache
              })
            }
          } catch {
            // Roll back optimistic update
            set(state => {
              const m = new Map(state.progress)
              if (prev) m.set(topicId, prev)
              else m.delete(topicId)
              return { progress: m }
            })
          }
        },

        isLearned:  (topicId) => get().progress.get(topicId)?.status === 'learned',
        isLearning: (topicId) => get().progress.get(topicId)?.status === 'learning',
      }),
      {
        name: 'er-progress',
        // Only persist the Maps as plain objects
        partialize: (state) => ({
          progress: Object.fromEntries(state.progress),
          branchProgress: Object.fromEntries(state.branchProgress),
          lastFetched: state.lastFetched,
        }),
        onRehydrateStorage: () => (state) => {
          if (!state) return
          // Convert plain objects back to Maps
          state.progress = new Map(Object.entries(state.progress ?? {})) as Map<string, UserProgress>
          state.branchProgress = new Map(Object.entries(state.branchProgress ?? {}))
        },
      }
    )
  )
)
