'use client'
// src/app/onboarding/page.tsx — Multi-step onboarding wizard

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Zap, ArrowRight, ChevronLeft, Check } from 'lucide-react'
import { clsx } from 'clsx'

const EXPERIENCE_OPTIONS = [
  { id: 'student',  label: 'Student',        desc: 'Currently studying EE/ECE/related' },
  { id: 'junior',   label: 'Junior (0-2y)',   desc: 'Recent graduate, early career' },
  { id: 'mid',      label: 'Mid-Level (2-5y)', desc: 'Working independently on projects' },
  { id: 'senior',   label: 'Senior (5-10y)',  desc: 'Leading designs, mentoring others' },
  { id: 'lead',     label: 'Lead/Staff (10y+)',desc: 'Principal/Staff/Distinguished level' },
]

const GOAL_OPTIONS = [
  { id: 'career-advancement', label: '📈 Career Advancement', desc: 'Get promoted or switch roles' },
  { id: 'skill-gaps',         label: '🔧 Fill Skill Gaps',    desc: 'Structured learning path' },
  { id: 'specialization',     label: '🎯 Specialization',     desc: 'Deep dive into a domain' },
  { id: 'interview-prep',     label: '💼 Interview Prep',     desc: 'Prepare for technical interviews' },
  { id: 'curiosity',          label: '🧠 Pure Curiosity',     desc: 'Just love learning' },
  { id: 'cv-improvement',     label: '📄 Improve My CV',      desc: 'Benchmark and document skills' },
]

const PATH_OPTIONS = [
  { id: 'analog-electronics',     label: 'Analog Electronics',    icon: '〰️', domain: 'hardware' },
  { id: 'pcb-design',             label: 'PCB Design',            icon: '🔲', domain: 'hardware' },
  { id: 'power-electronics',      label: 'Power Electronics',     icon: '⚡', domain: 'hardware' },
  { id: 'rtos-firmware',          label: 'RTOS & Firmware',       icon: '⏱️', domain: 'firmware' },
  { id: 'embedded-systems',       label: 'Embedded Systems',      icon: '🔧', domain: 'firmware' },
  { id: 'fpga-digital-design',    label: 'FPGA & Digital',        icon: '🖥️', domain: 'system' },
  { id: 'wireless-rf',            label: 'Wireless & RF',         icon: '📡', domain: 'specialization' },
  { id: 'medical-wearables',      label: 'Medical Electronics',   icon: '💊', domain: 'industry' },
  { id: 'automotive-electronics', label: 'Automotive',            icon: '🚗', domain: 'industry' },
  { id: 'dsp-signal-processing',  label: 'DSP',                   icon: '📈', domain: 'system' },
  { id: 'emc-compliance',         label: 'EMC & Compliance',      icon: '🛡️', domain: 'specialization' },
  { id: 'edge-ai-ml',             label: 'Edge AI & ML',          icon: '🧠', domain: 'specialization' },
]

const TOTAL_STEPS = 4

export default function OnboardingPage() {
  const { data: session } = useSession()
  const router = useRouter()

  const [step, setStep] = useState(0)
  const [experience, setExperience] = useState<string | null>(null)
  const [goals, setGoals] = useState<Set<string>>(new Set())
  const [paths, setPaths] = useState<Set<string>>(new Set())
  const [saving, setSaving] = useState(false)

  const save = async (complete = false) => {
    setSaving(true)
    try {
      await fetch('/api/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          step, experience: experience ?? null,
          goals: Array.from(goals), interests: Array.from(paths),
          selectedPaths: Array.from(paths), complete,
        }),
      })
    } catch (e) { console.error(e) }
    setSaving(false)
  }

  const next = async () => {
    await save(false)
    if (step < TOTAL_STEPS - 1) setStep(s => s + 1)
    else {
      await save(true)
      router.push('/dashboard')
    }
  }

  const skip = async () => {
    await save(true)
    router.push('/dashboard')
  }

  const canNext = (
    (step === 0) ||
    (step === 1 && experience !== null) ||
    (step === 2 && goals.size > 0) ||
    (step === 3 && paths.size > 0)
  )

  return (
    <div className="min-h-screen bg-[#060a10] flex items-center justify-center px-4">
      <div className="fixed inset-0 bg-[linear-gradient(rgba(56,189,248,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(56,189,248,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

      <div className="relative w-full max-w-xl">
        {/* Logo + progress */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-cyan to-brand-indigo flex items-center justify-center">
              <Zap className="w-4 h-4 text-[#060a10]" />
            </div>
            <span className="font-display font-bold text-sm text-slate-200">EmbeddedRoadmap</span>
          </div>
          <div className="flex items-center gap-2">
            {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
              <div key={i} className={clsx(
                'h-1.5 rounded-full transition-all',
                i < step ? 'bg-brand-cyan w-6' : i === step ? 'bg-brand-cyan w-8' : 'bg-surface-4 w-4'
              )} />
            ))}
          </div>
        </div>

        {/* Steps */}
        <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.15)] rounded-2xl p-8">

          {/* Step 0: Welcome */}
          {step === 0 && (
            <div className="text-center space-y-4">
              <div className="text-5xl mb-4">⚡</div>
              <h1 className="text-2xl font-display font-bold text-slate-100">
                Welcome{session?.user?.name ? `, ${session.user.name.split(' ')[0]}` : ''}!
              </h1>
              <p className="text-slate-400 leading-relaxed">
                EmbeddedRoadmap tracks your engineering skills, generates your CV automatically,
                and shows you exactly where to focus next.
              </p>
              <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-[rgba(99,179,237,0.1)]">
                {[
                  { icon: '🗺️', label: 'Interactive Roadmaps', desc: '1200+ curated topics' },
                  { icon: '📄', label: 'Auto CV Generation', desc: 'From your progress' },
                  { icon: '🏆', label: 'Global Benchmarking', desc: 'Know where you stand' },
                ].map(f => (
                  <div key={f.label} className="text-center">
                    <div className="text-2xl mb-1">{f.icon}</div>
                    <div className="text-xs font-medium text-slate-200">{f.label}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{f.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 1: Experience */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-display font-bold text-slate-100">What's your experience level?</h2>
                <p className="text-sm text-slate-500 mt-1">This helps us calibrate your roadmap starting point.</p>
              </div>
              <div className="space-y-2">
                {EXPERIENCE_OPTIONS.map(opt => (
                  <button key={opt.id} onClick={() => setExperience(opt.id)}
                    className={clsx(
                      'w-full flex items-center gap-3 p-3.5 rounded-xl border text-left transition-all',
                      experience === opt.id
                        ? 'border-brand-cyan bg-brand-cyan/10'
                        : 'border-[rgba(99,179,237,0.12)] hover:border-[rgba(99,179,237,0.25)] hover:bg-surface-2'
                    )}>
                    <div className={clsx(
                      'w-4 h-4 rounded-full border flex items-center justify-center shrink-0',
                      experience === opt.id ? 'border-brand-cyan bg-brand-cyan' : 'border-slate-600'
                    )}>
                      {experience === opt.id && <Check className="w-2.5 h-2.5 text-[#060a10]" />}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-slate-200">{opt.label}</div>
                      <div className="text-xs text-slate-500">{opt.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Goals */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-display font-bold text-slate-100">What are your goals?</h2>
                <p className="text-sm text-slate-500 mt-1">Select all that apply.</p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {GOAL_OPTIONS.map(opt => {
                  const selected = goals.has(opt.id)
                  return (
                    <button key={opt.id} onClick={() => setGoals(prev => {
                      const next = new Set(prev)
                      selected ? next.delete(opt.id) : next.add(opt.id)
                      return next
                    })}
                      className={clsx(
                        'p-3 rounded-xl border text-left transition-all',
                        selected
                          ? 'border-brand-cyan bg-brand-cyan/10'
                          : 'border-[rgba(99,179,237,0.12)] hover:border-[rgba(99,179,237,0.25)]'
                      )}>
                      <div className="text-sm font-medium text-slate-200">{opt.label}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{opt.desc}</div>
                    </button>
                  )
                })}
              </div>
            </div>
          )}

          {/* Step 3: Paths */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-display font-bold text-slate-100">Which areas interest you?</h2>
                <p className="text-sm text-slate-500 mt-1">Pick 1-4 domains to start exploring.</p>
              </div>
              <div className="grid grid-cols-2 gap-2 max-h-80 overflow-y-auto pr-1">
                {PATH_OPTIONS.map(opt => {
                  const selected = paths.has(opt.id)
                  return (
                    <button key={opt.id} onClick={() => setPaths(prev => {
                      const next = new Set(prev)
                      if (selected) { next.delete(opt.id) } else if (next.size < 6) { next.add(opt.id) }
                      return next
                    })}
                      className={clsx(
                        'flex items-center gap-2 p-3 rounded-xl border text-left transition-all',
                        selected
                          ? 'border-brand-cyan bg-brand-cyan/10'
                          : 'border-[rgba(99,179,237,0.12)] hover:border-[rgba(99,179,237,0.25)]',
                        !selected && paths.size >= 6 ? 'opacity-40 cursor-not-allowed' : ''
                      )}>
                      <span className="text-lg shrink-0">{opt.icon}</span>
                      <span className="text-xs font-medium text-slate-200">{opt.label}</span>
                    </button>
                  )
                })}
              </div>
              {paths.size >= 6 && <p className="text-xs text-slate-500">Max 6 selected. You can add more later.</p>}
            </div>
          )}

          {/* Footer actions */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-[rgba(99,179,237,0.08)]">
            <button
              onClick={() => step > 0 ? setStep(s => s - 1) : skip()}
              className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-300 transition-colors"
            >
              {step > 0 ? <><ChevronLeft className="w-4 h-4" /> Back</> : 'Skip setup'}
            </button>

            <div className="flex items-center gap-3">
              {step > 0 && (
                <button onClick={skip} className="text-xs text-slate-600 hover:text-slate-400 transition-colors">
                  Skip for now
                </button>
              )}
              <button
                onClick={next}
                disabled={!canNext || saving}
                className="btn-primary disabled:opacity-40"
              >
                {saving ? 'Saving…' : step === TOTAL_STEPS - 1 ? 'Start Exploring' : 'Continue'}
                {!saving && <ArrowRight className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-xs text-slate-600 mt-4">
          Step {step + 1} of {TOTAL_STEPS} · You can change these preferences in Settings later
        </p>
      </div>
    </div>
  )
}
