'use client'
// src/app/(auth)/login/page.tsx
import { signIn, getSession } from 'next-auth/react'
import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Zap, Mail, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react'

export default function LoginPage() {
  const router = useRouter()
  const params = useSearchParams()
  const callbackUrl = params.get('callbackUrl') ?? '/dashboard'
  const error = params.get('error')

  const [form, setForm] = useState({ email: '', password: '' })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState<string | null>(null)
  const [credError, setCredError] = useState('')

  const oauthLogin = async (provider: string) => {
    setLoading(provider)
    await signIn(provider, { callbackUrl })
  }

  const credLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading('credentials')
    setCredError('')
    const res = await signIn('credentials', {
      email: form.email, password: form.password,
      redirect: false,
    })
    if (res?.error) {
      setCredError('Invalid email or password')
      setLoading(null)
    } else {
      router.push(callbackUrl)
    }
  }

  const OAUTH_PROVIDERS = [
    {
      id: 'google',
      label: 'Continue with Google',
      bg: 'bg-white hover:bg-gray-50',
      text: 'text-gray-700',
      border: 'border-gray-200',
      icon: (
        <svg viewBox="0 0 24 24" className="w-4 h-4">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
      ),
    },
    {
      id: 'github',
      label: 'Continue with GitHub',
      bg: 'bg-[#24292e] hover:bg-[#2f363d]',
      text: 'text-white',
      border: 'border-[#1b1f23]',
      icon: (
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
          <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
        </svg>
      ),
    },
    {
      id: 'linkedin',
      label: 'Continue with LinkedIn',
      bg: 'bg-[#0A66C2] hover:bg-[#004182]',
      text: 'text-white',
      border: 'border-[#0A66C2]',
      icon: (
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
        </svg>
      ),
    },
    {
      id: 'facebook',
      label: 'Continue with Facebook',
      bg: 'bg-[#1877F2] hover:bg-[#166FE5]',
      text: 'text-white',
      border: 'border-[#1877F2]',
      icon: (
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      ),
    },
  ]

  const errorMessages: Record<string, string> = {
    OAuthSignin: 'Error initiating OAuth. Please try again.',
    OAuthCallback: 'OAuth callback error. Please try again.',
    OAuthCreateAccount: 'Could not create account. Email may already be registered.',
    EmailCreateAccount: 'Could not create account.',
    Callback: 'Callback error.',
    OAuthAccountNotLinked: 'This email is already registered with a different provider.',
    default: 'An authentication error occurred.',
  }

  return (
    <div className="min-h-screen bg-[#060a10] flex items-center justify-center px-4">
      {/* Background grid */}
      <div className="fixed inset-0 bg-grid-pattern bg-[size:40px_40px] pointer-events-none opacity-40" />
      <div className="fixed inset-0 bg-radial-glow pointer-events-none" />

      <div className="relative w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-cyan to-brand-indigo flex items-center justify-center mx-auto mb-4 shadow-glow-cyan">
            <Zap className="w-6 h-6 text-[#060a10]" />
          </div>
          <h1 className="text-2xl font-display font-bold text-slate-100">EmbeddedRoadmap</h1>
          <p className="text-sm text-slate-500 mt-1">The engineering skill graph</p>
        </div>

        {/* Error banner */}
        {(error || credError) && (
          <div className="mb-4 px-4 py-3 rounded-lg border border-red-500/30 bg-red-500/10 flex items-center gap-2 text-sm text-red-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {credError || errorMessages[error ?? ''] || errorMessages.default}
          </div>
        )}

        {/* Card */}
        <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.15)] rounded-xl p-6 shadow-card">
          <h2 className="text-base font-semibold text-slate-200 mb-5">Sign in to your account</h2>

          {/* OAuth providers */}
          <div className="space-y-2.5 mb-5">
            {OAUTH_PROVIDERS.map(p => (
              <button
                key={p.id}
                onClick={() => oauthLogin(p.id)}
                disabled={loading !== null}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg border text-sm font-medium transition-all disabled:opacity-60 ${p.bg} ${p.text} ${p.border}`}
              >
                {p.icon}
                <span className="flex-1 text-left">
                  {loading === p.id ? 'Redirecting…' : p.label}
                </span>
              </button>
            ))}
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3 mb-5">
            <div className="flex-1 h-px bg-[rgba(99,179,237,0.12)]" />
            <span className="text-xs text-slate-600">or with email</span>
            <div className="flex-1 h-px bg-[rgba(99,179,237,0.12)]" />
          </div>

          {/* Credentials form */}
          <form onSubmit={credLogin} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
                <input
                  type="email" required autoComplete="email"
                  className="w-full bg-[#0a1020] border border-[rgba(99,179,237,0.15)] rounded-lg pl-9 pr-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-brand-cyan/50 focus:ring-1 focus:ring-brand-cyan/20 transition-colors"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
                <input
                  type={showPw ? 'text' : 'password'} required autoComplete="current-password"
                  className="w-full bg-[#0a1020] border border-[rgba(99,179,237,0.15)] rounded-lg pl-9 pr-9 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-brand-cyan/50 focus:ring-1 focus:ring-brand-cyan/20 transition-colors"
                  placeholder="••••••••"
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                />
                <button type="button" onClick={() => setShowPw(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <button
              type="submit" disabled={loading !== null}
              className="w-full py-2.5 rounded-lg bg-brand-cyan text-[#060a10] text-sm font-semibold hover:bg-cyan-300 transition-colors disabled:opacity-60 mt-1"
            >
              {loading === 'credentials' ? 'Signing in…' : 'Sign in'}
            </button>
          </form>
        </div>

        {/* Footer links */}
        <p className="text-center text-sm text-slate-500 mt-5">
          No account?{' '}
          <Link href="/register" className="text-brand-cyan hover:text-cyan-300 transition-colors">
            Create one free
          </Link>
        </p>
        <p className="text-center text-xs text-slate-600 mt-3">
          By signing in, you agree to our{' '}
          <Link href="/terms" className="hover:text-slate-400 underline">Terms</Link>
          {' & '}
          <Link href="/privacy" className="hover:text-slate-400 underline">Privacy Policy</Link>
        </p>
      </div>
    </div>
  )
}
