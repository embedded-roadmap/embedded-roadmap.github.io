'use client'
// src/app/(auth)/register/page.tsx
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Zap, Mail, Lock, User, Eye, EyeOff, AlertCircle, CheckCircle } from 'lucide-react'

export default function RegisterPage() {
  const router = useRouter()
  const [form, setForm] = useState({ username: '', email: '', password: '', confirmPw: '' })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const passwordStrength = (pw: string): { score: number; label: string; color: string } => {
    let score = 0
    if (pw.length >= 8) score++
    if (/[A-Z]/.test(pw)) score++
    if (/[0-9]/.test(pw)) score++
    if (/[^A-Za-z0-9]/.test(pw)) score++
    const levels = [
      { score: 0, label: '', color: '' },
      { score: 1, label: 'Weak', color: 'bg-red-500' },
      { score: 2, label: 'Fair', color: 'bg-amber-500' },
      { score: 3, label: 'Good', color: 'bg-brand-cyan' },
      { score: 4, label: 'Strong', color: 'bg-brand-emerald' },
    ]
    return levels[score] ?? levels[0]
  }

  const pwStrength = passwordStrength(form.password)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (form.password !== form.confirmPw) { setError('Passwords do not match'); return }
    if (form.password.length < 8) { setError('Password must be at least 8 characters'); return }

    setLoading(true)
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: form.username, email: form.email, password: form.password }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error ?? 'Registration failed'); setLoading(false); return }

      // Auto-sign in after registration
      await signIn('credentials', { email: form.email, password: form.password, callbackUrl: '/dashboard' })
    } catch {
      setError('Registration failed. Please try again.')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#060a10] flex items-center justify-center px-4">
      <div className="fixed inset-0 bg-grid-pattern bg-[size:40px_40px] pointer-events-none opacity-40" />
      <div className="fixed inset-0 bg-radial-glow pointer-events-none" />

      <div className="relative w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-cyan to-brand-indigo flex items-center justify-center mx-auto mb-4 shadow-glow-cyan">
            <Zap className="w-6 h-6 text-[#060a10]" />
          </div>
          <h1 className="text-2xl font-display font-bold text-slate-100">Create your account</h1>
          <p className="text-sm text-slate-500 mt-1">Start tracking your engineering career</p>
        </div>

        {error && (
          <div className="mb-4 px-4 py-3 rounded-lg border border-red-500/30 bg-red-500/10 flex items-center gap-2 text-sm text-red-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.15)] rounded-xl p-6">
          {/* OAuth shortcuts */}
          <div className="grid grid-cols-2 gap-2 mb-5">
            {[
              { id: 'google',   label: 'Google',   bg: 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50' },
              { id: 'github',   label: 'GitHub',   bg: 'bg-[#24292e] text-white border-[#1b1f23] hover:bg-[#2f363d]' },
              { id: 'linkedin', label: 'LinkedIn', bg: 'bg-[#0A66C2] text-white border-[#0A66C2] hover:bg-[#004182]' },
              { id: 'facebook', label: 'Facebook', bg: 'bg-[#1877F2] text-white border-[#1877F2] hover:bg-[#166FE5]' },
            ].map(p => (
              <button key={p.id} onClick={() => signIn(p.id, { callbackUrl: '/dashboard' })}
                className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg border text-xs font-medium transition-all ${p.bg}`}>
                {p.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 h-px bg-[rgba(99,179,237,0.12)]" />
            <span className="text-xs text-slate-600">or create with email</span>
            <div className="flex-1 h-px bg-[rgba(99,179,237,0.12)]" />
          </div>

          <form onSubmit={submit} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Username</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
                <input type="text" required minLength={3} maxLength={30} pattern="[a-z0-9_-]+"
                  className="w-full bg-[#0a1020] border border-[rgba(99,179,237,0.15)] rounded-lg pl-9 pr-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-brand-cyan/50 transition-colors"
                  placeholder="embedded_wizard" value={form.username}
                  onChange={e => set('username', e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))} />
              </div>
              <p className="text-[11px] text-slate-600 mt-1">Lowercase letters, numbers, _ or -</p>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
                <input type="email" required autoComplete="email"
                  className="w-full bg-[#0a1020] border border-[rgba(99,179,237,0.15)] rounded-lg pl-9 pr-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-brand-cyan/50 transition-colors"
                  placeholder="you@example.com" value={form.email}
                  onChange={e => set('email', e.target.value)} />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
                <input type={showPw ? 'text' : 'password'} required minLength={8} autoComplete="new-password"
                  className="w-full bg-[#0a1020] border border-[rgba(99,179,237,0.15)] rounded-lg pl-9 pr-9 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-brand-cyan/50 transition-colors"
                  placeholder="Min 8 characters" value={form.password}
                  onChange={e => set('password', e.target.value)} />
                <button type="button" onClick={() => setShowPw(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {form.password && (
                <div className="mt-1.5 flex items-center gap-2">
                  <div className="flex-1 h-1 rounded-full bg-surface-4 overflow-hidden">
                    <div className={`h-full rounded-full transition-all ${pwStrength.color}`}
                      style={{ width: `${(pwStrength.score / 4) * 100}%` }} />
                  </div>
                  <span className="text-[11px] text-slate-500">{pwStrength.label}</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
                <input type={showPw ? 'text' : 'password'} required autoComplete="new-password"
                  className={`w-full bg-[#0a1020] border rounded-lg pl-9 pr-9 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none transition-colors ${
                    form.confirmPw && form.password !== form.confirmPw
                      ? 'border-red-500/50 focus:border-red-500/70'
                      : form.confirmPw && form.password === form.confirmPw
                      ? 'border-brand-emerald/50'
                      : 'border-[rgba(99,179,237,0.15)] focus:border-brand-cyan/50'
                  }`}
                  placeholder="Repeat password" value={form.confirmPw}
                  onChange={e => set('confirmPw', e.target.value)} />
                {form.confirmPw && form.password === form.confirmPw && (
                  <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-emerald" />
                )}
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="w-full py-2.5 rounded-lg bg-brand-cyan text-[#060a10] text-sm font-semibold hover:bg-cyan-300 transition-colors disabled:opacity-60 mt-2">
              {loading ? 'Creating account…' : 'Create account'}
            </button>
          </form>
        </div>

        <p className="text-center text-sm text-slate-500 mt-5">
          Already have an account?{' '}
          <Link href="/login" className="text-brand-cyan hover:text-cyan-300 transition-colors">Sign in</Link>
        </p>
      </div>
    </div>
  )
}
