// src/app/r/[token]/page.tsx
// Recruiter share link — public CV viewer with full recruiter mode

import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { RANK_LABELS } from '@/types'

async function getSharedCv(token: string) {
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_APP_URL}/api/cv/share/${token}`,
      { next: { revalidate: 60 } }
    )
    if (!res.ok) return null
    const { data } = await res.json()
    return data
  } catch { return null }
}

export async function generateMetadata({ params }: { params: { token: string } }): Promise<Metadata> {
  const data = await getSharedCv(params.token)
  if (!data) return { title: 'CV Not Found' }
  const cv = data.cv
  return {
    title: `${cv?.fullName ?? 'Engineer'} — Engineering CV`,
    description: `${cv?.title ?? RANK_LABELS[data.recruiterProfile?.user?.currentLevel ?? 'intern']}`,
  }
}

export default async function RecruiterSharePage({ params }: { params: { token: string } }) {
  const data = await getSharedCv(params.token)
  if (!data) notFound()

  const { cv, recruiterProfile: profile } = data

  return (
    <div className="min-h-screen bg-[#060a10] text-slate-100">
      <div className="max-w-5xl mx-auto px-6 py-10">

        {/* Recruiter header banner */}
        <div className="mb-8 px-4 py-3 rounded-lg border border-[rgba(56,189,248,0.15)] bg-[rgba(56,189,248,0.05)] flex items-center justify-between text-sm">
          <span className="text-slate-400">
            🔒 Recruiter view · Shared by <span className="text-slate-200">{cv?.fullName}</span>
          </span>
          <a href="/" className="text-brand-cyan hover:underline text-xs">EmbeddedRoadmap</a>
        </div>

        {/* CV Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold text-slate-100">{cv?.fullName}</h1>
          <p className="text-lg text-[#38bdf8] mt-1">{cv?.title}</p>
          <div className="flex flex-wrap items-center gap-3 mt-3 text-sm text-slate-500">
            {cv?.email && <span>✉ {cv.email}</span>}
            {cv?.phone && <span>☎ {cv.phone}</span>}
            {cv?.location && <span>📍 {cv.location}</span>}
          </div>

          {cv?.openToWork && cv.openToWork !== 'not_looking' && (
            <span className={`inline-flex items-center mt-3 px-3 py-1 rounded-full text-xs font-medium border ${
              cv.openToWork === 'open_to_work' ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' :
              cv.openToWork === 'hiring'       ? 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30' :
                                                 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30'
            }`}>
              {cv.openToWork === 'open_to_work' ? '✓ Open to Work' : cv.openToWork === 'hiring' ? '🔍 Hiring' : '⚡ Freelance Available'}
            </span>
          )}

          {/* Social links */}
          <div className="flex gap-3 mt-4">
            {cv?.socialLinks?.linkedin && <a href={cv.socialLinks.linkedin} target="_blank" rel="noopener" className="text-xs text-slate-400 hover:text-[#0A66C2] transition-colors">LinkedIn ↗</a>}
            {cv?.socialLinks?.github   && <a href={cv.socialLinks.github}   target="_blank" rel="noopener" className="text-xs text-slate-400 hover:text-slate-100 transition-colors">GitHub ↗</a>}
            {cv?.socialLinks?.hackaday && <a href={cv.socialLinks.hackaday} target="_blank" rel="noopener" className="text-xs text-amber-400/70 hover:text-amber-400 transition-colors">Hackaday ↗</a>}
            {cv?.socialLinks?.website  && <a href={cv.socialLinks.website}  target="_blank" rel="noopener" className="text-xs text-slate-400 hover:text-slate-100 transition-colors">Website ↗</a>}
          </div>
        </div>

        {/* Embedded roadmap stats — recruiter insight */}
        {profile && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
            {[
              { label: 'Level',          value: RANK_LABELS[profile.user.currentLevel] },
              { label: 'Topics Learned', value: profile.stats.topicsLearned },
              { label: 'Rare Skills',    value: profile.stats.rareSkills },
              { label: 'Global Rank',    value: `Top ${(100 - profile.stats.globalPercentile).toFixed(0)}%` },
            ].map(s => (
              <div key={s.label} className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-lg p-3 text-center">
                <div className="font-bold text-slate-100">{s.value}</div>
                <div className="text-[11px] text-slate-500 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 space-y-6">

            {/* Summary */}
            {cv?.summary && (
              <Section title="Professional Summary">
                <p className="text-sm text-slate-400 leading-relaxed">{cv.summary}</p>
              </Section>
            )}

            {/* Experience */}
            {cv?.experience?.length > 0 && (
              <Section title="Work Experience">
                {cv.experience.map((e: Record<string, unknown>, i: number) => (
                  <div key={i} className="mb-5 last:mb-0">
                    <div className="flex justify-between items-baseline">
                      <span className="font-medium text-slate-100">{e.title as string}</span>
                      <span className="text-xs text-slate-500">{e.startDate as string?.slice(0, 7)} – {e.isCurrent ? 'Present' : (e.endDate as string)?.slice(0, 7)}</span>
                    </div>
                    <div className="text-sm text-brand-cyan">{e.company as string}</div>
                    {e.description && <p className="text-xs text-slate-500 mt-1">{e.description as string}</p>}
                    {(e.highlights as string[] ?? []).length > 0 && (
                      <ul className="mt-2 space-y-1">
                        {(e.highlights as string[]).map((h, j) => <li key={j} className="text-xs text-slate-400">• {h}</li>)}
                      </ul>
                    )}
                  </div>
                ))}
              </Section>
            )}

            {/* Projects */}
            {cv?.projects?.filter((p: Record<string, unknown>) => p.isFeatured).length > 0 && (
              <Section title="Engineering Projects">
                {cv.projects.filter((p: Record<string, unknown>) => p.isFeatured).slice(0, 4).map((p: Record<string, unknown>, i: number) => (
                  <div key={i} className="mb-4 last:mb-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-100">{p.title as string}</span>
                      {p.repoUrl && <a href={p.repoUrl as string} target="_blank" rel="noopener" className="text-xs text-brand-cyan">↗</a>}
                    </div>
                    {p.description && <p className="text-xs text-slate-500 mt-1">{p.description as string}</p>}
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {(p.techStack as string[] ?? []).map((t: string) => <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400">{t}</span>)}
                      {(p.hardwareStack as string[] ?? []).map((t: string) => <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400">{t}</span>)}
                    </div>
                  </div>
                ))}
              </Section>
            )}
          </div>

          <div className="space-y-4">
            {/* Education */}
            {cv?.education?.length > 0 && (
              <Section title="Education" compact>
                {cv.education.map((e: Record<string, unknown>, i: number) => (
                  <div key={i} className="mb-3 last:mb-0">
                    <div className="text-sm font-medium text-slate-200">{e.institution as string}</div>
                    <div className="text-xs text-slate-500">{e.degree as string}{e.field ? `, ${e.field}` : ''}</div>
                    {e.gpa && <div className="text-xs text-slate-600">GPA: {e.gpa as string}</div>}
                  </div>
                ))}
              </Section>
            )}

            {/* Top skills */}
            {profile?.topSkills.length > 0 && (
              <Section title="Top Skills" compact>
                <div className="space-y-1.5">
                  {profile.topSkills.slice(0, 8).map((s: Record<string, unknown>, i: number) => (
                    <div key={i} className="flex items-center justify-between text-xs">
                      <span className="text-slate-300">{s.name as string}</span>
                      <span className={`font-medium ${
                        s.rarity === 'legendary' ? 'text-amber-400' :
                        s.rarity === 'elite'     ? 'text-indigo-400' :
                        s.rarity === 'rare'      ? 'text-cyan-400' : 'text-slate-500'
                      }`}>{(s.rarity as string)?.charAt(0).toUpperCase() + (s.rarity as string)?.slice(1)}</span>
                    </div>
                  ))}
                </div>
              </Section>
            )}

            {/* Certifications */}
            {cv?.certifications?.length > 0 && (
              <Section title="Certifications" compact>
                {cv.certifications.map((c: Record<string, unknown>, i: number) => (
                  <div key={i} className="text-xs mb-1.5">
                    <div className="text-slate-200">{c.name as string}</div>
                    <div className="text-slate-500">{c.issuer as string}</div>
                  </div>
                ))}
              </Section>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function Section({ title, children, compact }: { title: string; children: React.ReactNode; compact?: boolean }) {
  return (
    <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.1)] rounded-lg p-5">
      <h2 className={`font-semibold text-slate-300 uppercase tracking-wider border-b border-[rgba(99,179,237,0.1)] pb-2 mb-3 ${compact ? 'text-xs' : 'text-sm'}`}>{title}</h2>
      {children}
    </div>
  )
}
