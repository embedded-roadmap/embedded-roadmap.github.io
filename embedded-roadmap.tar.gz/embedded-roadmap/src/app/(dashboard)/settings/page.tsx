'use client'
// src/app/(dashboard)/settings/page.tsx
// User settings: privacy controls, GDPR, account management, donations

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { toast } from 'sonner'
import { Shield, Download, Trash2, Eye, EyeOff, Heart, ExternalLink, AlertTriangle, Coffee } from 'lucide-react'
import type { UserPrivacySettings, DonationConfig } from '@/types'

export default function SettingsPage() {
  const { data: session } = useSession()
  const [privacy, setPrivacy] = useState<Partial<UserPrivacySettings>>({})
  const [donations, setDonations] = useState<DonationConfig | null>(null)
  const [loading, setLoading] = useState(true)
  const [deleteConfirm, setDeleteConfirm] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    Promise.all([
      fetch('/api/users/privacy').then(r => r.json()),
      fetch('/api/donations').then(r => r.json()),
    ]).then(([privRes, donRes]) => {
      if (privRes.data) setPrivacy(privRes.data)
      if (donRes.data) setDonations(donRes.data)
      setLoading(false)
    })
  }, [])

  const toggle = async (key: keyof UserPrivacySettings) => {
    const newVal = !(privacy[key] as boolean)
    setPrivacy(p => ({ ...p, [key]: newVal }))
    setSaving(true)
    await fetch('/api/users/privacy', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ [key]: newVal }),
    })
    setSaving(false)
    toast.success('Privacy setting updated')
  }

  const exportData = async () => {
    const res = await fetch('/api/users/privacy?action=export', { method: 'POST' })
    const { data } = await res.json()
    if (data) toast.success('Export prepared — download link will be emailed within 24h')
  }

  const requestDelete = async () => {
    await fetch('/api/users/privacy?action=delete', { method: 'POST' })
    toast.error('Account scheduled for deletion in 30 days')
    setDeleteConfirm(false)
  }

  if (loading) return <div className="p-8 text-slate-500 text-sm">Loading settings...</div>

  const privacyToggles: { key: keyof UserPrivacySettings; label: string; desc: string }[] = [
    { key: 'isPublic',           label: 'Public Profile',         desc: 'Allow others to view your engineer profile' },
    { key: 'showPercentile',     label: 'Show Percentile Stats',  desc: 'Display global percentile on your profile' },
    { key: 'showXp',             label: 'Show XP Points',         desc: 'Display your total XP on your profile' },
    { key: 'showStreak',         label: 'Show Streak',            desc: 'Display your learning streak publicly' },
    { key: 'showBadges',         label: 'Show Badges',            desc: 'Display earned badges on your profile' },
    { key: 'showProjects',       label: 'Show Projects',          desc: 'Display your project portfolio publicly' },
    { key: 'showSalaryEstimates',label: 'Show Salary Estimates',  desc: 'Show salary range estimates on your profile' },
    { key: 'allowRecruiterView', label: 'Recruiter View',         desc: 'Allow recruiters to find and view your full profile' },
  ]

  return (
    <div className="max-w-2xl mx-auto px-6 py-8 space-y-8">
      <div>
        <h1 className="text-xl font-display font-bold text-slate-100">Settings</h1>
        <p className="text-sm text-slate-500 mt-0.5">Control your privacy, data, and account preferences.</p>
      </div>

      {/* Privacy Controls */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-brand-cyan" />
          <h2 className="text-sm font-semibold text-slate-200">Privacy Controls</h2>
        </div>

        <div className="card divide-y divide-border">
          {privacyToggles.map(({ key, label, desc }) => (
            <div key={key} className="flex items-center justify-between px-4 py-3">
              <div>
                <div className="text-sm text-slate-200">{label}</div>
                <div className="text-xs text-slate-500 mt-0.5">{desc}</div>
              </div>
              <button
                onClick={() => toggle(key)}
                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${
                  privacy[key] ? 'bg-brand-cyan' : 'bg-surface-4'
                }`}
              >
                <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                  privacy[key] ? 'translate-x-4.5' : 'translate-x-0.5'
                }`} />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* GDPR Data Controls */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Download className="w-4 h-4 text-brand-indigo" />
          <h2 className="text-sm font-semibold text-slate-200">Your Data (GDPR)</h2>
        </div>

        <div className="card p-5 space-y-4">
          <div>
            <h3 className="text-sm font-medium text-slate-200">Export All Data</h3>
            <p className="text-xs text-slate-500 mt-1">Download all your data: profile, progress, CV, badges. Sent to your registered email.</p>
            <button onClick={exportData} className="btn-secondary text-xs mt-3">
              <Download className="w-3.5 h-3.5" /> Request Data Export
            </button>
          </div>

          <div className="border-t border-border pt-4">
            <h3 className="text-sm font-medium text-red-400">Delete Account</h3>
            <p className="text-xs text-slate-500 mt-1">Permanently delete your account and all associated data. This action cannot be undone after the 30-day grace period.</p>
            {!deleteConfirm ? (
              <button onClick={() => setDeleteConfirm(true)} className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded text-xs text-red-400 border border-red-400/20 hover:bg-red-400/10 transition-all">
                <Trash2 className="w-3.5 h-3.5" /> Delete My Account
              </button>
            ) : (
              <div className="mt-3 p-3 rounded border border-red-400/30 bg-red-400/5 space-y-2">
                <div className="flex items-center gap-2 text-xs text-red-300">
                  <AlertTriangle className="w-4 h-4" />
                  This will delete all your data after 30 days. Are you sure?
                </div>
                <div className="flex gap-2">
                  <button onClick={requestDelete} className="px-3 py-1.5 rounded text-xs bg-red-500 text-white hover:bg-red-600 transition-colors">Yes, delete my account</button>
                  <button onClick={() => setDeleteConfirm(false)} className="btn-ghost text-xs">Cancel</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Support / Donations */}
      {donations && (
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-brand-rose" />
            <h2 className="text-sm font-semibold text-slate-200">Support EmbeddedRoadmap</h2>
          </div>

          <div className="card p-5">
            <p className="text-sm text-slate-400 mb-4">
              EmbeddedRoadmap is free and open to all engineers. If it's helped your career, consider supporting its development.
            </p>

            {/* Funding goal */}
            {donations.goal && (
              <div className="mb-5">
                <div className="flex justify-between text-xs text-slate-400 mb-1.5">
                  <span>{donations.goal.label}</span>
                  <span>${donations.goal.current} / ${donations.goal.target}/mo</span>
                </div>
                <div className="xp-bar">
                  <div className="xp-fill bg-gradient-to-r from-brand-rose to-brand-amber"
                    style={{ width: `${Math.min(100, (donations.goal.current / donations.goal.target) * 100)}%` }} />
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2.5">
              {donations.buyMeCoffeeUrl && (
                <a href={donations.buyMeCoffeeUrl} target="_blank" rel="noopener"
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded border border-[#FFDD00]/30 bg-[#FFDD00]/5 text-[#FFDD00] text-sm font-medium hover:bg-[#FFDD00]/10 transition-all">
                  <Coffee className="w-4 h-4" /> Buy me a coffee
                </a>
              )}
              {donations.patreonUrl && (
                <a href={donations.patreonUrl} target="_blank" rel="noopener"
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded border border-[#FF424D]/30 bg-[#FF424D]/5 text-[#FF424D] text-sm font-medium hover:bg-[#FF424D]/10 transition-all">
                  <ExternalLink className="w-3.5 h-3.5" /> Patreon
                </a>
              )}
              {donations.githubSponsorsUrl && (
                <a href={donations.githubSponsorsUrl} target="_blank" rel="noopener"
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded border border-slate-500/30 bg-slate-500/5 text-slate-300 text-sm font-medium hover:bg-slate-500/10 transition-all">
                  <Heart className="w-3.5 h-3.5" /> GitHub Sponsors
                </a>
              )}
              {donations.stripePublishableKey && (
                <a href="/donate" className="flex items-center justify-center gap-2 px-4 py-2.5 rounded border border-brand-indigo/30 bg-brand-indigo/5 text-brand-indigo text-sm font-medium hover:bg-brand-indigo/10 transition-all">
                  <Heart className="w-3.5 h-3.5" /> One-time donation
                </a>
              )}
            </div>

            <p className="text-[11px] text-slate-600 mt-4 text-center">
              No ads. No data selling. Just engineers helping engineers.
            </p>
          </div>
        </section>
      )}
    </div>
  )
}
