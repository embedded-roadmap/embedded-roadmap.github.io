'use client'
// src/app/(dashboard)/projects/page.tsx

import { useEffect, useState } from 'react'
import { Plus, ExternalLink, Github, Trash2, Edit3, Star, Code } from 'lucide-react'
import { toast } from 'sonner'
import type { CvProject } from '@/types'

const PLATFORM_ICONS: Record<string, { icon: string; label: string; color: string }> = {
  github:   { icon: '⌥', label: 'GitHub',     color: 'text-slate-300' },
  gitlab:   { icon: '🦊', label: 'GitLab',     color: 'text-orange-400' },
  hackaday: { icon: 'H',  label: 'Hackaday',   color: 'text-amber-400' },
  personal: { icon: '🌐', label: 'Website',    color: 'text-brand-cyan' },
  other:    { icon: '📁', label: 'Other',      color: 'text-slate-500' },
}

function ProjectCard({ project, onDelete, onEdit }: {
  project: CvProject
  onDelete: (id: string) => void
  onEdit: (p: CvProject) => void
}) {
  const platform = PLATFORM_ICONS[project.platform] ?? PLATFORM_ICONS.other
  return (
    <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-5 group">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-slate-100 text-sm">{project.title}</h3>
            {project.isFeatured && (
              <span className="flex items-center gap-0.5 text-[10px] text-brand-amber bg-brand-amber/10 px-1.5 py-0.5 rounded border border-brand-amber/20">
                <Star className="w-2.5 h-2.5" /> Featured
              </span>
            )}
          </div>
          {project.description && (
            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">{project.description}</p>
          )}
        </div>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={() => onEdit(project)}
            className="p-1.5 rounded text-slate-500 hover:text-slate-300 hover:bg-surface-3 transition-all">
            <Edit3 className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => onDelete(project.id)}
            className="p-1.5 rounded text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Stacks */}
      <div className="flex flex-wrap gap-1 mt-3">
        {project.techStack?.slice(0, 4).map(t => (
          <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-brand-cyan/8 text-brand-cyan border border-brand-cyan/15">{t}</span>
        ))}
        {project.hardwareStack?.slice(0, 3).map(t => (
          <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-brand-amber/8 text-brand-amber border border-brand-amber/15">{t}</span>
        ))}
        {project.firmwareStack?.slice(0, 2).map(t => (
          <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-brand-indigo/8 text-brand-indigo border border-brand-indigo/15">{t}</span>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-[rgba(99,179,237,0.06)]">
        <span className={`flex items-center gap-1 text-[10px] font-medium ${platform.color}`}>
          <span>{platform.icon}</span>{platform.label}
        </span>
        {project.repoUrl && (
          <a href={project.repoUrl} target="_blank" rel="noopener"
            className="flex items-center gap-1 text-[10px] text-slate-500 hover:text-brand-cyan transition-colors">
            <ExternalLink className="w-3 h-3" />
            {project.repoUrl.replace('https://','').split('/').slice(0,2).join('/')}
          </a>
        )}
      </div>
    </div>
  )
}

function ProjectForm({ project, onSave, onCancel }: {
  project?: Partial<CvProject>
  onSave: (p: Partial<CvProject>) => void
  onCancel: () => void
}) {
  const [form, setForm] = useState<Partial<CvProject>>(project ?? { platform: 'github', techStack: [], hardwareStack: [], firmwareStack: [], isFeatured: false, isPublic: true })
  const set = (k: string, v: unknown) => setForm(f => ({ ...f, [k]: v }))
  const setArr = (k: string, v: string) => set(k, v.split(',').map(s => s.trim()).filter(Boolean))

  return (
    <div className="bg-[#0a1020] border border-[rgba(99,179,237,0.2)] rounded-xl p-5 space-y-3">
      <h3 className="text-sm font-semibold text-slate-200">{project?.id ? 'Edit Project' : 'New Project'}</h3>
      <div className="grid grid-cols-2 gap-3">
        <div className="col-span-2">
          <label className="block text-xs text-slate-400 mb-1">Project Title *</label>
          <input className="input" value={form.title??''} onChange={e=>set('title',e.target.value)} placeholder="High-Voltage ECG Front-End" />
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Platform</label>
          <select className="input" value={form.platform??'github'} onChange={e=>set('platform',e.target.value)}>
            <option value="github">GitHub</option><option value="gitlab">GitLab</option>
            <option value="hackaday">Hackaday.io</option><option value="personal">Personal Site</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Repository URL</label>
          <input className="input" value={form.repoUrl??''} onChange={e=>set('repoUrl',e.target.value)} placeholder="https://github.com/..." />
        </div>
        <div className="col-span-2">
          <label className="block text-xs text-slate-400 mb-1">Description</label>
          <textarea className="textarea h-16" value={form.description??''} onChange={e=>set('description',e.target.value)} placeholder="Designed 10kV medical wearable front-end with IEC 60601 compliance..." />
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Hardware Stack (comma separated)</label>
          <input className="input" value={(form.hardwareStack??[]).join(', ')} onChange={e=>setArr('hardwareStack',e.target.value)} placeholder="STM32H7, MAX30003, TPS63020" />
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Firmware Stack</label>
          <input className="input" value={(form.firmwareStack??[]).join(', ')} onChange={e=>setArr('firmwareStack',e.target.value)} placeholder="FreeRTOS, HAL, BLE" />
        </div>
        <div className="col-span-2">
          <label className="block text-xs text-slate-400 mb-1">Tech / Software Stack</label>
          <input className="input" value={(form.techStack??[]).join(', ')} onChange={e=>setArr('techStack',e.target.value)} placeholder="C, Python, KiCad, Altium" />
        </div>
      </div>
      <div className="flex items-center gap-4">
        <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
          <input type="checkbox" className="rounded" checked={!!form.isFeatured} onChange={e=>set('isFeatured',e.target.checked)} />
          Feature on CV & profile
        </label>
        <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
          <input type="checkbox" className="rounded" checked={form.isPublic!==false} onChange={e=>set('isPublic',e.target.checked)} />
          Public
        </label>
      </div>
      <div className="flex gap-2 pt-1">
        <button onClick={()=>onSave(form)} className="btn-primary text-xs">Save Project</button>
        <button onClick={onCancel} className="btn-ghost text-xs">Cancel</button>
      </div>
    </div>
  )
}

export default function ProjectsPage() {
  const [projects, setProjects] = useState<CvProject[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingProject, setEditingProject] = useState<CvProject | null>(null)

  useEffect(() => {
    fetch('/api/cv/sections/projects').then(r=>r.json()).then(({data})=>{
      if(Array.isArray(data))setProjects(data)
      setLoading(false)
    })
  }, [])

  const saveProject = async (form: Partial<CvProject>) => {
    const res = await fetch('/api/cv/sections/projects', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
    })
    const { data } = await res.json()
    if (data) {
      setProjects(prev => {
        const idx = prev.findIndex(p => p.id === (data as CvProject).id)
        return idx >= 0 ? prev.map((p,i)=>i===idx?data as CvProject:p) : [data as CvProject, ...prev]
      })
      setShowForm(false); setEditingProject(null)
      toast.success('Project saved')
    }
  }

  const deleteProject = async (id: string) => {
    await fetch(`/api/cv/sections/projects?id=${id}`, { method: 'DELETE' })
    setProjects(prev => prev.filter(p => p.id !== id))
    toast.success('Project removed')
  }

  const featured = projects.filter(p => p.isFeatured)
  const rest = projects.filter(p => !p.isFeatured)

  return (
    <div className="px-6 py-6 space-y-5 max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-display font-bold text-slate-100 flex items-center gap-2">
            <Code className="w-5 h-5 text-brand-cyan" /> Engineering Projects
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            {projects.length} project{projects.length!==1?'s':''} · Featured projects appear on your CV and public profile.
          </p>
        </div>
        <button onClick={()=>{setShowForm(true);setEditingProject(null)}} className="btn-primary text-sm">
          <Plus className="w-4 h-4" /> Add Project
        </button>
      </div>

      {(showForm && !editingProject) && (
        <ProjectForm onSave={saveProject} onCancel={()=>setShowForm(false)} />
      )}

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {Array.from({length:4}).map((_,i)=><div key={i} className="h-44 bg-surface-2 rounded-xl animate-pulse" />)}
        </div>
      ) : projects.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-[rgba(99,179,237,0.15)] rounded-xl">
          <Code className="w-10 h-10 text-slate-700 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">No projects yet.</p>
          <p className="text-slate-600 text-xs mt-1">Add your first engineering project — it'll appear on your CV automatically.</p>
          <button onClick={()=>setShowForm(true)} className="btn-secondary text-xs mt-4">
            <Plus className="w-3.5 h-3.5" /> Add first project
          </button>
        </div>
      ) : (
        <>
          {featured.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Star className="w-3.5 h-3.5 text-brand-amber" />
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Featured</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {featured.map(p => (
                  editingProject?.id === p.id
                    ? <ProjectForm key={p.id} project={p} onSave={saveProject} onCancel={()=>setEditingProject(null)} />
                    : <ProjectCard key={p.id} project={p} onDelete={deleteProject} onEdit={setEditingProject} />
                ))}
              </div>
            </div>
          )}
          {rest.length > 0 && (
            <div>
              {featured.length > 0 && (
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">All Projects</span>
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {rest.map(p => (
                  editingProject?.id === p.id
                    ? <ProjectForm key={p.id} project={p} onSave={saveProject} onCancel={()=>setEditingProject(null)} />
                    : <ProjectCard key={p.id} project={p} onDelete={deleteProject} onEdit={setEditingProject} />
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
