'use client'
// src/app/(dashboard)/leaderboard/page.tsx
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Trophy, Flame, Zap, Star, Medal } from 'lucide-react'
import { RANK_LABELS, type RankTier } from '@/types'

type LeaderboardEntry = {
  rank: number
  username: string
  displayName: string | null
  currentLevel: RankTier
  totalXp: number
  monthlyScore: number
  currentStreak: number
  topicsLearned: number
  rareTopicsCount: number
  isCurrentUser?: boolean
}

const RANK_COLORS: Record<number, string> = {
  1: 'text-amber-400',
  2: 'text-slate-300',
  3: 'text-amber-600',
}

const RANK_BG: Record<number, string> = {
  1: 'bg-amber-400/10 border-amber-400/30',
  2: 'bg-slate-300/10 border-slate-300/20',
  3: 'bg-amber-600/10 border-amber-600/20',
}

export default function LeaderboardPage() {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([])
  const [period, setPeriod] = useState<'monthly' | 'alltime'>('monthly')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    fetch(`/api/rankings?period=${period}&limit=50`)
      .then(r => r.json())
      .then(({ data }) => {
        if (data?.rankings) setEntries(data.rankings)
        setLoading(false)
      })
  }, [period])

  return (
    <div className="max-w-3xl mx-auto px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-display font-bold text-slate-100 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-brand-amber" />
            Leaderboard
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">Top engineers by engineering progression</p>
        </div>
        <div className="flex rounded-lg border border-[rgba(99,179,237,0.15)] overflow-hidden">
          {(['monthly', 'alltime'] as const).map(p => (
            <button key={p} onClick={() => setPeriod(p)}
              className={`px-4 py-1.5 text-xs font-medium transition-colors ${
                period === p ? 'bg-brand-cyan/10 text-brand-cyan' : 'text-slate-500 hover:text-slate-300'
              }`}>
              {p === 'monthly' ? 'This Month' : 'All Time'}
            </button>
          ))}
        </div>
      </div>

      {/* Podium (top 3) */}
      {!loading && entries.slice(0, 3).length === 3 && (
        <div className="grid grid-cols-3 gap-3 mb-2">
          {[entries[1], entries[0], entries[2]].map((entry, i) => {
            if (!entry) return <div key={i} />
            const position = i === 1 ? 1 : i === 0 ? 2 : 3
            const style = RANK_BG[position]
            return (
              <div key={entry.username}
                className={`relative border rounded-xl p-4 text-center ${style} ${i === 1 ? 'scale-105 -mt-2' : ''}`}>
                {i === 1 && <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-xl">👑</div>}
                <div className={`text-2xl font-display font-bold ${RANK_COLORS[position]}`}>#{position}</div>
                <div className="font-medium text-sm text-slate-200 mt-1 truncate">
                  {entry.displayName ?? entry.username}
                </div>
                <div className={`text-xs mt-0.5 ${RANK_COLORS[position]}`}>
                  {RANK_LABELS[entry.currentLevel]}
                </div>
                <div className="text-xs text-slate-500 mt-1.5 flex items-center justify-center gap-1">
                  <Zap className="w-3 h-3" />
                  {(period === 'monthly' ? entry.monthlyScore : entry.totalXp).toLocaleString()}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Full table */}
      <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl overflow-hidden">
        {/* Column headers */}
        <div className="grid grid-cols-12 gap-2 px-4 py-2.5 border-b border-[rgba(99,179,237,0.1)] text-[10px] font-semibold text-slate-600 uppercase tracking-wider">
          <span className="col-span-1 text-center">#</span>
          <span className="col-span-4">Engineer</span>
          <span className="col-span-2 text-right">Score</span>
          <span className="col-span-2 text-right hidden sm:block">Topics</span>
          <span className="col-span-2 text-right hidden sm:block">Streak</span>
          <span className="col-span-1 text-right hidden sm:block">Rare</span>
        </div>

        {loading
          ? Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="px-4 py-3 border-b border-[rgba(99,179,237,0.06)] flex gap-3 items-center">
                <div className="w-6 h-4 bg-surface-3 rounded animate-pulse" />
                <div className="flex-1 h-4 bg-surface-3 rounded animate-pulse" />
                <div className="w-16 h-4 bg-surface-3 rounded animate-pulse" />
              </div>
            ))
          : entries.map((entry) => (
              <Link key={entry.username} href={`/engineers/${entry.username}`}
                className={`grid grid-cols-12 gap-2 items-center px-4 py-3 border-b border-[rgba(99,179,237,0.06)] last:border-0 hover:bg-surface-2 transition-colors ${
                  entry.isCurrentUser ? 'bg-brand-cyan/5' : ''
                }`}>
                {/* Rank */}
                <span className={`col-span-1 text-center text-sm font-bold ${RANK_COLORS[entry.rank] ?? 'text-slate-500'}`}>
                  {entry.rank <= 3
                    ? ['🥇', '🥈', '🥉'][entry.rank - 1]
                    : `#${entry.rank}`
                  }
                </span>

                {/* Engineer */}
                <div className="col-span-4 flex items-center gap-2.5 min-w-0">
                  <div className="w-7 h-7 rounded-lg bg-brand-indigo/20 border border-brand-indigo/30 flex items-center justify-center text-xs font-bold text-brand-indigo shrink-0">
                    {(entry.displayName ?? entry.username).charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className={`text-sm font-medium truncate ${entry.isCurrentUser ? 'text-brand-cyan' : 'text-slate-200'}`}>
                      {entry.displayName ?? entry.username}
                      {entry.isCurrentUser && <span className="text-[10px] ml-1.5 text-brand-cyan/70">(you)</span>}
                    </div>
                    <div className="text-[10px] text-slate-600">{RANK_LABELS[entry.currentLevel]}</div>
                  </div>
                </div>

                {/* Score */}
                <div className="col-span-2 text-right">
                  <span className="text-sm font-mono font-medium text-slate-200">
                    {(period === 'monthly' ? entry.monthlyScore : entry.totalXp).toLocaleString()}
                  </span>
                </div>

                {/* Topics */}
                <div className="col-span-2 text-right hidden sm:flex items-center justify-end gap-1 text-slate-400 text-xs">
                  <span>{entry.topicsLearned}</span>
                </div>

                {/* Streak */}
                <div className="col-span-2 text-right hidden sm:flex items-center justify-end gap-1 text-xs">
                  <Flame className="w-3 h-3 text-brand-amber" />
                  <span className="text-slate-400">{entry.currentStreak}d</span>
                </div>

                {/* Rare */}
                <div className="col-span-1 text-right hidden sm:flex items-center justify-end gap-1 text-xs">
                  <Star className="w-3 h-3 text-brand-indigo" />
                  <span className="text-slate-400">{entry.rareTopicsCount}</span>
                </div>
              </Link>
            ))
        }
      </div>

      <p className="text-center text-xs text-slate-600">
        Monthly rankings reset on the 1st · Rare skills weighted 4× · Legendary 8×
      </p>
    </div>
  )
}
