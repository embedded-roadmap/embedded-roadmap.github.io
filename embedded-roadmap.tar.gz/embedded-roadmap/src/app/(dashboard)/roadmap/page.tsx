'use client'
// src/app/(dashboard)/roadmap/page.tsx
import { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import dynamic from 'next/dynamic'
import { ChevronDown, Zap, Map, Layers } from 'lucide-react'
import { useRoadmapStore } from '@/stores/roadmap'
import { useProgressStore } from '@/stores/progress'
import { TopicDetailPanel } from '@/components/roadmap/TopicDetailPanel'
import type { Branch } from '@/types'

// Lazy-load React Flow (heavy)
const RoadmapGraph = dynamic(
  () => import('@/components/roadmap/RoadmapGraph').then(m => ({ default: m.RoadmapGraph })),
  { ssr: false, loading: () => <GraphLoadingState /> }
)

const DOMAIN_LABELS: Record<string, string> = {
  hardware:       'Hardware',
  firmware:       'Firmware & Software',
  system:         'Systems & Architecture',
  specialization: 'Specializations',
  industry:       'Industry Verticals',
}

export default function RoadmapPage() {
  const params = useSearchParams()
  const { branches, activeBranchSlug, fetchBranches, loadBranch, selectTopic } = useRoadmapStore()
  const { fetchProgress, branchProgress } = useProgressStore()
  const [showBranchMenu, setShowBranchMenu] = useState(false)

  useEffect(() => {
    fetchBranches()
    fetchProgress()
  }, [])

  useEffect(() => {
    // Auto-load from URL param or first branch
    const slugParam = params.get('branch')
    if (slugParam) {
      loadBranch(slugParam)
    } else if (branches.length > 0 && !activeBranchSlug) {
      loadBranch(branches[0].slug)
    }
  }, [branches, params])

  // Group branches by domain
  const byDomain = branches.reduce<Record<string, Branch[]>>((acc, b) => {
    ;(acc[b.domain] ??= []).push(b)
    return acc
  }, {})

  const active = branches.find(b => b.slug === activeBranchSlug)
  const activeProg = activeBranchSlug ? branchProgress.get(activeBranchSlug) : null

  return (
    <div className="flex h-full overflow-hidden">

      {/* Left: Branch selector */}
      <div className="w-56 shrink-0 bg-[#08111c] border-r border-[rgba(99,179,237,0.1)] overflow-y-auto">
        <div className="px-3 py-3 border-b border-[rgba(99,179,237,0.1)]">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <Layers className="w-3.5 h-3.5" /> Branches
          </div>
        </div>

        <nav className="py-2">
          {Object.entries(byDomain).map(([domain, domainBranches]) => (
            <div key={domain} className="mb-1">
              <div className="px-3 py-1.5 text-[10px] font-bold text-slate-600 uppercase tracking-wider">
                {DOMAIN_LABELS[domain] ?? domain}
              </div>
              {domainBranches.map(branch => {
                const prog = branchProgress.get(branch.slug)
                const isActive = activeBranchSlug === branch.slug
                return (
                  <button
                    key={branch.slug}
                    onClick={() => { loadBranch(branch.slug); selectTopic(null) }}
                    className={`w-full text-left px-3 py-2 transition-all ${
                      isActive
                        ? 'bg-brand-cyan/10 text-brand-cyan'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-surface-2'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs truncate">{branch.name}</span>
                      {prog && prog.pct > 0 && (
                        <span className={`text-[10px] font-medium shrink-0 ${isActive ? 'text-brand-cyan' : 'text-slate-600'}`}>
                          {Math.round(prog.pct)}%
                        </span>
                      )}
                    </div>
                    {prog && prog.pct > 0 && (
                      <div className="mt-1 h-0.5 rounded-full bg-surface-4 overflow-hidden">
                        <div className={`h-full rounded-full ${isActive ? 'bg-brand-cyan' : 'bg-slate-600'} transition-all`}
                          style={{ width: `${prog.pct}%` }} />
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          ))}
        </nav>
      </div>

      {/* Center: Graph canvas */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Branch header bar */}
        {active && (
          <div className="shrink-0 px-4 py-2.5 bg-[#080f1a] border-b border-[rgba(99,179,237,0.1)] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Map className="w-4 h-4 text-brand-cyan" />
              <div>
                <span className="font-medium text-sm text-slate-200">{active.name}</span>
                {active.description && (
                  <span className="text-xs text-slate-500 ml-2 hidden lg:inline">{active.description}</span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-500">
              {activeProg && (
                <>
                  <span><span className="text-slate-300 font-medium">{activeProg.learned}</span> learned</span>
                  <span><span className="text-slate-300 font-medium">{Math.round(activeProg.pct)}%</span> complete</span>
                </>
              )}
            </div>
          </div>
        )}

        <RoadmapGraph />

        {/* Legend */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-[#08111c]/90 backdrop-blur-sm border border-[rgba(99,179,237,0.12)] rounded-lg px-4 py-2 text-[10px] text-slate-500">
          {[
            { color: 'bg-emerald-500', label: 'Learned' },
            { color: 'bg-amber-500',   label: 'In Progress' },
            { color: 'bg-slate-600',   label: 'Available' },
            { color: 'bg-cyan-400',    label: 'Rare' },
            { color: 'bg-amber-400',   label: 'Legendary' },
          ].map(l => (
            <div key={l.label} className="flex items-center gap-1.5">
              <div className={`w-2 h-2 rounded-full ${l.color}`} />
              <span>{l.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right: Topic detail panel */}
      <TopicDetailPanel />
    </div>
  )
}

function GraphLoadingState() {
  return (
    <div className="flex-1 flex items-center justify-center">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-brand-cyan border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-slate-500">Loading roadmap engine…</p>
      </div>
    </div>
  )
}
