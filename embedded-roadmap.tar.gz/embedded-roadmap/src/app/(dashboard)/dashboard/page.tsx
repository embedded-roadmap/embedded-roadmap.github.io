'use client'
// src/app/(dashboard)/dashboard/page.tsx
import { useSession } from 'next-auth/react'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Zap, TrendingUp, Map, Award, Target, ArrowRight, Flame, Star, Trophy } from 'lucide-react'
import { RANK_LABELS, RANK_XP_THRESHOLDS, type RankTier } from '@/types'

export default function DashboardPage() {
  const { data: session } = useSession()
  const [stats, setStats] = useState<Record<string, unknown>>({})
  const [recentProgress, setRecentProgress] = useState<Record<string, unknown>[]>([])
  const [recommendations, setRecommendations] = useState<Record<string, unknown>[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      fetch('/api/progress').then(r => r.json()),
      fetch('/api/ai/recommend').then(r => r.json()),
    ]).then(([prog, recs]) => {
      if (prog.data) {
        setStats(prog.data.user ?? {})
        setRecentProgress((prog.data.recentProgress ?? []).slice(0, 5))
      }
      if (recs.data?.recommendations) setRecommendations(recs.data.recommendations.slice(0, 3))
      setLoading(false)
    })
  }, [])

  const currentLevel = (stats.currentLevel as RankTier) ?? 'intern'
  const totalXp = Number(stats.totalXp ?? 0)
  const nextLevel = Object.entries(RANK_XP_THRESHOLDS).find(([, xp]) => xp > totalXp)
  const nextLevelXp = nextLevel?.[1] ?? totalXp
  const prevLevelXp = RANK_XP_THRESHOLDS[currentLevel] ?? 0
  const xpProgress = Math.min(100, ((totalXp - prevLevelXp) / Math.max(1, nextLevelXp - prevLevelXp)) * 100)

  if (loading) return <DashboardSkeleton />

  return (
    <div className="px-6 py-6 space-y-6 animate-fade-up">
      {/* Hero greeting */}
      <div className="relative overflow-hidden rounded-xl bg-[#0d1420] border border-[rgba(99,179,237,0.15)] p-6">
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-cyan/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-xl font-display font-bold text-slate-100">
                Welcome back, {session?.user?.name?.split(' ')[0] ?? session?.user?.username ?? 'Engineer'}
              </h1>
              <p className="text-slate-500 text-sm mt-1">Keep pushing your engineering boundaries.</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-display font-bold text-brand-cyan">{RANK_LABELS[currentLevel]}</div>
              <div className="text-xs text-slate-500 mt-0.5">{totalXp.toLocaleString()} XP</div>
            </div>
          </div>

          {/* XP bar */}
          <div className="mt-5">
            <div className="flex justify-between text-xs text-slate-500 mb-1.5">
              <span>{totalXp.toLocaleString()} XP</span>
              <span>Next: {nextLevelXp.toLocaleString()} XP ({nextLevel?.[0] ?? 'max'})</span>
            </div>
            <div className="h-2 rounded-full bg-surface-4 overflow-hidden">
              <div className="h-full rounded-full bg-gradient-to-r from-brand-cyan to-brand-indigo transition-all duration-700"
                style={{ width: `${xpProgress}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Map,      label: 'Topics Learned',  value: stats.topicsLearned,   color: 'text-brand-cyan',    bg: 'bg-brand-cyan/10' },
          { icon: Flame,    label: 'Day Streak',       value: `${stats.currentStreak ?? 0}d`, color: 'text-brand-amber',  bg: 'bg-brand-amber/10' },
          { icon: Star,     label: 'Rare Skills',      value: stats.rareTopicsCount, color: 'text-brand-indigo',  bg: 'bg-brand-indigo/10' },
          { icon: Trophy,   label: 'Badges Earned',    value: stats.badgesCount ?? 0,color: 'text-brand-emerald', bg: 'bg-brand-emerald/10' },
        ].map(s => (
          <div key={s.label} className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-4">
            <div className={`w-8 h-8 rounded-lg ${s.bg} flex items-center justify-center mb-3`}>
              <s.icon className={`w-4 h-4 ${s.color}`} />
            </div>
            <div className={`text-2xl font-display font-bold ${s.color}`}>{String(s.value ?? 0)}</div>
            <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* AI Recommendations */}
        <div className="lg:col-span-2">
          <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-brand-cyan" />
                <h2 className="text-sm font-semibold text-slate-200">Recommended Next</h2>
              </div>
              <Link href="/roadmap" className="text-xs text-slate-500 hover:text-brand-cyan flex items-center gap-1 transition-colors">
                View roadmap <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
            {recommendations.length === 0 ? (
              <div className="text-center py-6">
                <Map className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-sm text-slate-500">Start a branch to get recommendations</p>
                <Link href="/roadmap" className="btn-primary text-xs mt-3 inline-flex">Explore Roadmap</Link>
              </div>
            ) : (
              <div className="space-y-3">
                {recommendations.map((rec, i) => (
                  <Link key={i} href={`/roadmap?topic=${(rec as Record<string, unknown>).slug}`}
                    className="flex items-start gap-3 p-3 rounded-lg border border-transparent hover:border-[rgba(99,179,237,0.15)] hover:bg-surface-2 transition-all group">
                    <div className="w-6 h-6 rounded-full bg-brand-cyan/10 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-xs font-bold text-brand-cyan">{i + 1}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-slate-200 group-hover:text-brand-cyan transition-colors">
                        {(rec as Record<string, unknown>).topicName as string}
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 truncate">
                        {(rec as Record<string, unknown>).reasoning as string}
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-brand-cyan transition-all mt-0.5 group-hover:translate-x-0.5" />
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-4 h-4 text-brand-emerald" />
              <h2 className="text-sm font-semibold text-slate-200">Recent Progress</h2>
            </div>
            {recentProgress.length === 0 ? (
              <p className="text-xs text-slate-600 py-4 text-center">No recent activity</p>
            ) : (
              <div className="space-y-3">
                {recentProgress.map((p, i) => {
                  const prog = p as Record<string, unknown>
                  return (
                    <div key={i} className="flex items-start gap-2.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-brand-emerald mt-1.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-slate-300 truncate">{prog.topicName as string}</div>
                        <div className="text-[11px] text-slate-600">{prog.branchSlug as string} · +{prog.xpEarned as number} XP</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}

            {/* Quick links */}
            <div className="mt-4 pt-4 border-t border-[rgba(99,179,237,0.08)] space-y-2">
              {[
                { href: '/cv',         label: '→ Update CV',        color: 'text-brand-cyan' },
                { href: '/leaderboard',label: '→ Leaderboard',      color: 'text-brand-indigo' },
                { href: '/badges',     label: '→ Earn badges',      color: 'text-brand-amber' },
              ].map(l => (
                <Link key={l.href} href={l.href} className={`block text-xs ${l.color} hover:opacity-80 transition-opacity`}>{l.label}</Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function DashboardSkeleton() {
  return (
    <div className="px-6 py-6 space-y-6">
      <div className="h-36 rounded-xl bg-surface-2 animate-pulse" />
      <div className="grid grid-cols-4 gap-4">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-24 rounded-xl bg-surface-2 animate-pulse" />)}</div>
      <div className="grid grid-cols-3 gap-5"><div className="col-span-2 h-64 rounded-xl bg-surface-2 animate-pulse" /><div className="h-64 rounded-xl bg-surface-2 animate-pulse" /></div>
    </div>
  )
}
