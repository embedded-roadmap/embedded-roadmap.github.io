'use client'
// src/app/(dashboard)/analytics/page.tsx

import { useEffect, useState } from 'react'
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
         BarChart, Bar, XAxis, YAxis, Tooltip, LineChart, Line, Area, AreaChart } from 'recharts'
import { TrendingUp, Award, Zap, Globe, Star } from 'lucide-react'
import { RANK_LABELS, RARITY_LABELS, xpToNextRank, type RankTier, type RarityTier } from '@/types'
import { clsx } from 'clsx'

const RARITY_COLORS: Record<string, string> = {
  legendary: '#fbbf24', elite: '#818cf8', rare: '#38bdf8',
  uncommon: '#34d399', common: '#94a3b8', ubiquitous: '#64748b',
}

export default function AnalyticsPage() {
  const [data, setData] = useState<Record<string, unknown> | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/analytics').then(r => r.json()).then(({ data }) => {
      setData(data)
      setLoading(false)
    })
  }, [])

  if (loading) return <AnalyticsSkeleton />
  if (!data) return <div className="p-8 text-slate-500 text-sm">Failed to load analytics.</div>

  const user = data.user as Record<string, unknown>
  const radarData = (data.radarData as Record<string, unknown>[]) ?? []
  const xpHistory = (data.xpHistory as { date: string; xp: number }[]) ?? []
  const heatmap = (data.heatmap as Record<string, unknown>[]) ?? []
  const topSkills = (data.topSkills as { name: string; rarityTier: string; branchName: string; xpEarned: number }[]) ?? []

  const { nextRank, xpNeeded, pct } = xpToNextRank(Number(user.totalXp ?? 0))
  const level = user.currentLevel as RankTier ?? 'intern'

  return (
    <div className="px-6 py-6 space-y-6 max-w-5xl">
      <div>
        <h1 className="text-xl font-display font-bold text-slate-100 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-brand-cyan" /> Engineering Analytics
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">Your skill profile, progression, and global positioning.</p>
      </div>

      {/* Top stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Rank',            value: RANK_LABELS[level], sub: `${Number(user.totalXp??0).toLocaleString()} XP`, color: 'text-brand-cyan' },
          { label: 'Global Percentile',value: `Top ${(100 - Number(user.globalPercentile ?? 0)).toFixed(1)}%`, sub: 'of all engineers', color: 'text-brand-indigo' },
          { label: 'Topics Learned',  value: user.topicsLearned, sub: 'across all branches', color: 'text-brand-emerald' },
          { label: 'Rare Skills',     value: user.rareTopicsCount, sub: 'rare/elite/legendary', color: 'text-brand-amber' },
        ].map(s => (
          <div key={s.label} className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-4">
            <div className={`text-2xl font-display font-bold ${s.color}`}>{String(s.value ?? 0)}</div>
            <div className="text-xs font-medium text-slate-300 mt-0.5">{s.label}</div>
            <div className="text-[11px] text-slate-500">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* XP progress bar */}
      {nextRank && (
        <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-5">
          <div className="flex justify-between text-sm mb-2">
            <span className="font-medium text-slate-200">{RANK_LABELS[level]}</span>
            <span className="text-slate-500">{xpNeeded.toLocaleString()} XP to {RANK_LABELS[nextRank]}</span>
          </div>
          <div className="h-2.5 rounded-full bg-surface-4 overflow-hidden">
            <div className="h-full rounded-full bg-gradient-to-r from-brand-cyan to-brand-indigo transition-all duration-700"
              style={{ width: `${pct}%` }} />
          </div>
          <div className="text-xs text-slate-600 mt-1">{pct.toFixed(1)}% to next rank</div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">

        {/* Radar chart */}
        {radarData.length > 0 && (
          <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-5">
            <h2 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
              <Globe className="w-4 h-4 text-brand-cyan" /> Competency by Domain
            </h2>
            <ResponsiveContainer width="100%" height={260}>
              <RadarChart data={radarData.map(d => ({ ...d, fullMark: 100 }))}>
                <PolarGrid stroke="rgba(99,179,237,0.1)" />
                <PolarAngleAxis dataKey="label" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Radar name="Score" dataKey="score" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.15} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* XP over time */}
        {xpHistory.length > 0 && (
          <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-5">
            <h2 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-brand-amber" /> XP Gained (30 days)
            </h2>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={xpHistory}>
                <defs>
                  <linearGradient id="xpGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#38bdf8" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 10 }}
                  tickFormatter={d => d.slice(5)} />
                <YAxis tick={{ fill: '#64748b', fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ background: '#0d1420', border: '1px solid rgba(99,179,237,0.2)', borderRadius: 8, fontSize: 12 }}
                  labelStyle={{ color: '#94a3b8' }} itemStyle={{ color: '#38bdf8' }} />
                <Area type="monotone" dataKey="xp" stroke="#38bdf8" fill="url(#xpGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Specialization heatmap */}
      {heatmap.length > 0 && (
        <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-5">
          <h2 className="text-sm font-semibold text-slate-300 mb-4">Specialization Heatmap</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {heatmap.slice(0, 12).map((h) => {
              const pct = Number(h.pctComplete ?? 0)
              const color = (h.color as string) ?? '#38bdf8'
              return (
                <div key={h.branchSlug as string}
                  className="bg-[#0a1020] border border-[rgba(99,179,237,0.08)] rounded-lg p-3">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-medium text-slate-300 leading-tight">
                      {(h.branchName as string).replace(' & ', ' &\n')}
                    </span>
                    <span className="text-xs text-slate-500 ml-2 shrink-0">{pct}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-surface-4 overflow-hidden">
                    <div className="h-full rounded-full transition-all"
                      style={{ width: `${Math.max(pct, 2)}%`, backgroundColor: color }} />
                  </div>
                  <div className="text-[10px] text-slate-600 mt-1.5">
                    {h.topicsLearned as number}/{h.topicsTotal as number} topics
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Top skills */}
      {topSkills.length > 0 && (
        <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-5">
          <h2 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
            <Star className="w-4 h-4 text-brand-amber" /> Rarest Skills
          </h2>
          <div className="space-y-2">
            {topSkills.map((skill, i) => (
              <div key={i} className="flex items-center gap-3 py-1.5">
                <span className="text-xs text-slate-600 w-4 text-right">{i + 1}</span>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-200">{skill.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-medium"
                      style={{ color: RARITY_COLORS[skill.rarityTier] ?? '#94a3b8', background: `${RARITY_COLORS[skill.rarityTier] ?? '#94a3b8'}18` }}>
                      {RARITY_LABELS[skill.rarityTier as RarityTier] ?? skill.rarityTier}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600 mt-0.5">{skill.branchName}</div>
                </div>
                <span className="text-xs text-slate-500 flex items-center gap-0.5">
                  <Zap className="w-3 h-3" />{skill.xpEarned}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function AnalyticsSkeleton() {
  return (
    <div className="px-6 py-6 space-y-6">
      <div className="h-8 w-48 bg-surface-2 rounded animate-pulse" />
      <div className="grid grid-cols-4 gap-4">{Array.from({length:4}).map((_,i)=><div key={i} className="h-24 bg-surface-2 rounded-xl animate-pulse" />)}</div>
      <div className="grid grid-cols-2 gap-5">{Array.from({length:2}).map((_,i)=><div key={i} className="h-72 bg-surface-2 rounded-xl animate-pulse" />)}</div>
    </div>
  )
}
