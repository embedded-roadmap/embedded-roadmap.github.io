'use client'
// src/app/(dashboard)/badges/page.tsx
import { useEffect, useState } from 'react'
import { Zap, Lock } from 'lucide-react'

type BadgeData = {
  id: string
  slug: string
  name: string
  description: string
  icon: string
  rarity: 'common' | 'uncommon' | 'rare' | 'legendary'
  xpReward: number
  earned?: boolean
  earnedAt?: string
  progress?: number
  progressMax?: number
}

const RARITY_STYLES: Record<string, { border: string; bg: string; glow: string; label: string }> = {
  common:    { border: 'border-slate-500/40',   bg: 'bg-slate-500/10',   glow: '',                                   label: 'Common' },
  uncommon:  { border: 'border-emerald-500/40', bg: 'bg-emerald-500/10', glow: '',                                   label: 'Uncommon' },
  rare:      { border: 'border-cyan-400/50',    bg: 'bg-cyan-400/10',    glow: 'shadow-[0_0_12px_rgba(56,189,248,0.2)]', label: 'Rare' },
  legendary: { border: 'border-amber-400/60',   bg: 'bg-amber-400/10',   glow: 'shadow-[0_0_16px_rgba(251,191,36,0.25)]', label: 'Legendary' },
}

export default function BadgesPage() {
  const [badges, setBadges] = useState<BadgeData[]>([])
  const [filter, setFilter] = useState<'all' | 'earned' | 'locked'>('all')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/badges').then(r => r.json()).then(({ data }) => {
      if (data?.badges) setBadges(data.badges)
      setLoading(false)
    })
  }, [])

  const earned = badges.filter(b => b.earned)
  const filtered = filter === 'earned' ? earned
    : filter === 'locked' ? badges.filter(b => !b.earned)
    : badges

  return (
    <div className="px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-display font-bold text-slate-100 flex items-center gap-2">
            <Zap className="w-5 h-5 text-brand-amber" />
            Badges
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            {earned.length}/{badges.length} earned · Rare badges auto-populate your CV
          </p>
        </div>
        <div className="flex rounded-lg border border-[rgba(99,179,237,0.15)] overflow-hidden text-xs">
          {(['all', 'earned', 'locked'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 font-medium capitalize transition-colors ${
                filter === f ? 'bg-brand-cyan/10 text-brand-cyan' : 'text-slate-500 hover:text-slate-300'
              }`}>
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Progress bar */}
      <div className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-xl p-4">
        <div className="flex justify-between text-xs text-slate-500 mb-2">
          <span>Badge collection progress</span>
          <span className="text-slate-300">{earned.length} / {badges.length}</span>
        </div>
        <div className="h-2 rounded-full bg-surface-4 overflow-hidden">
          <div className="h-full rounded-full bg-gradient-to-r from-brand-amber to-brand-cyan"
            style={{ width: `${badges.length > 0 ? (earned.length / badges.length) * 100 : 0}%` }} />
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {Array.from({ length: 15 }).map((_, i) => (
            <div key={i} className="aspect-square rounded-xl bg-surface-2 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-slate-600">
          <Zap className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No badges yet in this category</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filtered.map(badge => {
            const style = RARITY_STYLES[badge.rarity] ?? RARITY_STYLES.common
            return (
              <div key={badge.id}
                className={`relative rounded-xl border p-4 text-center transition-all ${style.border} ${style.bg} ${style.glow} ${
                  badge.earned ? 'opacity-100' : 'opacity-50 grayscale'
                }`}
              >
                {/* Lock overlay */}
                {!badge.earned && (
                  <div className="absolute top-2 right-2">
                    <Lock className="w-3 h-3 text-slate-600" />
                  </div>
                )}

                {/* Icon */}
                <div className="text-3xl mb-2 leading-none">{badge.icon}</div>

                {/* Name */}
                <div className={`text-xs font-semibold mb-0.5 ${badge.earned ? 'text-slate-200' : 'text-slate-500'}`}>
                  {badge.name}
                </div>

                {/* Rarity */}
                <div className={`text-[10px] mb-2 ${
                  badge.rarity === 'legendary' ? 'text-amber-400' :
                  badge.rarity === 'rare'      ? 'text-cyan-400' :
                  badge.rarity === 'uncommon'  ? 'text-emerald-400' : 'text-slate-600'
                }`}>{style.label}</div>

                {/* Description */}
                <p className="text-[10px] text-slate-500 leading-relaxed line-clamp-2">{badge.description}</p>

                {/* XP reward */}
                {badge.xpReward > 0 && (
                  <div className="mt-2 flex items-center justify-center gap-1 text-[10px] text-slate-600">
                    <Zap className="w-2.5 h-2.5" />+{badge.xpReward} XP
                  </div>
                )}

                {/* Progress bar (for partial) */}
                {!badge.earned && badge.progress !== undefined && badge.progressMax && (
                  <div className="mt-2">
                    <div className="h-1 rounded-full bg-surface-4 overflow-hidden">
                      <div className="h-full rounded-full bg-brand-cyan/50"
                        style={{ width: `${(badge.progress / badge.progressMax) * 100}%` }} />
                    </div>
                    <div className="text-[10px] text-slate-600 mt-0.5">
                      {badge.progress}/{badge.progressMax}
                    </div>
                  </div>
                )}

                {/* Earned date */}
                {badge.earned && badge.earnedAt && (
                  <div className="mt-1.5 text-[10px] text-slate-600">
                    {new Date(badge.earnedAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
