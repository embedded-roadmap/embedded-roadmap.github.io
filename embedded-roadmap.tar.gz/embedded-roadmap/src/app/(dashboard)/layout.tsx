'use client'
// src/app/(dashboard)/layout.tsx
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useSession, signOut } from 'next-auth/react'
import {
  LayoutDashboard, Map, Trophy, FileText, FolderGit2,
  Settings, LogOut, Zap, Shield, ChevronRight, Search,
  BookOpen, User
} from 'lucide-react'
import { clsx } from 'clsx'
import { useEffect, useState } from 'react'

const NAV = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/roadmap',   label: 'Roadmap',   icon: Map },
  { href: '/badges',    label: 'Badges',    icon: Zap },
  { href: '/leaderboard', label: 'Leaderboard', icon: Trophy },
  { href: '/cv',        label: 'CV Builder', icon: FileText },
  { href: '/projects',  label: 'Projects',  icon: FolderGit2 },
]

const BOTTOM_NAV = [
  { href: '/settings', label: 'Settings',  icon: Settings },
]

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const { data: session } = useSession()
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div className="flex h-screen bg-surface-0 overflow-hidden">
      {/* Sidebar */}
      <aside className={clsx(
        'flex flex-col bg-surface-1 border-r border-border transition-all duration-200 shrink-0',
        collapsed ? 'w-14' : 'w-56'
      )}>
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-4 py-4 border-b border-border min-h-[57px]">
          <div className="w-7 h-7 rounded-md bg-gradient-to-br from-brand-cyan to-brand-indigo flex items-center justify-center shrink-0">
            <Zap className="w-3.5 h-3.5 text-surface-0" />
          </div>
          {!collapsed && (
            <span className="font-display font-bold text-sm text-slate-100 tracking-tight">
              EmbeddedRoadmap
            </span>
          )}
        </div>

        {/* Main nav */}
        <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || pathname.startsWith(href + '/')
            return (
              <Link key={href} href={href}
                className={clsx(
                  'flex items-center rounded px-2 py-2 text-sm transition-all duration-100',
                  collapsed ? 'justify-center' : 'gap-2.5',
                  active
                    ? 'bg-brand-cyan/10 text-brand-cyan'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-surface-3'
                )}
                title={collapsed ? label : undefined}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {!collapsed && <span>{label}</span>}
              </Link>
            )
          })}
        </nav>

        {/* Bottom section */}
        <div className="px-2 py-3 border-t border-border space-y-0.5">
          {BOTTOM_NAV.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href}
              className={clsx(
                'flex items-center rounded px-2 py-2 text-sm text-slate-400 hover:text-slate-100 hover:bg-surface-3 transition-all',
                collapsed ? 'justify-center' : 'gap-2.5'
              )}
              title={collapsed ? label : undefined}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {!collapsed && <span>{label}</span>}
            </Link>
          ))}

          {/* User */}
          {session?.user && (
            <div className={clsx(
              'flex items-center rounded px-2 py-2 gap-2',
              collapsed ? 'justify-center' : ''
            )}>
              <div className="w-6 h-6 rounded-full bg-brand-indigo/30 border border-brand-indigo/40 flex items-center justify-center shrink-0">
                <User className="w-3 h-3 text-brand-indigo" />
              </div>
              {!collapsed && (
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-slate-200 truncate">
                    {session.user.name ?? session.user.username}
                  </div>
                  <div className="text-[10px] text-slate-500 truncate">
                    {session.user.username}
                  </div>
                </div>
              )}
            </div>
          )}

          <button
            onClick={() => signOut({ callbackUrl: '/login' })}
            className={clsx(
              'w-full flex items-center rounded px-2 py-2 text-sm text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all',
              collapsed ? 'justify-center' : 'gap-2.5'
            )}
            title={collapsed ? 'Sign out' : undefined}
          >
            <LogOut className="w-4 h-4 shrink-0" />
            {!collapsed && <span>Sign out</span>}
          </button>

          {/* Collapse toggle */}
          <button
            onClick={() => setCollapsed(c => !c)}
            className="w-full flex items-center justify-center p-1.5 text-slate-600 hover:text-slate-400 transition-colors"
          >
            <ChevronRight className={clsx('w-3.5 h-3.5 transition-transform duration-200', collapsed ? '' : 'rotate-180')} />
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-hidden flex flex-col">
        {/* Topbar */}
        <header className="h-14 border-b border-border bg-surface-1/50 backdrop-blur-sm flex items-center px-6 gap-4 shrink-0">
          <div className="flex-1">
            {/* Breadcrumb */}
            <BreadcrumbNav pathname={pathname} />
          </div>
          <Link href="/search" className="flex items-center gap-2 px-3 py-1.5 rounded border border-border text-sm text-slate-500 hover:text-slate-300 hover:border-border-strong transition-all bg-surface-2 w-48">
            <Search className="w-3.5 h-3.5" />
            <span>Search topics...</span>
            <kbd className="ml-auto text-[10px] px-1.5 py-0.5 rounded bg-surface-3 text-slate-600">⌘K</kbd>
          </Link>
        </header>

        {/* Page content */}
        <div className="flex-1 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  )
}

function BreadcrumbNav({ pathname }: { pathname: string }) {
  const parts = pathname.split('/').filter(Boolean)
  const labels: Record<string, string> = {
    dashboard: 'Dashboard', roadmap: 'Roadmap', cv: 'CV Builder',
    badges: 'Badges', leaderboard: 'Leaderboard', projects: 'Projects',
    settings: 'Settings', profile: 'Profile',
  }
  return (
    <nav className="flex items-center gap-1.5 text-sm">
      {parts.map((p, i) => (
        <span key={p} className="flex items-center gap-1.5">
          {i > 0 && <span className="text-slate-600">/</span>}
          <span className={i === parts.length - 1 ? 'text-slate-200 font-medium' : 'text-slate-500'}>
            {labels[p] ?? p}
          </span>
        </span>
      ))}
    </nav>
  )
}
