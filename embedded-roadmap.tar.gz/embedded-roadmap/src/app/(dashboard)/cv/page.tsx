'use client'
// src/app/(dashboard)/cv/page.tsx
// Full CV Builder — multi-section editor with live preview

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { toast } from 'sonner'
import {
  FileText, Download, Share2, Eye, EyeOff, Plus, Trash2, ChevronDown,
  ChevronUp, Save, ExternalLink, Copy, Check, Briefcase, GraduationCap,
  Award, BookOpen, Wrench, Globe, Mail, Linkedin, Github, Code
} from 'lucide-react'
import type { EngineerCv, CvTemplateId, OpenToWorkStatus } from '@/types'

// ── Metadata ──────────────────────────────────────────────────

export const metadata = { title: 'CV Builder' }

// ── Main Page ─────────────────────────────────────────────────

export default function CvPage() {
  const { data: session } = useSession()
  const [activeTab, setActiveTab] = useState<'personal' | 'experience' | 'education' | 'skills' | 'projects' | 'extra' | 'preview'>('personal')
  const [cv, setCv] = useState<Partial<EngineerCv>>({})
  const [privacy, setPrivacy] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [exporting, setExporting] = useState(false)
  const [shareToken, setShareToken] = useState<string | null>(null)
  const [shareEnabled, setShareEnabled] = useState(false)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    fetch('/api/cv').then(r => r.json()).then(({ data }) => {
      if (data?.cv) setCv(data.cv)
      if (data?.privacy) setPrivacy(data.privacy)
      setLoading(false)
    })
    fetch('/api/cv/export').then(r => r.json()).then(({ data }) => {
      if (data?.shareToken) setShareToken(data.shareToken)
      if (data?.shareEnabled) setShareEnabled(data.shareEnabled)
    })
  }, [])

  const save = useCallback(async (updates: Partial<EngineerCv>) => {
    setSaving(true)
    try {
      await fetch('/api/cv', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(updates) })
      setCv(prev => ({ ...prev, ...updates }))
      toast.success('CV saved')
    } catch { toast.error('Save failed') }
    finally { setSaving(false) }
  }, [])

  const exportPdf = async (template: CvTemplateId = 'precision', atsMode = false) => {
    setExporting(true)
    try {
      const res = await fetch('/api/cv/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ template, atsMode }),
      })
      if (!res.ok) throw new Error('Export failed')
      const html = await res.text()
      // Open in new tab → user uses browser print to PDF
      const w = window.open('', '_blank')
      if (w) {
        w.document.write(html)
        w.document.close()
        setTimeout(() => w.print(), 500)
      }
      toast.success('PDF opened — use Print → Save as PDF')
    } catch { toast.error('Export failed') }
    finally { setExporting(false) }
  }

  const toggleShare = async () => {
    const action = shareEnabled ? 'disable-share' : 'enable-share'
    const res = await fetch(`/api/cv/export?action=${action}`)
    const { data } = await res.json()
    setShareEnabled(!shareEnabled)
    if (data?.token) setShareToken(data.token)
    toast.success(shareEnabled ? 'Share link disabled' : 'Share link enabled')
  }

  const copyShareLink = () => {
    if (!shareToken) return
    navigator.clipboard.writeText(`${window.location.origin}/r/${shareToken}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
    toast.success('Link copied!')
  }

  if (loading) return <CvSkeleton />

  const TABS = [
    { id: 'personal',   label: 'Personal',   icon: FileText },
    { id: 'experience', label: 'Experience',  icon: Briefcase },
    { id: 'education',  label: 'Education',   icon: GraduationCap },
    { id: 'skills',     label: 'Skills',      icon: Wrench },
    { id: 'projects',   label: 'Projects',    icon: Code },
    { id: 'extra',      label: 'Extra',       icon: Award },
    { id: 'preview',    label: 'Preview',     icon: Eye },
  ] as const

  return (
    <div className="flex h-full">
      {/* Left: editor */}
      <div className="flex-1 flex flex-col overflow-hidden border-r border-border">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 border-b border-border shrink-0">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-xl font-display font-bold text-slate-100">CV Builder</h1>
              <p className="text-sm text-slate-500 mt-0.5">
                Automatically synced with your roadmap progress
              </p>
            </div>
            <div className="flex items-center gap-2">
              {/* Share toggle */}
              <button
                onClick={toggleShare}
                className={`btn-secondary text-xs ${shareEnabled ? 'border-brand-emerald/40 text-brand-emerald' : ''}`}
              >
                <Share2 className="w-3.5 h-3.5" />
                {shareEnabled ? 'Link active' : 'Share link'}
              </button>
              {shareEnabled && shareToken && (
                <button onClick={copyShareLink} className="btn-ghost text-xs">
                  {copied ? <Check className="w-3.5 h-3.5 text-brand-emerald" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              )}
              {/* Export dropdown */}
              <ExportMenu onExport={exportPdf} loading={exporting} />
            </div>
          </div>

          {/* Open to work banner */}
          <OpenToWorkSelector value={cv.openToWork ?? 'not_looking'} onChange={v => save({ openToWork: v })} />
        </div>

        {/* Tab bar */}
        <div className="flex gap-0.5 px-6 pt-3 border-b border-border shrink-0 overflow-x-auto">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setActiveTab(id as typeof activeTab)}
              className={`flex items-center gap-1.5 px-3 py-2 text-sm rounded-t transition-all whitespace-nowrap ${
                activeTab === id
                  ? 'text-brand-cyan border-b-2 border-brand-cyan -mb-px'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          {activeTab === 'personal'   && <PersonalTab cv={cv} onSave={save} />}
          {activeTab === 'experience' && <ExperienceTab userId={session?.user?.id ?? ''} />}
          {activeTab === 'education'  && <EducationTab userId={session?.user?.id ?? ''} />}
          {activeTab === 'skills'     && <SkillsTab cv={cv} onSave={save} />}
          {activeTab === 'projects'   && <ProjectsTab userId={session?.user?.id ?? ''} />}
          {activeTab === 'extra'      && <ExtraTab userId={session?.user?.id ?? ''} />}
          {activeTab === 'preview'    && <PreviewTab onExport={exportPdf} />}
        </div>
      </div>

      {/* Right: live stats panel */}
      <div className="w-72 shrink-0 overflow-y-auto">
        <CvStatsPanel cv={cv} />
      </div>
    </div>
  )
}

// ── Tab: Personal ─────────────────────────────────────────────

function PersonalTab({ cv, onSave }: { cv: Partial<EngineerCv>; onSave: (d: Partial<EngineerCv>) => void }) {
  const [form, setForm] = useState({
    fullName: cv.fullName ?? '',
    title:    cv.title ?? '',
    email:    cv.email ?? '',
    phone:    cv.phone ?? '',
    location: cv.location ?? '',
    summary:  cv.summary ?? '',
    linkedin: cv.socialLinks?.linkedin ?? '',
    github:   cv.socialLinks?.github ?? '',
    hackaday: cv.socialLinks?.hackaday ?? '',
    website:  cv.socialLinks?.website ?? '',
  })
  const [dirty, setDirty] = useState(false)

  const set = (k: string, v: string) => { setForm(f => ({ ...f, [k]: v })); setDirty(true) }

  const handleSave = () => {
    onSave({
      fullName: form.fullName, title: form.title,
      email: form.email, phone: form.phone || undefined,
      location: form.location || undefined, summary: form.summary || undefined,
      socialLinks: {
        linkedin: form.linkedin || null, github: form.github || null,
        hackaday: form.hackaday || null, website: form.website || null,
        gitlab: cv.socialLinks?.gitlab ?? null, email: cv.email ?? null,
      },
    })
    setDirty(false)
  }

  return (
    <div className="space-y-5 max-w-xl">
      <SectionHeader icon={FileText} title="Personal Information" />
      <div className="grid grid-cols-2 gap-4">
        <FormField label="Full Name" required>
          <input className="input" value={form.fullName} onChange={e => set('fullName', e.target.value)} placeholder="Jane Smith" />
        </FormField>
        <FormField label="Professional Title">
          <input className="input" value={form.title} onChange={e => set('title', e.target.value)} placeholder="Senior Embedded Systems Engineer" />
        </FormField>
        <FormField label="Email" required>
          <input className="input" type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="jane@example.com" />
        </FormField>
        <FormField label="Phone">
          <input className="input" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+1 555 000 0000" />
        </FormField>
        <FormField label="Location" className="col-span-2">
          <input className="input" value={form.location} onChange={e => set('location', e.target.value)} placeholder="Istanbul, Turkey" />
        </FormField>
      </div>

      <FormField label="Professional Summary">
        <textarea className="textarea h-28" value={form.summary} onChange={e => set('summary', e.target.value)}
          placeholder="Results-driven embedded systems engineer with 6+ years designing high-voltage systems and medical wearables..." />
        <p className="text-xs text-slate-500 mt-1">{form.summary.length}/1500 chars — Shown at top of CV</p>
      </FormField>

      <SectionHeader icon={Globe} title="Professional Links" className="mt-2" />
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Linkedin className="w-4 h-4 text-[#0A66C2] shrink-0" />
          <input className="input" value={form.linkedin} onChange={e => set('linkedin', e.target.value)} placeholder="https://linkedin.com/in/username" />
        </div>
        <div className="flex items-center gap-2">
          <Github className="w-4 h-4 text-slate-300 shrink-0" />
          <input className="input" value={form.github} onChange={e => set('github', e.target.value)} placeholder="https://github.com/username" />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-brand-amber text-sm shrink-0 w-4 text-center">H</span>
          <input className="input" value={form.hackaday} onChange={e => set('hackaday', e.target.value)} placeholder="https://hackaday.io/username" />
        </div>
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-slate-400 shrink-0" />
          <input className="input" value={form.website} onChange={e => set('website', e.target.value)} placeholder="https://yoursite.com" />
        </div>
      </div>

      {dirty && (
        <button onClick={handleSave} className="btn-primary">
          <Save className="w-3.5 h-3.5" /> Save Personal Info
        </button>
      )}
    </div>
  )
}

// ── Tab: Experience ───────────────────────────────────────────

function ExperienceTab({ userId }: { userId: string }) {
  const [items, setItems] = useState<Record<string, unknown>[]>([])
  const [expanded, setExpanded] = useState<string | null>('new')
  const [form, setForm] = useState<Record<string, unknown>>({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetch('/api/cv/sections/experience').then(r => r.json()).then(({ data }) => {
      if (Array.isArray(data)) setItems(data)
    })
  }, [])

  const save = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/cv/sections/experience', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
      })
      const { data } = await res.json()
      if (data) {
        setItems(prev => {
          const idx = prev.findIndex(i => (i as Record<string, unknown>).id === (data as Record<string, unknown>).id)
          return idx >= 0 ? prev.map((i, j) => j === idx ? data : i) : [data, ...prev]
        })
        setExpanded(null)
        setForm({})
        toast.success('Experience saved')
      }
    } catch { toast.error('Save failed') }
    finally { setSaving(false) }
  }

  const del = async (id: string) => {
    await fetch(`/api/cv/sections/experience?id=${id}`, { method: 'DELETE' })
    setItems(prev => prev.filter(i => (i as Record<string, unknown>).id !== id))
    toast.success('Removed')
  }

  return (
    <div className="space-y-4 max-w-xl">
      <div className="flex items-center justify-between">
        <SectionHeader icon={Briefcase} title="Work Experience" />
        <button onClick={() => { setExpanded('new'); setForm({}) }} className="btn-ghost text-xs">
          <Plus className="w-3.5 h-3.5" /> Add
        </button>
      </div>

      {expanded === 'new' && (
        <ExperienceForm form={form} onChange={setForm} onSave={save} onCancel={() => setExpanded(null)} saving={saving} />
      )}

      {items.map(item => {
        const it = item as Record<string, unknown>
        const isOpen = expanded === it.id
        return (
          <div key={it.id as string} className="card p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="font-medium text-sm text-slate-100">{it.title as string}</div>
                <div className="text-xs text-brand-cyan mt-0.5">{it.company as string}</div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => { setExpanded(isOpen ? null : it.id as string); setForm(it) }} className="btn-ghost p-1">
                  {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
                <button onClick={() => del(it.id as string)} className="btn-ghost p-1 text-red-400 hover:text-red-300">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            {isOpen && (
              <div className="mt-4 pt-4 border-t border-border">
                <ExperienceForm form={form} onChange={setForm} onSave={save} onCancel={() => setExpanded(null)} saving={saving} />
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

function ExperienceForm({ form, onChange, onSave, onCancel, saving }: {
  form: Record<string, unknown>
  onChange: (f: Record<string, unknown>) => void
  onSave: () => void
  onCancel: () => void
  saving: boolean
}) {
  const set = (k: string, v: unknown) => onChange({ ...form, [k]: v })
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <FormField label="Job Title" required>
          <input className="input" value={form.title as string ?? ''} onChange={e => set('title', e.target.value)} placeholder="Senior Embedded Engineer" />
        </FormField>
        <FormField label="Company" required>
          <input className="input" value={form.company as string ?? ''} onChange={e => set('company', e.target.value)} placeholder="Livewell Technologies" />
        </FormField>
        <FormField label="Start Date" required>
          <input className="input" type="month" value={form.startDate as string ?? ''} onChange={e => set('startDate', e.target.value + '-01')} />
        </FormField>
        <FormField label="End Date">
          <input className="input" type="month" value={form.endDate as string ?? ''} onChange={e => set('endDate', e.target.value + '-01')}
            disabled={Boolean(form.isCurrent)} placeholder="Leave blank if current" />
        </FormField>
      </div>
      <label className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer">
        <input type="checkbox" className="rounded" checked={Boolean(form.isCurrent)} onChange={e => set('isCurrent', e.target.checked)} />
        Current position
      </label>
      <FormField label="Description">
        <textarea className="textarea h-20" value={form.description as string ?? ''} onChange={e => set('description', e.target.value)} placeholder="Designed 10kV medical wearable circuits..." />
      </FormField>
      <FormField label="Key Highlights (one per line)">
        <textarea className="textarea h-20" value={(form.highlights as string[] ?? []).join('\n')} onChange={e => set('highlights', e.target.value.split('\n').filter(Boolean))} placeholder="Reduced power consumption by 40%..." />
      </FormField>
      <FormField label="Tech Stack (comma separated)">
        <input className="input" value={(form.techStack as string[] ?? []).join(', ')} onChange={e => set('techStack', e.target.value.split(',').map((s: string) => s.trim()).filter(Boolean))} placeholder="STM32, FreeRTOS, Altium Designer, SPI, I2C" />
      </FormField>
      <div className="flex gap-2 pt-2">
        <button onClick={onSave} disabled={saving} className="btn-primary text-xs">
          <Save className="w-3.5 h-3.5" /> {saving ? 'Saving…' : 'Save'}
        </button>
        <button onClick={onCancel} className="btn-ghost text-xs">Cancel</button>
      </div>
    </div>
  )
}

// ── Tab: Education ────────────────────────────────────────────

function EducationTab({ userId }: { userId: string }) {
  const [items, setItems] = useState<Record<string, unknown>[]>([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState<Record<string, unknown>>({})

  useEffect(() => {
    fetch('/api/cv/sections/education').then(r => r.json()).then(({ data }) => { if (Array.isArray(data)) setItems(data) })
  }, [])

  const save = async () => {
    const res = await fetch('/api/cv/sections/education', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
    const { data } = await res.json()
    if (data) { setItems(prev => [data, ...prev.filter(i => (i as Record<string, unknown>).id !== (data as Record<string, unknown>).id)]); setShowForm(false); setForm({}); toast.success('Saved') }
  }

  return (
    <div className="space-y-4 max-w-xl">
      <div className="flex items-center justify-between">
        <SectionHeader icon={GraduationCap} title="Education" />
        <button onClick={() => setShowForm(s => !s)} className="btn-ghost text-xs"><Plus className="w-3.5 h-3.5" /> Add</button>
      </div>
      {showForm && (
        <div className="card p-4 space-y-3">
          <FormField label="Institution" required>
            <input className="input" value={form.institution as string ?? ''} onChange={e => setForm(f => ({ ...f, institution: e.target.value }))} placeholder="Istanbul Technical University" />
          </FormField>
          <div className="grid grid-cols-2 gap-3">
            <FormField label="Degree">
              <input className="input" value={form.degree as string ?? ''} onChange={e => setForm(f => ({ ...f, degree: e.target.value }))} placeholder="B.Sc. / M.Sc. / Ph.D." />
            </FormField>
            <FormField label="Field of Study">
              <input className="input" value={form.field as string ?? ''} onChange={e => setForm(f => ({ ...f, field: e.target.value }))} placeholder="Electrical Engineering" />
            </FormField>
            <FormField label="Start Year" required>
              <input className="input" type="number" min="1990" max="2030" value={form.startYear as number ?? ''} onChange={e => setForm(f => ({ ...f, startYear: parseInt(e.target.value) }))} />
            </FormField>
            <FormField label="End Year">
              <input className="input" type="number" min="1990" max="2030" value={form.endYear as number ?? ''} onChange={e => setForm(f => ({ ...f, endYear: parseInt(e.target.value) }))} />
            </FormField>
            <FormField label="GPA">
              <input className="input" value={form.gpa as string ?? ''} onChange={e => setForm(f => ({ ...f, gpa: e.target.value }))} placeholder="3.85 / 4.0" />
            </FormField>
            <FormField label="Honors / Awards">
              <input className="input" value={form.honors as string ?? ''} onChange={e => setForm(f => ({ ...f, honors: e.target.value }))} placeholder="Cum Laude" />
            </FormField>
          </div>
          <div className="flex gap-2"><button onClick={save} className="btn-primary text-xs"><Save className="w-3.5 h-3.5" /> Save</button><button onClick={() => setShowForm(false)} className="btn-ghost text-xs">Cancel</button></div>
        </div>
      )}
      {items.map(item => {
        const it = item as Record<string, unknown>
        return (
          <div key={it.id as string} className="card p-4 flex items-start justify-between">
            <div>
              <div className="font-medium text-sm text-slate-100">{it.institution as string}</div>
              <div className="text-xs text-slate-400 mt-0.5">{it.degree as string}{it.field ? `, ${it.field}` : ''}</div>
              <div className="text-xs text-slate-600 mt-0.5">{it.startYear as number}–{(it.endYear as number) ?? 'present'}{it.gpa ? ` · GPA ${it.gpa}` : ''}</div>
            </div>
            <button onClick={async () => { await fetch(`/api/cv/sections/education?id=${it.id}`, { method: 'DELETE' }); setItems(p => p.filter(i => (i as Record<string, unknown>).id !== it.id)) }} className="btn-ghost p-1 text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
          </div>
        )
      })}
    </div>
  )
}

// ── Tab: Skills ───────────────────────────────────────────────

function SkillsTab({ cv, onSave }: { cv: Partial<EngineerCv>; onSave: (d: Partial<EngineerCv>) => void }) {
  const [roadmapTopics, setRoadmapTopics] = useState<Record<string, unknown>[]>([])
  const [manualSkills, setManualSkills] = useState<{ category: string; skills: string[] }[]>([])
  const [newCat, setNewCat] = useState('')
  const [newSkills, setNewSkills] = useState('')

  useEffect(() => {
    // Load roadmap progress for auto-populate preview
    fetch('/api/progress').then(r => r.json()).then(({ data }) => {
      if (data?.progress) setRoadmapTopics(data.progress.slice(0, 20))
    })
    fetch('/api/cv/sections/manual_skills').then(r => r.json()).then(({ data }) => {
      if (Array.isArray(data)) setManualSkills(data.map((d: Record<string, unknown>) => ({ category: d.category as string, skills: d.skills as string[] })))
    })
  }, [])

  const addCategory = async () => {
    if (!newCat.trim() || !newSkills.trim()) return
    const skills = newSkills.split(',').map(s => s.trim()).filter(Boolean)
    const res = await fetch('/api/cv/sections/manual_skills', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ category: newCat.trim(), skills }) })
    const { data } = await res.json()
    if (data) { setManualSkills(p => [...p, { category: newCat, skills }]); setNewCat(''); setNewSkills(''); toast.success('Skill category added') }
  }

  return (
    <div className="space-y-6 max-w-xl">
      {/* Auto-populated section */}
      <div>
        <SectionHeader icon={Wrench} title="Auto-Populated from Roadmap" />
        <div className="card p-4 mt-3">
          <p className="text-xs text-slate-500 mb-3">These skills are automatically generated from your completed topics:</p>
          {roadmapTopics.length === 0
            ? <p className="text-xs text-slate-600 italic">No topics learned yet. Start your roadmap to populate skills.</p>
            : <div className="flex flex-wrap gap-1.5">
                {roadmapTopics.map((t, i) => (
                  <span key={i} className="badge-cyan text-xs">{(t as Record<string, unknown>).topicName as string ?? (t as Record<string, unknown>).name as string}</span>
                ))}
              </div>
          }
        </div>
      </div>

      {/* Manual skill categories */}
      <div>
        <SectionHeader icon={Plus} title="Custom Skill Categories" />
        <div className="space-y-3 mt-3">
          {manualSkills.map((cat, i) => (
            <div key={i} className="card p-3 flex items-start justify-between gap-3">
              <div className="flex-1">
                <div className="text-xs font-semibold text-slate-300">{cat.category}</div>
                <div className="text-xs text-slate-500 mt-1">{cat.skills.join(', ')}</div>
              </div>
            </div>
          ))}
          <div className="card p-4 space-y-3">
            <FormField label="Category Name">
              <input className="input" value={newCat} onChange={e => setNewCat(e.target.value)} placeholder="e.g. Programming Languages, EDA Tools, Standards" />
            </FormField>
            <FormField label="Skills (comma separated)">
              <input className="input" value={newSkills} onChange={e => setNewSkills(e.target.value)} placeholder="C/C++, Python, MATLAB, Altium, KiCad" />
            </FormField>
            <button onClick={addCategory} className="btn-primary text-xs"><Plus className="w-3.5 h-3.5" /> Add Category</button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Tab: Projects ─────────────────────────────────────────────

function ProjectsTab({ userId }: { userId: string }) {
  const [items, setItems] = useState<Record<string, unknown>[]>([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState<Record<string, unknown>>({})

  useEffect(() => {
    fetch('/api/cv/sections/projects').then(r => r.json()).then(({ data }) => { if (Array.isArray(data)) setItems(data) })
  }, [])

  const set = (k: string, v: unknown) => setForm(f => ({ ...f, [k]: v }))

  const save = async () => {
    const res = await fetch('/api/cv/sections/projects', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
    const { data } = await res.json()
    if (data) { setItems(prev => [data, ...prev.filter(i => (i as Record<string, unknown>).id !== (data as Record<string, unknown>).id)]); setShowForm(false); setForm({}); toast.success('Project saved') }
  }

  const PLATFORMS = [
    { value: 'github', label: 'GitHub', color: 'text-slate-300' },
    { value: 'gitlab', label: 'GitLab', color: 'text-orange-400' },
    { value: 'hackaday', label: 'Hackaday.io', color: 'text-brand-amber' },
    { value: 'personal', label: 'Personal Site', color: 'text-brand-cyan' },
    { value: 'other', label: 'Other', color: 'text-slate-500' },
  ]

  return (
    <div className="space-y-4 max-w-xl">
      <div className="flex items-center justify-between">
        <SectionHeader icon={Code} title="Engineering Projects" />
        <button onClick={() => setShowForm(s => !s)} className="btn-ghost text-xs"><Plus className="w-3.5 h-3.5" /> Add Project</button>
      </div>

      {showForm && (
        <div className="card p-5 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <FormField label="Project Title" required className="col-span-2">
              <input className="input" value={form.title as string ?? ''} onChange={e => set('title', e.target.value)} placeholder="High-Voltage ECG Front-End Design" />
            </FormField>
            <FormField label="Platform">
              <select className="input" value={form.platform as string ?? 'github'} onChange={e => set('platform', e.target.value)}>
                {PLATFORMS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
              </select>
            </FormField>
            <FormField label="Repository URL">
              <input className="input" value={form.repoUrl as string ?? ''} onChange={e => set('repoUrl', e.target.value)} placeholder="https://github.com/..." />
            </FormField>
          </div>
          <FormField label="Description">
            <textarea className="textarea h-20" value={form.description as string ?? ''} onChange={e => set('description', e.target.value)} placeholder="Developed a 10kV isolation barrier..." />
          </FormField>
          <div className="grid grid-cols-3 gap-3">
            <FormField label="Hardware Stack">
              <input className="input" value={(form.hardwareStack as string[] ?? []).join(', ')} onChange={e => set('hardwareStack', e.target.value.split(',').map((s: string) => s.trim()).filter(Boolean))} placeholder="STM32, TI ADS1299" />
            </FormField>
            <FormField label="Firmware Stack">
              <input className="input" value={(form.firmwareStack as string[] ?? []).join(', ')} onChange={e => set('firmwareStack', e.target.value.split(',').map((s: string) => s.trim()).filter(Boolean))} placeholder="FreeRTOS, HAL" />
            </FormField>
            <FormField label="Tech Stack">
              <input className="input" value={(form.techStack as string[] ?? []).join(', ')} onChange={e => set('techStack', e.target.value.split(',').map((s: string) => s.trim()).filter(Boolean))} placeholder="C, Python, KiCad" />
            </FormField>
          </div>
          <label className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer">
            <input type="checkbox" className="rounded" checked={Boolean(form.isFeatured)} onChange={e => set('isFeatured', e.target.checked)} />
            Feature on CV and public profile
          </label>
          <div className="flex gap-2"><button onClick={save} className="btn-primary text-xs"><Save className="w-3.5 h-3.5" /> Save</button><button onClick={() => setShowForm(false)} className="btn-ghost text-xs">Cancel</button></div>
        </div>
      )}

      {items.map(item => {
        const it = item as Record<string, unknown>
        return (
          <div key={it.id as string} className="card p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm text-slate-100">{it.title as string}</span>
                  {it.isFeatured && <span className="badge-amber text-[10px]">Featured</span>}
                </div>
                {it.repoUrl && <a href={it.repoUrl as string} target="_blank" rel="noopener" className="text-xs text-brand-cyan hover:underline flex items-center gap-1 mt-0.5"><ExternalLink className="w-3 h-3" />{(it.repoUrl as string).replace('https://', '')}</a>}
                <div className="text-xs text-slate-500 mt-1">{(it.techStack as string[] ?? []).join(' · ')}</div>
              </div>
              <button onClick={async () => { await fetch(`/api/cv/sections/projects?id=${it.id}`, { method: 'DELETE' }); setItems(p => p.filter(i => (i as Record<string, unknown>).id !== it.id)) }} className="btn-ghost p-1 text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── Tab: Extra ────────────────────────────────────────────────

function ExtraTab({ userId }: { userId: string }) {
  return (
    <div className="space-y-6 max-w-xl">
      <GenericListSection section="certifications" title="Certifications" icon={Award} fields={[
        { key: 'name', label: 'Certification Name', required: true, placeholder: 'IPC-A-610, ISO 26262, OSCP' },
        { key: 'issuer', label: 'Issuer', placeholder: 'IPC, TÜV, SANS' },
        { key: 'issuedDate', label: 'Issue Date', type: 'date' },
        { key: 'url', label: 'Credential URL', placeholder: 'https://...' },
      ]} />
      <GenericListSection section="publications" title="Publications" icon={BookOpen} fields={[
        { key: 'title', label: 'Title', required: true, placeholder: 'Capacitance Estimation in Wearable ECG...' },
        { key: 'venue', label: 'Venue / Journal', placeholder: 'IEEE Transactions on Biomedical Engineering' },
        { key: 'year', label: 'Year', type: 'number' },
        { key: 'doi', label: 'DOI', placeholder: '10.1109/TBME.2024.xxxx' },
      ]} />
      <GenericListSection section="patents" title="Patents" icon={Wrench} fields={[
        { key: 'title', label: 'Patent Title', required: true },
        { key: 'patentNumber', label: 'Patent Number', placeholder: 'US11,234,567' },
        { key: 'jurisdiction', label: 'Jurisdiction', placeholder: 'US, EP, TR' },
        { key: 'grantDate', label: 'Grant Date', type: 'date' },
      ]} />
      <GenericListSection section="awards" title="Awards & Recognition" icon={Award} fields={[
        { key: 'title', label: 'Award', required: true, placeholder: 'Best Hardware Design Award' },
        { key: 'issuer', label: 'Organization', placeholder: 'IEEE' },
        { key: 'year', label: 'Year', type: 'number' },
        { key: 'description', label: 'Description' },
      ]} />
    </div>
  )
}

// ── Tab: Preview ──────────────────────────────────────────────

function PreviewTab({ onExport }: { onExport: (t: CvTemplateId, ats: boolean) => void }) {
  const templates: { id: CvTemplateId; label: string; desc: string }[] = [
    { id: 'precision', label: 'Precision', desc: 'Clean professional — recommended' },
    { id: 'vector', label: 'Vector', desc: 'Dark sidebar, two-column layout' },
    { id: 'circuit', label: 'Circuit', desc: 'Engineering blue aesthetic' },
    { id: 'minimal', label: 'Minimal / ATS', desc: 'Pure text — maximum ATS compatibility' },
  ]

  return (
    <div className="space-y-6 max-w-xl">
      <SectionHeader icon={Eye} title="Export & Templates" />

      <div className="grid grid-cols-2 gap-3">
        {templates.map(t => (
          <div key={t.id} className="card-hover p-4 cursor-pointer" onClick={() => onExport(t.id, t.id === 'minimal')}>
            <div className="font-medium text-sm text-slate-100">{t.label}</div>
            <div className="text-xs text-slate-500 mt-0.5">{t.desc}</div>
            <button className="btn-primary mt-3 text-xs w-full justify-center">
              <Download className="w-3.5 h-3.5" /> Export PDF
            </button>
          </div>
        ))}
      </div>

      <div className="card p-4 bg-brand-cyan/5 border-brand-cyan/20">
        <div className="text-xs font-semibold text-brand-cyan mb-1">💡 PDF Export Guide</div>
        <div className="text-xs text-slate-400 space-y-1">
          <p>1. Click "Export PDF" to open CV in new tab</p>
          <p>2. Press <kbd className="px-1.5 py-0.5 bg-surface-3 rounded text-[10px]">Ctrl+P</kbd> / <kbd className="px-1.5 py-0.5 bg-surface-3 rounded text-[10px]">⌘P</kbd></p>
          <p>3. Choose "Save as PDF" as destination</p>
          <p>4. Set margins to "None" for best results</p>
        </div>
      </div>
    </div>
  )
}

// ── Stats Sidebar ─────────────────────────────────────────────

function CvStatsPanel({ cv }: { cv: Partial<EngineerCv> }) {
  const [stats, setStats] = useState<Record<string, unknown>>({})

  useEffect(() => {
    fetch('/api/progress').then(r => r.json()).then(({ data }) => {
      if (data) setStats({ topicsLearned: data.progress?.length ?? 0, branchProgress: data.branchProgress?.length ?? 0 })
    })
  }, [])

  const completeness = calculateCompleteness(cv)

  return (
    <div className="p-4 space-y-5">
      <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">CV Status</h3>

      {/* Completeness */}
      <div>
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="text-slate-400">Completeness</span>
          <span className="text-slate-200 font-medium">{completeness}%</span>
        </div>
        <div className="xp-bar">
          <div className="xp-fill" style={{ width: `${completeness}%` }} />
        </div>
      </div>

      {/* Roadmap stats */}
      <div className="space-y-2.5">
        <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Roadmap Auto-Fill</h4>
        <StatRow label="Topics learned" value={stats.topicsLearned as number ?? 0} badge="auto" />
        <StatRow label="Active branches" value={stats.branchProgress as number ?? 0} badge="auto" />
      </div>

      {/* Section checklist */}
      <div className="space-y-1.5">
        <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Sections</h4>
        {[
          { label: 'Personal info', done: Boolean(cv.fullName && cv.email) },
          { label: 'Work experience', done: false },
          { label: 'Education', done: false },
          { label: 'Projects', done: false },
          { label: 'Professional links', done: Boolean(cv.socialLinks?.linkedin || cv.socialLinks?.github) },
        ].map(({ label, done }) => (
          <div key={label} className="flex items-center gap-2 text-xs">
            <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${done ? 'bg-brand-emerald border-brand-emerald' : 'border-slate-600'}`}>
              {done && <Check className="w-2 h-2 text-surface-0" />}
            </div>
            <span className={done ? 'text-slate-300' : 'text-slate-500'}>{label}</span>
          </div>
        ))}
      </div>

      {/* Open to work */}
      {cv.openToWork && cv.openToWork !== 'not_looking' && (
        <div className={`badge text-xs px-3 py-1.5 ${
          cv.openToWork === 'open_to_work' ? 'badge-emerald' :
          cv.openToWork === 'hiring' ? 'badge-cyan' : 'badge-indigo'
        }`}>
          {cv.openToWork === 'open_to_work' ? '✓ Open to Work' : cv.openToWork === 'hiring' ? '🔍 Hiring' : '⚡ Freelance'}
        </div>
      )}
    </div>
  )
}

// ── Shared UI helpers ─────────────────────────────────────────

function SectionHeader({ icon: Icon, title, className }: { icon: React.ElementType; title: string; className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className ?? ''}`}>
      <Icon className="w-4 h-4 text-brand-cyan" />
      <h3 className="text-sm font-semibold text-slate-200">{title}</h3>
    </div>
  )
}

function FormField({ label, required, children, className }: { label: string; required?: boolean; children: React.ReactNode; className?: string }) {
  return (
    <div className={className}>
      <label className="block text-xs font-medium text-slate-400 mb-1.5">
        {label}{required && <span className="text-red-400 ml-0.5">*</span>}
      </label>
      {children}
    </div>
  )
}

function StatRow({ label, value, badge }: { label: string; value: number; badge?: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs text-slate-500">{label}</span>
      <div className="flex items-center gap-1.5">
        <span className="text-xs font-medium text-slate-200">{value}</span>
        {badge && <span className="badge-cyan text-[10px]">{badge}</span>}
      </div>
    </div>
  )
}

function ExportMenu({ onExport, loading }: { onExport: (t: CvTemplateId, ats: boolean) => void; loading: boolean }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="relative">
      <button onClick={() => setOpen(o => !o)} disabled={loading} className="btn-primary text-xs">
        <Download className="w-3.5 h-3.5" />
        {loading ? 'Exporting…' : 'Export PDF'}
        <ChevronDown className="w-3 h-3 ml-1" />
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1 w-44 bg-surface-2 border border-border rounded shadow-card z-10" onMouseLeave={() => setOpen(false)}>
          {(['precision','vector','circuit','minimal'] as CvTemplateId[]).map(t => (
            <button key={t} onClick={() => { onExport(t, t === 'minimal'); setOpen(false) }}
              className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:bg-surface-3 hover:text-slate-100 first:rounded-t last:rounded-b capitalize">
              {t}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function OpenToWorkSelector({ value, onChange }: { value: OpenToWorkStatus; onChange: (v: OpenToWorkStatus) => void }) {
  const options: { id: OpenToWorkStatus; label: string; color: string }[] = [
    { id: 'not_looking', label: 'Not looking', color: 'text-slate-500' },
    { id: 'open_to_work', label: '✓ Open to Work', color: 'text-brand-emerald' },
    { id: 'hiring', label: '🔍 Hiring', color: 'text-brand-cyan' },
    { id: 'freelance', label: '⚡ Freelance Available', color: 'text-brand-indigo' },
  ]
  return (
    <div className="flex items-center gap-2 mt-3">
      <span className="text-xs text-slate-500">Status:</span>
      <div className="flex gap-1">
        {options.map(o => (
          <button key={o.id} onClick={() => onChange(o.id)}
            className={`px-2.5 py-1 rounded text-xs transition-all ${value === o.id ? `${o.color} bg-surface-3 border border-current/30` : 'text-slate-600 hover:text-slate-400'}`}>
            {o.label}
          </button>
        ))}
      </div>
    </div>
  )
}

function GenericListSection({ section, title, icon: Icon, fields }: {
  section: string; title: string; icon: React.ElementType;
  fields: { key: string; label: string; required?: boolean; placeholder?: string; type?: string }[]
}) {
  const [items, setItems] = useState<Record<string, unknown>[]>([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState<Record<string, unknown>>({})

  useEffect(() => {
    fetch(`/api/cv/sections/${section}`).then(r => r.json()).then(({ data }) => { if (Array.isArray(data)) setItems(data) })
  }, [section])

  const save = async () => {
    const res = await fetch(`/api/cv/sections/${section}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
    const { data } = await res.json()
    if (data) { setItems(prev => [data, ...prev]); setShowForm(false); setForm({}); toast.success('Saved') }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <SectionHeader icon={Icon} title={title} />
        <button onClick={() => setShowForm(s => !s)} className="btn-ghost text-xs"><Plus className="w-3.5 h-3.5" /> Add</button>
      </div>
      {showForm && (
        <div className="card p-4 space-y-3 mb-3">
          {fields.map(f => (
            <FormField key={f.key} label={f.label} required={f.required}>
              <input className="input" type={f.type ?? 'text'} placeholder={f.placeholder}
                value={form[f.key] as string ?? ''}
                onChange={e => setForm(prev => ({ ...prev, [f.key]: f.type === 'number' ? parseInt(e.target.value) : e.target.value }))} />
            </FormField>
          ))}
          <div className="flex gap-2"><button onClick={save} className="btn-primary text-xs"><Save className="w-3.5 h-3.5" /> Save</button><button onClick={() => setShowForm(false)} className="btn-ghost text-xs">Cancel</button></div>
        </div>
      )}
      {items.map(item => {
        const it = item as Record<string, unknown>
        const primaryField = fields[0]
        return (
          <div key={it.id as string} className="card p-3 flex items-center justify-between mb-2">
            <div>
              <div className="text-sm text-slate-200">{it[primaryField.key] as string}</div>
              {fields[1] && <div className="text-xs text-slate-500">{it[fields[1].key] as string}{fields[2] && it[fields[2].key] ? ` · ${it[fields[2].key]}` : ''}</div>}
            </div>
            <button onClick={async () => { await fetch(`/api/cv/sections/${section}?id=${it.id}`, { method: 'DELETE' }); setItems(p => p.filter(i => (i as Record<string, unknown>).id !== it.id)) }} className="btn-ghost p-1 text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
          </div>
        )
      })}
    </div>
  )
}

function calculateCompleteness(cv: Partial<EngineerCv>): number {
  let score = 0
  if (cv.fullName) score += 20
  if (cv.email) score += 10
  if (cv.title) score += 10
  if (cv.summary) score += 15
  if (cv.socialLinks?.linkedin || cv.socialLinks?.github) score += 10
  if (cv.location) score += 5
  return Math.min(100, score) + 30 // +30 base for roadmap auto-fill
}

function CvSkeleton() {
  return (
    <div className="flex h-full items-center justify-center">
      <div className="text-slate-500 text-sm">Loading CV Builder...</div>
    </div>
  )
}
