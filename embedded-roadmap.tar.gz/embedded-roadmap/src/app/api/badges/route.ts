// src/app/api/badges/route.ts
import { withAuth, ok, serverError } from '@/lib/api'
import { BadgeQueries } from '@/lib/db/queries'

export const GET = withAuth(async (_req, { session }) => {
  try {
    const [all, userBadges] = await Promise.all([
      BadgeQueries.getAllBadges(),
      BadgeQueries.getUserBadges(session.user.id),
    ])
    const earnedMap = new Map(userBadges.map(ub => [ub.badgeId, ub.earnedAt]))

    const badges = all.map(badge => ({
      ...badge,
      earned: earnedMap.has(badge.id),
      earnedAt: earnedMap.get(badge.id) ?? null,
    }))

    return ok({ badges, totalEarned: userBadges.length, total: all.length })
  } catch (e) { return serverError(e) }
})
