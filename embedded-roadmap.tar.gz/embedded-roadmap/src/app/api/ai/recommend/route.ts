// src/app/api/ai/recommend/route.ts
import { NextRequest } from 'next/server'
import { withAuth, ok, serverError } from '@/lib/api'
import { UserQueries, TopicQueries, ProgressQueries } from '@/lib/db/queries'
import { BranchQueries } from '@/lib/db/queries'
import { getNextTopicRecommendations, getCareerAnalysis } from '@/lib/ai/recommendations'

export const GET = withAuth(async (req, { session }) => {
  try {
    const type = req.nextUrl.searchParams.get('type') ?? 'next'

    const [user, branchProgress, learnedTopicIds] = await Promise.all([
      UserQueries.findById(session.user.id),
      ProgressQueries.getBranchProgress(session.user.id),
      ProgressQueries.getCompletedTopicIds(session.user.id),
    ])

    if (!user) return ok({ recommendations: [] })

    // Get topics from user's most active branches
    const activeBranchSlugs = branchProgress
      .sort((a, b) => b.xpInBranch - a.xpInBranch)
      .slice(0, 5)
      .map(b => b.branchSlug)

    const allBranches = await BranchQueries.getAll()
    const targetBranches = activeBranchSlugs.length > 0
      ? allBranches.filter(b => activeBranchSlugs.includes(b.slug))
      : allBranches.slice(0, 5)

    const allTopicsArrays = await Promise.all(
      targetBranches.map(b => TopicQueries.getByBranch(b.id, session.user.id))
    )
    const allTopics = allTopicsArrays.flat()
    const learnedTopics  = allTopics.filter(t => learnedTopicIds.has(t.id))
    const availableTopics = allTopics.filter(t => !learnedTopicIds.has(t.id))

    if (type === 'career') {
      const profile = await UserQueries.findById(session.user.id) as Record<string, unknown>
      const analysis = await getCareerAnalysis(user, learnedTopics, profile?.targetRole as string)
      return ok(analysis)
    }

    const recs = await getNextTopicRecommendations(user, learnedTopics, availableTopics)
    return ok(recs)
  } catch (e) {
    return serverError(e)
  }
})
