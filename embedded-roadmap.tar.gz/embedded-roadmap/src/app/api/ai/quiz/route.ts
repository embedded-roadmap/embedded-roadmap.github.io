// src/app/api/ai/quiz/route.ts
import { NextRequest } from 'next/server'
import { withAuth, ok, err, serverError, parseQuery } from '@/lib/api'
import { queryOne } from '@/lib/db'

const quizCache = new Map<string, { ts: number; quiz: unknown[] }>()

export const GET = withAuth(async (req, { session }) => {
  const slug = parseQuery(req, 'topicSlug', '')
  if (!slug) return err('topicSlug required')

  // Check 24hr cache
  const cached = quizCache.get(slug)
  if (cached && Date.now() - cached.ts < 86_400_000) return ok({ quiz: cached.quiz })

  // Get topic details
  const topic = await queryOne<{ name: string; description: string }>(
    `SELECT name, description FROM topics WHERE slug = $1`, [slug])
  if (!topic) return err('Topic not found')

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.OPENAI_API_KEY ?? '',  // reuse env or use ANTHROPIC_API_KEY
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: `Generate 5 multiple-choice quiz questions for an electronics/embedded engineering topic.

Topic: ${topic.name}
Description: ${topic.description ?? ''}

Respond ONLY with a JSON array (no markdown) like:
[{"question":"...","options":["A","B","C","D"],"answer":0},...]

where "answer" is the 0-indexed correct option. Make questions technical and specific.`,
        }],
      }),
    })

    const data = await response.json()
    const text = data.content?.[0]?.text ?? ''
    const quiz = JSON.parse(text.trim())

    quizCache.set(slug, { ts: Date.now(), quiz })
    return ok({ quiz })
  } catch (e) {
    return serverError(e)
  }
})
