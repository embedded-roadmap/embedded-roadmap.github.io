import{NextRequest}from'next/server'
import{ok,notFound,serverError}from'@/lib/api'
import{BranchQueries,TopicQueries,ProgressQueries}from'@/lib/db/queries'
import{getServerSession}from'next-auth'
import{authOptions}from'@/lib/auth'
export async function GET(req:NextRequest,{params}:{params:{slug:string}}){
  try{
    const session=await getServerSession(authOptions)
    const branch=await BranchQueries.getBySlug(params.slug)
    if(!branch)return notFound('Branch')
    const topics=await TopicQueries.getByBranch(params.slug,true)
    return ok({branch,topics})
  }catch(e){return serverError(e)}
}
