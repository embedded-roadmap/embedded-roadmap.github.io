import{ok,serverError}from'@/lib/api'
import{BranchQueries}from'@/lib/db/queries'
export async function GET(){
  try{const branches=await BranchQueries.getAll();return ok({branches})}
  catch(e){return serverError(e)}
}
