import{NextRequest}from'next/server'
import{z}from'zod'
import{withAuth,ok,err,serverError,parseBody}from'@/lib/api'
import{ProgressQueries,UserQueries}from'@/lib/db/queries'
export const GET=withAuth(async(_req,{session})=>{
  try{
    const[progress,branchProgress,user]=await Promise.all([ProgressQueries.getUserProgress(session.user.id),ProgressQueries.getBranchProgress(session.user.id),UserQueries.findById(session.user.id)])
    return ok({progress,branchProgress,recentProgress:progress.filter(p=>p.status==='learned'||p.status==='reviewing').slice(0,10),user})
  }catch(e){return serverError(e)}
})
const S=z.object({topicId:z.string().uuid(),status:z.enum(['learning','learned','reviewing','skipped','not_started'])})
export const POST=withAuth(async(req,{session})=>{
  const p=await parseBody(req,S);if('error'in p)return err(p.error)
  try{const progress=await ProgressQueries.markTopic(session.user.id,p.data.topicId,p.data.status);const user=await UserQueries.findById(session.user.id);return ok({progress,user})}catch(e){return serverError(e)}
})
