// src/app/api/profile/[username]/route.ts
// Public engineer profile API — recruiter-safe

import { NextRequest } from 'next/server'
import { ok, notFound, serverError } from '@/lib/api'
import { RecruiterQueries } from '@/lib/db/cv-queries'

export async function GET(_req: NextRequest, { params }: { params: { username: string } }) {
  try {
    const profile = await RecruiterQueries.buildProfile(params.username)
    if (!profile) return notFound('Engineer profile')
    return ok(profile)
  } catch (e) {
    return serverError(e)
  }
}
