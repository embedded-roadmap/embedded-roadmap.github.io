// src/app/api/donations/route.ts
// Donation platform config — returns public links, no payment processing here

import { NextRequest } from 'next/server'
import { ok } from '@/lib/api'
import type { DonationConfig } from '@/types'

export async function GET() {
  const config: DonationConfig = {
    stripePublishableKey: process.env.STRIPE_PUBLISHABLE_KEY ?? null,
    buyMeCoffeeUrl: process.env.BUYMEACOFFEE_URL ?? null,
    patreonUrl: process.env.PATREON_URL ?? null,
    githubSponsorsUrl: process.env.GITHUB_SPONSORS_URL ?? null,
    goal: process.env.DONATION_GOAL_CURRENT ? {
      current: parseInt(process.env.DONATION_GOAL_CURRENT),
      target: parseInt(process.env.DONATION_GOAL_TARGET ?? '500'),
      label: process.env.DONATION_GOAL_LABEL ?? 'Monthly server costs',
    } : null,
  }
  return ok(config)
}
