// src/app/api/onboarding/route.ts
import { z } from 'zod'
import { withAuth, ok, err, serverError, parseBody } from '@/lib/api'
import { UserQueries } from '@/lib/db/queries'

export const GET = withAuth(async (_req, { session }) => {
  try {
    const onboarding = await UserQueries.getOnboarding(session.user.id)
    return ok({ onboarding })
  } catch (e) { return serverError(e) }
})

const schema = z.object({
  step: z.number().int().min(0).max(5),
  experience: z.enum(['student','junior','mid','senior','lead']).optional().nullable(),
  goals: z.array(z.string()).max(10).optional(),
  interests: z.array(z.string()).max(15).optional(),
  selectedPaths: z.array(z.string()).max(10).optional(),
  complete: z.boolean().optional(),
})

export const POST = withAuth(async (req, { session }) => {
  const parsed = await parseBody(req, schema)
  if ('error' in parsed) return err(parsed.error)
  try {
    await UserQueries.upsertOnboarding(session.user.id, parsed.data)
    if (parsed.data.complete) {
      await UserQueries.completeOnboarding(session.user.id)
    }
    return ok({ saved: true })
  } catch (e) { return serverError(e) }
})
