import{NextRequest}from'next/server'
import{withAdmin,ok,err,serverError}from'@/lib/api'
import{query,execute,queryOne}from'@/lib/db'
export const POST=withAdmin(async(req)=>{
  try{
    const body=await req.json().catch(()=>({}))
    const{topics,branchSlug}=body as{topics?:Record<string,unknown>[];branchSlug?:string}
    if(!topics||!Array.isArray(topics)||topics.length===0)return err('topics array required')
    const branch=await queryOne<{id:string}>(`SELECT id FROM branches WHERE slug=$1`,[branchSlug])
    if(!branch)return err(`Branch not found: ${branchSlug}`)
    let imported=0;let errors=0
    for(const t of topics){
      try{
        await query(`INSERT INTO topics(slug,branch_id,name,description,level,difficulty,difficulty_tier,estimated_hours,key_concepts,tools,industry_tags,salary_impact)VALUES($1,$2,$3,$4,$5,$6,$7::difficulty_tier,$8,$9,$10,$11,$12)ON CONFLICT(slug)DO UPDATE SET name=$3,description=$4,level=$5,difficulty=$6,difficulty_tier=$7::difficulty_tier,estimated_hours=$8,key_concepts=$9,tools=$10,industry_tags=$11,salary_impact=$12`,
          [t.slug,branch.id,t.name,t.description??null,t.level??1,t.difficulty??50,t.difficultyTier??'intermediate',t.estimatedHours??null,t.keyConcepts??[],t.tools??[],t.industryTags??[],t.salaryImpact??0])
        imported++
      }catch(e){console.error(`Import error ${t.slug}:`,e);errors++}
    }
    await execute(`UPDATE branches SET topic_count=(SELECT COUNT(*) FROM topics WHERE branch_id=$1 AND status='published') WHERE id=$1`,[branch.id])
    return ok({imported,errors,total:topics.length})
  }catch(e){return serverError(e)}
})
export const GET=withAdmin(async()=>{
  try{
    const rows=await query<Record<string,unknown>>(`SELECT b.slug,b.name,b.topic_count,COUNT(t.id) AS actual_count FROM branches b LEFT JOIN topics t ON t.branch_id=b.id AND t.status='published' GROUP BY b.id,b.slug,b.name,b.topic_count ORDER BY b.sort_order`)
    return ok({branches:rows,totalTopics:rows.reduce((s,r)=>s+Number(r.actual_count??0),0)})
  }catch(e){return serverError(e)}
})
