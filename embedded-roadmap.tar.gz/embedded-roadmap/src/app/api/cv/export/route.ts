// src/app/api/cv/export/route.ts
// PDF export and share token management

import { NextRequest, NextResponse } from 'next/server'
import { withAuth, ok, err, serverError, parseQuery } from '@/lib/api'
import { CvQueries } from '@/lib/db/cv-queries'
import { ProgressQueries, BadgeQueries, UserQueries } from '@/lib/db/queries'
import { generateCvHtml } from '@/lib/cv/pdf-generator'
import type { CvTemplateId, PdfRenderOptions } from '@/lib/cv/pdf-generator'

// POST /api/cv/export — generate PDF HTML (client renders via print dialog)
// In production: swap html → puppeteer PDF generation
export const POST = withAuth(async (req, { session }) => {
  try {
    const body = await req.json().catch(() => ({}))
    const template = (body.template ?? 'precision') as CvTemplateId
    const theme = (body.theme ?? 'light') as 'light' | 'dark'
    const atsMode = Boolean(body.atsMode)

    // Load all CV data
    const [cv, user, learnedProgress, badges] = await Promise.all([
      CvQueries.getFullCv(session.user.id),
      UserQueries.findById(session.user.id),
      ProgressQueries.getUserProgress(session.user.id),
      BadgeQueries.getUserBadges(session.user.id),
    ])

    if (!cv || !user) return err('No CV found — create your CV first')

    // Build roadmap data snapshot
    const roadmapData = {
      learnedTopics: learnedProgress.map(p => ({
        name: (p as Record<string, unknown>).topicName as string ?? '',
        rarity: (p as Record<string, unknown>).topicRarity as import('@/types').RarityTier ?? 'common',
        branchName: (p as Record<string, unknown>).branchSlug as string ?? '',
      })).filter(t => t.name),
      earnedBadges: badges.map(b => ({
        name: b.badge?.name ?? '',
        icon: b.badge?.icon ?? '',
        rarity: b.badge?.rarity ?? 'common' as import('@/types').RarityTier,
      })),
      totalXp: user.totalXp,
      globalPercentile: user.globalPercentile,
      topicsLearned: user.topicsLearned,
      rareSkillsCount: user.rareTopicsCount,
      currentLevel: user.currentLevel,
    }

    const html = generateCvHtml(
      cv as unknown as import('@/types').EngineerCv,
      roadmapData,
      { template, theme, atsMode, includeRoadmapStats: !atsMode, includeRarityBadges: !atsMode }
    )

    await CvQueries.markGenerated(session.user.id)

    // Return HTML for client-side print-to-PDF
    // In production: use puppeteer to generate actual PDF bytes
    return new NextResponse(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'X-CV-Generated': new Date().toISOString(),
      }
    })
  } catch (e) {
    return serverError(e)
  }
})

// GET /api/cv/export?action=share — get/create share token
export const GET = withAuth(async (req, { session }) => {
  const action = parseQuery(req, 'action', 'token')

  try {
    if (action === 'enable-share') {
      const token = await CvQueries.enableShare(session.user.id)
      return ok({ token, shareUrl: `${process.env.NEXT_PUBLIC_APP_URL}/r/${token}` })
    }

    if (action === 'disable-share') {
      await CvQueries.disableShare(session.user.id)
      return ok({ shareEnabled: false })
    }

    const cv = await CvQueries.getByUserId(session.user.id)
    return ok({
      shareEnabled: cv?.shareEnabled ?? false,
      shareToken: cv?.shareToken ?? null,
      shareUrl: cv?.shareToken ? `${process.env.NEXT_PUBLIC_APP_URL}/r/${cv.shareToken}` : null,
    })
  } catch (e) {
    return serverError(e)
  }
})
