// src/app/api/cv/share/[token]/route.ts
// Public recruiter CV access via share token

import { NextRequest } from 'next/server'
import { ok, notFound, serverError } from '@/lib/api'
import { CvQueries, RecruiterQueries } from '@/lib/db/cv-queries'
import { query } from '@/lib/db'

export async function GET(_req: NextRequest, { params }: { params: { token: string } }) {
  try {
    const cv = await CvQueries.getByShareToken(params.token)
    if (!cv) return notFound('Share link')

    // Get username for full recruiter profile
    const userRow = await query<{ username: string }>(
      `SELECT username FROM users WHERE id = $1`, [(cv as Record<string, unknown>).userId as string])
    if (!userRow[0]) return notFound('Profile')

    const profile = await RecruiterQueries.buildProfile(userRow[0].username)
    if (!profile) return notFound('Profile')

    return ok({ cv, recruiterProfile: profile })
  } catch (e) {
    return serverError(e)
  }
}
