// src/app/api/cv/route.ts
// GET/PUT the user's CV personal info

import { NextRequest } from 'next/server'
import { z } from 'zod'
import { withAuth, ok, err, serverError, parseBody } from '@/lib/api'
import { CvQueries, CvSectionQueries, PrivacyQueries } from '@/lib/db/cv-queries'
import { ProgressQueries } from '@/lib/db/queries'

// GET — full CV data
export const GET = withAuth(async (_req, { session }) => {
  try {
    const [cv, privacy] = await Promise.all([
      CvQueries.getFullCv(session.user.id),
      PrivacyQueries.get(session.user.id),
    ])
    return ok({ cv, privacy })
  } catch (e) {
    return serverError(e)
  }
})

const personalSchema = z.object({
  fullName:    z.string().min(1).max(120).optional(),
  title:       z.string().max(200).optional(),
  email:       z.string().email().optional(),
  phone:       z.string().max(40).optional(),
  location:    z.string().max(120).optional(),
  summary:     z.string().max(1500).optional(),
  openToWork:  z.enum(['not_looking','open_to_work','hiring','freelance']).optional(),
  templateId:  z.enum(['precision','vector','circuit','minimal']).optional(),
  socialLinks: z.object({
    linkedin:  z.string().url().nullable().optional(),
    github:    z.string().url().nullable().optional(),
    hackaday:  z.string().url().nullable().optional(),
    gitlab:    z.string().url().nullable().optional(),
    website:   z.string().url().nullable().optional(),
    email:     z.string().email().nullable().optional(),
  }).optional(),
})

// PUT — update personal info
export const PUT = withAuth(async (req, { session }) => {
  const parsed = await parseBody(req, personalSchema)
  if ('error' in parsed) return err(parsed.error)

  try {
    await CvQueries.getOrCreate(session.user.id)
    await CvQueries.updatePersonal(session.user.id, parsed.data)
    return ok({ updated: true })
  } catch (e) {
    return serverError(e)
  }
})
