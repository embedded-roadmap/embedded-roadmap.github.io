// src/app/api/cv/sections/[section]/route.ts
// CRUD for all CV sections (education, experience, certifications, projects, etc.)

import { NextRequest } from 'next/server'
import { z } from 'zod'
import { withAuth, ok, err, notFound, serverError, parseBody } from '@/lib/api'
import { CvQueries, CvSectionQueries, ProjectQueries } from '@/lib/db/cv-queries'

type Section = 'education' | 'experience' | 'certifications' | 'projects'
  | 'publications' | 'patents' | 'awards' | 'references' | 'manual_skills' | 'languages'

const TABLE_MAP: Record<Section, string> = {
  education:    'cv_education',
  experience:   'cv_experience',
  certifications: 'cv_certifications',
  projects:     'cv_projects',
  publications: 'cv_publications',
  patents:      'cv_patents',
  awards:       'cv_awards',
  references:   'cv_references',
  manual_skills:'cv_manual_skills',
  languages:    'cv_languages',
}

const schemas: Partial<Record<Section, z.ZodTypeAny>> = {
  education: z.object({
    id: z.string().uuid().optional(),
    institution: z.string().min(1).max(200),
    degree: z.string().max(100).optional(),
    field: z.string().max(150).optional(),
    startYear: z.number().int().min(1950).max(2030),
    endYear: z.number().int().min(1950).max(2030).nullable().optional(),
    gpa: z.string().max(10).nullable().optional(),
    honors: z.string().max(200).nullable().optional(),
    relevant_courses: z.array(z.string()).optional(),
  }),
  experience: z.object({
    id: z.string().uuid().optional(),
    company: z.string().min(1).max(200),
    title: z.string().min(1).max(200),
    location: z.string().max(120).nullable().optional(),
    startDate: z.string(),
    endDate: z.string().nullable().optional(),
    isCurrent: z.boolean().optional(),
    description: z.string().max(2000).optional(),
    highlights: z.array(z.string().max(300)).max(8).optional(),
    techStack: z.array(z.string()).max(20).optional(),
    domains: z.array(z.string()).max(10).optional(),
  }),
  certifications: z.object({
    id: z.string().uuid().optional(),
    name: z.string().min(1).max(200),
    issuer: z.string().max(200).optional(),
    issuedDate: z.string().nullable().optional(),
    expiryDate: z.string().nullable().optional(),
    credentialId: z.string().max(100).nullable().optional(),
    url: z.string().url().nullable().optional(),
  }),
  projects: z.object({
    id: z.string().uuid().optional(),
    title: z.string().min(1).max(200),
    description: z.string().max(2000).nullable().optional(),
    techStack: z.array(z.string()).max(20).optional(),
    hardwareStack: z.array(z.string()).max(20).optional(),
    firmwareStack: z.array(z.string()).max(20).optional(),
    relatedTopicSlugs: z.array(z.string()).max(20).optional(),
    repoUrl: z.string().url().nullable().optional(),
    projectUrl: z.string().url().nullable().optional(),
    platform: z.enum(['github','gitlab','hackaday','personal','other']).optional(),
    imageUrl: z.string().url().nullable().optional(),
    videoUrl: z.string().url().nullable().optional(),
    isFeatured: z.boolean().optional(),
    startDate: z.string().nullable().optional(),
    endDate: z.string().nullable().optional(),
  }),
  publications: z.object({
    id: z.string().uuid().optional(),
    title: z.string().min(1).max(400),
    venue: z.string().max(200).optional(),
    year: z.number().int().min(1970).max(2030).optional(),
    url: z.string().url().nullable().optional(),
    doi: z.string().max(100).nullable().optional(),
    authors: z.array(z.string()).optional(),
  }),
  patents: z.object({
    id: z.string().uuid().optional(),
    title: z.string().min(1).max(400),
    patentNumber: z.string().max(60).optional(),
    filingDate: z.string().optional(),
    grantDate: z.string().nullable().optional(),
    jurisdiction: z.string().max(10).optional(),
    url: z.string().url().nullable().optional(),
    inventors: z.array(z.string()).optional(),
  }),
  awards: z.object({
    id: z.string().uuid().optional(),
    title: z.string().min(1).max(200),
    issuer: z.string().max(200).optional(),
    year: z.number().int().min(1970).max(2030).optional(),
    description: z.string().max(500).nullable().optional(),
  }),
  manual_skills: z.object({
    id: z.string().uuid().optional(),
    category: z.string().min(1).max(80),
    skills: z.array(z.string()).max(30),
  }),
  languages: z.object({
    id: z.string().uuid().optional(),
    name: z.string().min(1).max(60),
    level: z.enum(['native','professional','conversational','basic']),
  }),
}

// GET /api/cv/sections/[section] — list items
export const GET = withAuth(async (_req, { session, params }) => {
  const section = params.section as Section
  if (!TABLE_MAP[section]) return err('Invalid section')

  try {
    const cvId = await getCvId(session.user.id)
    if (!cvId) return ok([])

    const { query, rowsToCamel } = await import('@/lib/db')
    const rows = await query(`SELECT * FROM ${TABLE_MAP[section]} WHERE ${section === 'projects' ? 'user_id' : 'cv_id'} = $1 ORDER BY sort_order NULLS LAST`, [section === 'projects' ? session.user.id : cvId])
    return ok(rowsToCamel(rows))
  } catch (e) {
    return serverError(e)
  }
})

// POST /api/cv/sections/[section] — upsert item
export const POST = withAuth(async (req, { session, params }) => {
  const section = params.section as Section
  if (!TABLE_MAP[section]) return err('Invalid section')

  const schema = schemas[section]
  if (!schema) return err('Section not editable via this endpoint')

  const parsed = await parseBody(req, schema)
  if ('error' in parsed) return err(parsed.error)

  try {
    await CvQueries.getOrCreate(session.user.id)

    let result: unknown
    switch (section) {
      case 'education':     result = await CvSectionQueries.upsertEducation(session.user.id, parsed.data); break
      case 'experience':    result = await CvSectionQueries.upsertExperience(session.user.id, parsed.data); break
      case 'certifications': result = await CvSectionQueries.upsertCertification(session.user.id, parsed.data); break
      case 'projects':      result = await ProjectQueries.upsert(session.user.id, parsed.data); break
      default: {
        // Generic upsert for publications, patents, awards, etc.
        const cvId = await getCvId(session.user.id)
        if (!cvId) return err('No CV found')
        const { query: q, rowsToCamel } = await import('@/lib/db')
        const data = parsed.data as Record<string, unknown>
        const keys = Object.keys(data).filter(k => k !== 'id')
        const colNames = keys.map(toSnake).join(', ')
        const placeholders = keys.map((_, i) => `$${i + 3}`).join(', ')
        const updateSets = keys.map((k, i) => `${toSnake(k)} = $${i + 3}`).join(', ')
        const rows = await q(
          `INSERT INTO ${TABLE_MAP[section]} (id, cv_id, ${colNames})
           VALUES (COALESCE($1::uuid, uuid_generate_v4()), $2, ${placeholders})
           ON CONFLICT (id) DO UPDATE SET ${updateSets}
           RETURNING *`,
          [data.id ?? null, cvId, ...keys.map(k => data[k])])
        result = rowsToCamel(rows)[0]
      }
    }
    return ok(result)
  } catch (e) {
    return serverError(e)
  }
})

// DELETE /api/cv/sections/[section]?id=xxx
export const DELETE = withAuth(async (req, { session, params }) => {
  const section = params.section as Section
  const id = req.nextUrl.searchParams.get('id')
  if (!id) return err('id required')

  try {
    const deleted = await CvSectionQueries.deleteItem(TABLE_MAP[section] as Parameters<typeof CvSectionQueries.deleteItem>[0], id, session.user.id)
    if (!deleted) return notFound('Item')
    return ok({ deleted: true })
  } catch (e) {
    return serverError(e)
  }
})

async function getCvId(userId: string): Promise<string | null> {
  const { queryOne } = await import('@/lib/db')
  const row = await queryOne<{ id: string }>(`SELECT id FROM engineer_cvs WHERE user_id = $1`, [userId])
  return row?.id ?? null
}

function toSnake(s: string): string {
  return s.replace(/[A-Z]/g, c => `_${c.toLowerCase()}`)
}
