// src/app/api/analytics/route.ts
import { withAuth, ok, serverError } from '@/lib/api'
import { AnalyticsQueries } from '@/lib/db/queries'
import { UserQueries, ProgressQueries, BadgeQueries } from '@/lib/db/queries'

export const GET = withAuth(async (_req, { session }) => {
  try {
    const [user, radarData, xpHistory, heatmap, topSkills, badges] = await Promise.all([
      UserQueries.findById(session.user.id),
      AnalyticsQueries.getRadarData(session.user.id),
      AnalyticsQueries.getXpHistory(session.user.id, 30),
      AnalyticsQueries.getHeatmap(session.user.id),
      AnalyticsQueries.getTopSkills(session.user.id),
      BadgeQueries.getUserBadges(session.user.id),
    ])
    return ok({ user, radarData, xpHistory, heatmap, topSkills, badgesEarned: badges.length })
  } catch (e) { return serverError(e) }
})
