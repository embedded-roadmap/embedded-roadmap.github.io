import{z}from'zod'
import bcrypt from'bcryptjs'
import{NextRequest}from'next/server'
import{ok,err,serverError}from'@/lib/api'
import{UserQueries}from'@/lib/db/queries'
import{validateUsername,validatePassword}from'@/lib/auth'
const S=z.object({username:z.string().min(3).max(30),email:z.string().email(),password:z.string().min(8).max(128)})
export async function POST(req:NextRequest){
  try{
    const b=await req.json();const p=S.safeParse(b)
    if(!p.success)return err(p.error.errors.map(e=>e.message).join(', '))
    const{username,email,password}=p.data
    const ue=validateUsername(username.toLowerCase());if(ue)return err(ue)
    const pe=validatePassword(password);if(pe)return err(pe)
    const[ee,eu]=await Promise.all([UserQueries.findByEmail(email),UserQueries.findByUsername(username.toLowerCase())])
    if(ee)return err('Email already registered',409)
    if(eu)return err('Username already taken',409)
    const hash=await bcrypt.hash(password,12)
    const user=await UserQueries.create({username:username.toLowerCase(),email:email.toLowerCase(),passwordHash:hash,displayName:username})
    return ok({userId:user.id,username:user.username},201)
  }catch(e){return serverError(e)}
}
