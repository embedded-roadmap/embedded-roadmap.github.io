import{NextRequest}from'next/server'
import{getServerSession}from'next-auth'
import{authOptions}from'@/lib/auth'
import{ok,serverError,parseQuery,parseQueryInt}from'@/lib/api'
import{RankingQueries}from'@/lib/db/queries'
export async function GET(req:NextRequest){
  try{
    const session=await getServerSession(authOptions)
    const period=parseQuery(req,'period','monthly') as 'monthly'|'alltime'
    const limit=parseQueryInt(req,'limit',50)
    const rankings=await RankingQueries.getLeaderboard(period,limit,session?.user?.id)
    return ok({rankings})
  }catch(e){return serverError(e)}
}
