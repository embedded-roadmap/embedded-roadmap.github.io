// src/app/api/users/privacy/route.ts
import { NextRequest } from 'next/server'
import { z } from 'zod'
import { withAuth, ok, err, serverError, parseBody } from '@/lib/api'
import { PrivacyQueries } from '@/lib/db/cv-queries'
import { UserQueries, ProgressQueries, BadgeQueries } from '@/lib/db/queries'

export const GET = withAuth(async (_req, { session }) => {
  try {
    const settings = await PrivacyQueries.get(session.user.id)
    return ok(settings)
  } catch (e) {
    return serverError(e)
  }
})

const schema = z.object({
  isPublic:            z.boolean().optional(),
  showPercentile:      z.boolean().optional(),
  showXp:              z.boolean().optional(),
  showSalaryEstimates: z.boolean().optional(),
  showStreak:          z.boolean().optional(),
  showBadges:          z.boolean().optional(),
  showProjects:        z.boolean().optional(),
  allowRecruiterView:  z.boolean().optional(),
  openToWork:          z.enum(['not_looking','open_to_work','hiring','freelance']).optional(),
})

export const PUT = withAuth(async (req, { session }) => {
  const parsed = await parseBody(req, schema)
  if ('error' in parsed) return err(parsed.error)
  try {
    await PrivacyQueries.update(session.user.id, parsed.data)
    return ok({ updated: true })
  } catch (e) {
    return serverError(e)
  }
})

// POST /api/users/privacy?action=export|delete
export const POST = withAuth(async (req, { session }) => {
  const action = req.nextUrl.searchParams.get('action')

  if (action === 'export') {
    // Compile full user data export (GDPR)
    const [user, progress, badges] = await Promise.all([
      UserQueries.findById(session.user.id),
      ProgressQueries.getUserProgress(session.user.id),
      BadgeQueries.getUserBadges(session.user.id),
    ])
    await PrivacyQueries.requestDataExport(session.user.id)
    return ok({
      exportedAt: new Date().toISOString(),
      user,
      topicsLearned: progress.length,
      badgesEarned: badges.length,
      note: 'Full data export prepared. Download link will be emailed within 24 hours.',
    })
  }

  if (action === 'delete') {
    await PrivacyQueries.requestAccountDeletion(session.user.id)
    return ok({ message: 'Account scheduled for deletion in 30 days. Contact support to cancel.' })
  }

  return err('Unknown action')
})
