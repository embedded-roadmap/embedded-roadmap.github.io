// src/app/api/users/me/route.ts
import { z } from 'zod'
import { withAuth, ok, serverError, parseBody, err } from '@/lib/api'
import { UserQueries } from '@/lib/db/queries'

export const GET = withAuth(async (_req, { session }) => {
  try {
    const user = await UserQueries.findById(session.user.id)
    if (!user) return err('User not found', 404)
    return ok({ user })
  } catch (e) { return serverError(e) }
})

const updateSchema = z.object({
  displayName: z.string().min(1).max(80).optional(),
  bio: z.string().max(500).optional(),
  location: z.string().max(100).optional(),
  websiteUrl: z.string().url().optional().or(z.literal('')),
  linkedinUrl: z.string().url().optional().or(z.literal('')),
  isPublic: z.boolean().optional(),
  headline: z.string().max(200).optional(),
  yearsExperience: z.number().int().min(0).max(50).optional(),
  currentCompany: z.string().max(150).optional(),
  currentRole: z.string().max(150).optional(),
  targetRole: z.string().max(150).optional(),
  expertiseAreas: z.array(z.string()).max(10).optional(),
  countryCode: z.string().length(2).optional(),
})

export const PUT = withAuth(async (req, { session }) => {
  const parsed = await parseBody(req, updateSchema)
  if ('error' in parsed) return err(parsed.error)
  try {
    await UserQueries.updateProfile(session.user.id, parsed.data)
    const user = await UserQueries.findById(session.user.id)
    return ok({ user })
  } catch (e) { return serverError(e) }
})
