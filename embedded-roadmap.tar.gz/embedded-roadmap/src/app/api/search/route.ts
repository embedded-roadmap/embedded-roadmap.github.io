import{NextRequest}from'next/server'
import{ok,err,serverError,parseQuery,parseQueryInt}from'@/lib/api'
import{TopicQueries}from'@/lib/db/queries'
export async function GET(req:NextRequest){
  try{
    const q=parseQuery(req,'q','').trim()
    if(q.length<2)return err('Query must be at least 2 chars')
    const limit=parseQueryInt(req,'limit',20)
    const results=await TopicQueries.search(q,limit)
    return ok({results})
  }catch(e){return serverError(e)}
}
