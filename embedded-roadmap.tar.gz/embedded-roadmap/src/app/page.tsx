// src/app/page.tsx — Landing page

import Link from 'next/link'
import { Zap, Map, FileText, Trophy, ArrowRight, Check, Star, Code2, Cpu, Radio } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#060a10] text-slate-100">
      {/* Background grid */}
      <div className="fixed inset-0 bg-[linear-gradient(rgba(56,189,248,0.015)_1px,transparent_1px),linear-gradient(90deg,rgba(56,189,248,0.015)_1px,transparent_1px)] bg-[size:48px_48px] pointer-events-none" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,rgba(56,189,248,0.06)_0%,transparent_60%)] pointer-events-none" />

      {/* Nav */}
      <nav className="relative border-b border-[rgba(99,179,237,0.1)] backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#38bdf8] to-[#818cf8] flex items-center justify-center">
              <Zap className="w-3.5 h-3.5 text-[#060a10]" />
            </div>
            <span className="font-bold text-sm text-slate-100 tracking-tight">EmbeddedRoadmap</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/login" className="text-sm text-slate-400 hover:text-slate-200 transition-colors">Sign in</Link>
            <Link href="/register" className="px-4 py-1.5 rounded-lg bg-[#38bdf8] text-[#060a10] text-sm font-semibold hover:bg-cyan-300 transition-colors">
              Get started free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative max-w-6xl mx-auto px-6 pt-24 pb-16 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[rgba(56,189,248,0.25)] bg-[rgba(56,189,248,0.05)] text-xs text-[#38bdf8] mb-8 font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-[#38bdf8] animate-pulse" />
          1200+ engineering topics, 24 branches, 7 difficulty levels
        </div>

        <h1 className="text-5xl sm:text-6xl font-extrabold leading-tight tracking-tight mb-6">
          <span className="text-slate-100">The Engineering</span>
          <br />
          <span className="bg-gradient-to-r from-[#38bdf8] via-[#818cf8] to-[#34d399] bg-clip-text text-transparent">
            Skill Graph
          </span>
        </h1>

        <p className="text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed mb-10">
          Track your electronics and embedded systems knowledge, benchmark globally,
          and generate ATS-optimized CVs automatically from your roadmap progress.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link href="/register"
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-[#38bdf8] text-[#060a10] font-bold text-base hover:bg-cyan-300 transition-all shadow-[0_0_20px_rgba(56,189,248,0.3)]">
            Start for free <ArrowRight className="w-4 h-4" />
          </Link>
          <Link href="/engineers/demo"
            className="flex items-center gap-2 px-6 py-3 rounded-xl border border-[rgba(99,179,237,0.2)] text-slate-300 hover:border-[rgba(99,179,237,0.4)] hover:text-slate-100 transition-all text-base">
            See example profile
          </Link>
        </div>

        <p className="text-xs text-slate-600 mt-4">Free forever · No credit card required</p>
      </section>

      {/* Feature grid */}
      <section className="relative max-w-6xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            {
              icon: Map, color: '#38bdf8', title: 'Interactive Roadmaps',
              desc: '24 engineering branches, 1200+ expert-curated topics from passive components to SkyWater 130nm IC design. Dependency edges, prerequisite locking, rarity scoring.',
            },
            {
              icon: FileText, color: '#818cf8', title: 'Auto CV Generation',
              desc: 'Your CV auto-populates from your roadmap progress. 4 ATS-optimized templates. One-click PDF export. Recruiter share links. Open-to-work badges.',
            },
            {
              icon: Trophy, color: '#fbbf24', title: 'Global Benchmarking',
              desc: 'See where you stand globally. Percentile engine ranks you against engineers worldwide. Monthly leaderboards. Rarity scoring for rare/elite/legendary skills.',
            },
            {
              icon: Code2, color: '#34d399', title: 'Skill Rarity Engine',
              desc: 'Every topic has a rarity tier (Common → Legendary) based on what percentage of engineers know it. High-voltage design? 10kV EMC? Legendary territory.',
            },
            {
              icon: Cpu, color: '#fb7185', title: 'Engineering Analytics',
              desc: 'Radar chart by domain, specialization heatmap, XP history, percentile calculation, and competency scoring across Hardware/Firmware/Systems.',
            },
            {
              icon: Radio, color: '#a78bfa', title: 'AI-Powered Insights',
              desc: 'Personalized topic recommendations based on your progress. AI-generated knowledge quizzes for each topic. Career gap analysis.',
            },
          ].map(f => (
            <div key={f.title} className="bg-[#0d1420] border border-[rgba(99,179,237,0.1)] rounded-2xl p-6 hover:border-[rgba(99,179,237,0.2)] transition-all">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4" style={{ background: `${f.color}18` }}>
                <f.icon className="w-5 h-5" style={{ color: f.color }} />
              </div>
              <h3 className="font-semibold text-slate-100 mb-2">{f.title}</h3>
              <p className="text-sm text-slate-500 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Topic showcase */}
      <section className="relative max-w-6xl mx-auto px-6 py-16 border-t border-[rgba(99,179,237,0.06)]">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-slate-100 mb-3">Topics written by elite engineers</h2>
          <p className="text-slate-500 max-w-xl mx-auto">Not generic tutorial content. Every topic is technically precise, written from production experience.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl mx-auto">
          {[
            { name: 'High-Voltage Analog Design (>500V)', branch: 'Analog Electronics', level: '⭐ Elite', color: '#818cf8', desc: 'Partial discharge, creepage/clearance for >1kV, HV op-amps (PA78), bootstrapping, IEC 60664.' },
            { name: 'IEC 62304 Medical Firmware', branch: 'RTOS & Firmware', level: '⭐ Elite', color: '#818cf8', desc: 'Software safety classification A/B/C, SOUP management, V&V, risk management per IEC 14971.' },
            { name: 'LLC Resonant Converter Design', branch: 'Power Electronics', level: '🔥 Expert', color: '#38bdf8', desc: 'FHA, resonant tank design, ZVS conditions, dead time optimization, frequency-controlled output.' },
            { name: 'Custom IC with SkyWater 130nm PDK', branch: 'FPGA & Digital', level: '✨ Legendary', color: '#fbbf24', desc: 'Xschem, ngspice, Magic VLSI, DRC/LVS, OpenLane digital flow. Open-source silicon.' },
          ].map(t => (
            <div key={t.name} className="bg-[#0d1420] border border-[rgba(99,179,237,0.1)] rounded-xl p-4">
              <div className="flex items-start justify-between gap-3 mb-2">
                <h4 className="text-sm font-medium text-slate-200 leading-tight">{t.name}</h4>
                <span className="text-[10px] font-medium whitespace-nowrap" style={{ color: t.color }}>{t.level}</span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">{t.desc}</p>
              <div className="mt-2 text-[10px] text-slate-600">{t.branch}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative max-w-6xl mx-auto px-6 py-20 text-center border-t border-[rgba(99,179,237,0.06)]">
        <h2 className="text-4xl font-bold text-slate-100 mb-4">
          Ready to chart your engineering career?
        </h2>
        <p className="text-slate-400 mb-8 max-w-lg mx-auto">
          Join engineers tracking their skills, generating CVs, and benchmarking globally.
        </p>
        <Link href="/register"
          className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[#38bdf8] to-[#818cf8] text-[#060a10] font-bold text-lg hover:opacity-90 transition-opacity shadow-[0_0_30px_rgba(56,189,248,0.25)]">
          Start for free <ArrowRight className="w-5 h-5" />
        </Link>
      </section>

      {/* Footer */}
      <footer className="border-t border-[rgba(99,179,237,0.06)] py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <Zap className="w-3.5 h-3.5" />
            <span>EmbeddedRoadmap — The global engineering skill graph</span>
          </div>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-slate-400">Privacy</Link>
            <Link href="/terms" className="hover:text-slate-400">Terms</Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
