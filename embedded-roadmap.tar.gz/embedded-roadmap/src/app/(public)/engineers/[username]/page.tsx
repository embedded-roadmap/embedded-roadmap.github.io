// src/app/(public)/engineers/[username]/page.tsx
// Public engineer profile — minimal, professional, recruiter-friendly

import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import type { RecruiterProfile, RarityTier } from '@/types'
import { RARITY_LABELS, RANK_LABELS } from '@/types'

// ── Server-side data fetch ────────────────────────────────────

async function getProfile(username: string): Promise<RecruiterProfile | null> {
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_APP_URL}/api/profile/${username}`,
      { next: { revalidate: 300 } }  // 5min cache
    )
    if (!res.ok) return null
    const { data } = await res.json()
    return data
  } catch { return null }
}

export async function generateMetadata({ params }: { params: { username: string } }): Promise<Metadata> {
  const p = await getProfile(params.username)
  if (!p) return { title: 'Engineer Not Found' }
  return {
    title: `${p.user.displayName ?? p.user.username} — Engineering Profile`,
    description: `${RANK_LABELS[p.user.currentLevel]} · ${p.stats.topicsLearned} topics · ${p.stats.globalPercentile}th percentile`,
  }
}

// ── Page ──────────────────────────────────────────────────────

export default async function EngineerProfilePage({ params }: { params: { username: string } }) {
  const profile = await getProfile(params.username)
  if (!profile) notFound()

  const { user, cv, topSkills, radarData, specializationHeatmap, openToWork, projects, stats } = profile

  const RARITY_COLORS: Record<RarityTier, string> = {
    ubiquitous: 'text-slate-400',
    common:     'text-slate-300',
    uncommon:   'text-green-400',
    rare:       'text-cyan-400',
    elite:      'text-indigo-400',
    legendary:  'text-amber-400',
  }

  const OPEN_TO_WORK_LABELS: Record<string, { text: string; color: string }> = {
    open_to_work: { text: '✓ Open to Work',         color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' },
    hiring:       { text: '🔍 Hiring',               color: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30' },
    freelance:    { text: '⚡ Freelance Available',   color: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30' },
  }

  return (
    <div className="min-h-screen bg-[#060a10]">
      {/* Subtle grid background */}
      <div className="fixed inset-0 bg-[linear-gradient(rgba(56,189,248,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(56,189,248,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

      <div className="relative max-w-4xl mx-auto px-6 py-12">

        {/* ── Header ── */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-6 mb-10">
          <div>
            <h1 className="text-2xl font-display font-bold text-slate-100">
              {user.displayName ?? user.username}
            </h1>
            <p className="text-slate-400 mt-1">
              {cv?.title ?? RANK_LABELS[user.currentLevel]}
            </p>

            {/* Location */}
            {user.location && (
              <p className="text-sm text-slate-500 mt-1">📍 {user.location}</p>
            )}

            {/* Open to work badge */}
            {openToWork !== 'not_looking' && OPEN_TO_WORK_LABELS[openToWork] && (
              <span className={`inline-flex items-center mt-3 px-3 py-1 rounded-full text-xs font-medium border ${OPEN_TO_WORK_LABELS[openToWork].color}`}>
                {OPEN_TO_WORK_LABELS[openToWork].text}
              </span>
            )}

            {/* Professional links — icon buttons only */}
            <div className="flex items-center gap-2 mt-4">
              {cv?.socialLinks?.linkedin && (
                <a href={cv.socialLinks.linkedin} target="_blank" rel="noopener"
                  className="w-8 h-8 rounded border border-border bg-surface-2 flex items-center justify-center text-slate-400 hover:text-[#0A66C2] hover:border-[#0A66C2]/40 transition-all"
                  title="LinkedIn">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                </a>
              )}
              {cv?.socialLinks?.github && (
                <a href={cv.socialLinks.github} target="_blank" rel="noopener"
                  className="w-8 h-8 rounded border border-border bg-surface-2 flex items-center justify-center text-slate-400 hover:text-slate-100 hover:border-slate-500 transition-all"
                  title="GitHub">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
                </a>
              )}
              {cv?.socialLinks?.hackaday && (
                <a href={cv.socialLinks.hackaday} target="_blank" rel="noopener"
                  className="w-8 h-8 rounded border border-border bg-surface-2 flex items-center justify-center text-amber-400 hover:border-amber-500/40 transition-all font-bold text-sm"
                  title="Hackaday.io">H</a>
              )}
              {cv?.socialLinks?.website && (
                <a href={cv.socialLinks.website} target="_blank" rel="noopener"
                  className="w-8 h-8 rounded border border-border bg-surface-2 flex items-center justify-center text-slate-400 hover:text-slate-100 hover:border-slate-500 transition-all"
                  title="Website">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current stroke-2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                </a>
              )}
              {cv?.socialLinks?.email && (
                <a href={`mailto:${cv.socialLinks.email}`}
                  className="w-8 h-8 rounded border border-border bg-surface-2 flex items-center justify-center text-slate-400 hover:text-slate-100 hover:border-slate-500 transition-all"
                  title="Email">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current stroke-2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                </a>
              )}
            </div>
          </div>

          {/* Right: rank + XP */}
          <div className="shrink-0 text-right">
            <div className="text-2xl font-display font-bold text-brand-cyan">
              {RANK_LABELS[user.currentLevel]}
            </div>
            {user.totalXp > 0 && (
              <div className="text-sm text-slate-500 mt-1">{user.totalXp.toLocaleString()} XP</div>
            )}
            {stats.globalPercentile > 0 && (
              <div className="text-xs text-slate-500 mt-0.5">
                Top <span className="text-slate-300 font-medium">{(100 - stats.globalPercentile).toFixed(1)}%</span> globally
              </div>
            )}
          </div>
        </div>

        {/* ── Stats row ── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
          {[
            { label: 'Topics Learned',  value: stats.topicsLearned },
            { label: 'Rare Skills',     value: stats.rareSkills,   note: 'skills' },
            { label: 'Current Streak',  value: `${stats.currentStreak}d` },
            { label: 'Longest Streak',  value: `${stats.longestStreak}d` },
          ].map(s => (
            <div key={s.label} className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-lg p-4 text-center">
              <div className="text-xl font-bold text-slate-100">{s.value}</div>
              <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* ── Left 2/3: Skills + Projects ── */}
          <div className="lg:col-span-2 space-y-6">

            {/* Top skills */}
            {topSkills.length > 0 && (
              <section className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-lg p-5">
                <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Skill Highlights</h2>
                <div className="space-y-2">
                  {topSkills.slice(0, 10).map((skill, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <span className="text-sm text-slate-200">{skill.name}</span>
                      <span className={`text-xs font-medium ${RARITY_COLORS[skill.rarity]}`}>
                        {RARITY_LABELS[skill.rarity]}
                      </span>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Projects */}
            {projects.length > 0 && (
              <section className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-lg p-5">
                <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Engineering Projects</h2>
                <div className="space-y-4">
                  {projects.filter(p => p.isFeatured).slice(0, 4).map(p => (
                    <div key={p.id} className="border-b border-[rgba(99,179,237,0.08)] pb-4 last:border-0 last:pb-0">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="font-medium text-sm text-slate-100">{p.title}</div>
                          {p.description && <p className="text-xs text-slate-500 mt-1 line-clamp-2">{p.description}</p>}
                          <div className="flex flex-wrap gap-1.5 mt-2">
                            {(p.techStack ?? []).slice(0, 5).map(t => (
                              <span key={t} className="px-1.5 py-0.5 rounded text-[10px] bg-[rgba(56,189,248,0.08)] text-cyan-400 border border-[rgba(56,189,248,0.15)]">{t}</span>
                            ))}
                            {(p.hardwareStack ?? []).slice(0, 3).map(t => (
                              <span key={t} className="px-1.5 py-0.5 rounded text-[10px] bg-[rgba(251,191,36,0.08)] text-amber-400 border border-[rgba(251,191,36,0.15)]">{t}</span>
                            ))}
                          </div>
                        </div>
                        {p.repoUrl && (
                          <a href={p.repoUrl} target="_blank" rel="noopener"
                            className="shrink-0 text-xs text-slate-500 hover:text-brand-cyan flex items-center gap-1 transition-colors">
                            <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-none stroke-current stroke-2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                            Repo
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>

          {/* ── Right 1/3: Heatmap ── */}
          <div className="space-y-6">

            {/* Specialization heatmap */}
            {specializationHeatmap.length > 0 && (
              <section className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-lg p-5">
                <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Specialization</h2>
                <div className="space-y-2.5">
                  {specializationHeatmap.slice(0, 8).map(h => (
                    <div key={h.branch}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-slate-400 capitalize">{h.branch.replace(/-/g, ' ')}</span>
                        <span className="text-slate-500">{Math.round(h.pct)}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-[#1a2234] overflow-hidden">
                        <div className="h-full rounded-full bg-gradient-to-r from-cyan-500/60 to-indigo-500/60 transition-all"
                          style={{ width: `${Math.max(h.pct, 2)}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Radar chart domains */}
            {radarData.length > 0 && (
              <section className="bg-[#0d1420] border border-[rgba(99,179,237,0.12)] rounded-lg p-5">
                <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Competency by Domain</h2>
                <div className="space-y-2">
                  {radarData.map(d => (
                    <div key={d.domain} className="flex items-center gap-2 text-xs">
                      <span className="w-24 text-slate-500 capitalize shrink-0">{d.domain}</span>
                      <div className="flex-1 h-1.5 rounded-full bg-[#1a2234] overflow-hidden">
                        <div className="h-full rounded-full bg-brand-indigo/50 transition-all"
                          style={{ width: `${d.score}%` }} />
                      </div>
                      <span className="text-slate-500 w-8 text-right">{d.score}%</span>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>

        {/* ── Download CV ── */}
        {cv?.shareEnabled && (
          <div className="mt-8 text-center">
            <p className="text-xs text-slate-600 mb-2">ATS-optimized CV available</p>
            <a href={`/api/cv/export?token=${cv.shareToken}`}
              className="inline-flex items-center gap-2 px-4 py-2 rounded border border-[rgba(56,189,248,0.2)] text-sm text-brand-cyan hover:bg-brand-cyan/10 transition-all">
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current stroke-2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Download CV
            </a>
          </div>
        )}

        {/* Footer */}
        <div className="mt-12 pt-6 border-t border-[rgba(99,179,237,0.08)] text-center">
          <a href="/" className="text-xs text-slate-600 hover:text-slate-400 transition-colors">
            Powered by EmbeddedRoadmap
          </a>
        </div>
      </div>
    </div>
  )
}
