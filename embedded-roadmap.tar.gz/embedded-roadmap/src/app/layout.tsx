// src/app/layout.tsx
import type { Metadata } from 'next'
import './globals.css'
import { Providers } from './providers'

export const metadata: Metadata = {
  title: { default: 'EmbeddedRoadmap', template: '%s — EmbeddedRoadmap' },
  description: 'The global engineering skill graph for electronics and embedded systems engineers.',
  keywords: ['embedded systems', 'electronics engineering', 'career roadmap', 'engineering skills', 'FPGA', 'PCB design', 'firmware'],
  authors: [{ name: 'EmbeddedRoadmap' }],
  openGraph: {
    type: 'website',
    siteName: 'EmbeddedRoadmap',
    title: 'EmbeddedRoadmap — Engineering Skill Graph',
    description: 'Track, benchmark, and accelerate your electronics engineering career.',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&family=Syne:wght@700;800&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-surface-0 text-slate-100 antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
