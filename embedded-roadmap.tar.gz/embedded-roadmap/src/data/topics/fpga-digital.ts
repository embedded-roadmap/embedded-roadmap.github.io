// src/data/topics/fpga-digital.ts
// 55 topics: digital logic to advanced FPGA, SoC, and ASIC methodology

export const FPGA_TOPICS = [
  // ── Level 1-2: Digital Logic ──────────────────────────────
  {
    slug: 'digital-logic-fundamentals',
    name: 'Digital Logic Fundamentals',
    description: 'Boolean algebra, De Morgan, Karnaugh maps, combinational vs sequential logic, metastability, setup/hold time, clock-to-Q delay, fanout.',
    level: 1, difficulty: 20, difficultyTier: 'foundational',
    keyConepts: ['Karnaugh map', 'metastability', 'setup time', 'hold time', 'fanout'],
    estimatedHours: 12,
  },
  {
    slug: 'vhdl-verilog-basics',
    name: 'VHDL & Verilog Fundamentals',
    description: 'RTL coding style, synthesizable vs behavioral constructs, entity/architecture, process, always block, blocking vs non-blocking assignment, simulation delta cycle.',
    level: 1, difficulty: 28, difficultyTier: 'foundational',
    keyConepts: ['RTL', 'synthesizable', 'blocking assignment', 'delta cycle', 'testbench'],
    tools: ['ModelSim', 'Vivado', 'Quartus', 'GHDL/Icarus'],
    estimatedHours: 20,
  },
  {
    slug: 'fpga-architecture',
    name: 'FPGA Architecture (LUT, FF, DSP, BRAM)',
    description: 'LUT4/LUT6 structure, flip-flop with CE/SR, carry chain, DSP48/DSP58 architecture, Block RAM (true dual-port), MMCM/PLL clock generation, I/O banks.',
    level: 2, difficulty: 38, difficultyTier: 'intermediate',
    keyConepts: ['LUT', 'carry chain', 'DSP48E2', 'BRAM', 'MMCM', 'IOB', 'CLB'],
    tools: ['Xilinx Vivado', 'Intel Quartus', 'Lattice Radiant'],
    estimatedHours: 18,
  },

  // ── Level 2-3: FPGA Design ────────────────────────────────
  {
    slug: 'fpga-timing-constraints',
    name: 'FPGA Timing Constraints & Closure',
    description: 'SDC constraints (create_clock, set_input_delay, set_output_delay, set_false_path, set_multicycle_path), timing reports, slack, WNS/TNS, hold violations.',
    level: 2, difficulty: 50, difficultyTier: 'intermediate',
    keyConepts: ['SDC', 'create_clock', 'false path', 'multicycle path', 'WNS', 'TNS', 'hold violation'],
    tools: ['Xilinx Vivado', 'Intel Quartus TimeQuest'],
    estimatedHours: 20,
  },
  {
    slug: 'clock-domain-crossing',
    name: 'Clock Domain Crossing (CDC)',
    description: 'Synchronizer circuits (double FF, handshake), Gray code counters for FIFOs, CDC analysis tools, metastability MTBF calculation, glitch filtering.',
    level: 3, difficulty: 60, difficultyTier: 'advanced',
    keyConepts: ['double FF sync', 'handshake', 'Gray code FIFO', 'MTBF', 'Questa CDC analyzer'],
    tools: ['Questa CDC', 'SpyGlass CDC', 'ModelSim'],
    estimatedHours: 22,
  },
  {
    slug: 'fpga-ip-core-design',
    name: 'FPGA IP Core Design',
    description: 'AXI4/AXI4-Lite/AXI4-Stream protocols, IP packager (Vivado), burst transactions, FIFO design, parameterized modules, code portability across vendors.',
    level: 3, difficulty: 58, difficultyTier: 'advanced',
    keyConepts: ['AXI4', 'AXI4-Lite', 'AXI4-Stream', 'burst', 'IP packager', 'parameterized RTL'],
    tools: ['Xilinx Vivado IP Packager', 'Modelsim', 'QSYS'],
    estimatedHours: 25,
  },
  {
    slug: 'fpga-dsp-design',
    name: 'DSP on FPGA (FIR, FFT, Filters)',
    description: 'Fixed-point arithmetic, FIR filter structures (direct, transposed), Xilinx FIR Compiler, FFT using Cooley-Tukey on FPGA, overflow and rounding, CORDIC.',
    level: 3, difficulty: 65, difficultyTier: 'advanced',
    keyConepts: ['fixed-point', 'FIR', 'Cooley-Tukey FFT', 'CORDIC', 'overflow', 'rounding'],
    tools: ['Xilinx FIR Compiler', 'Vivado HLS', 'MATLAB Fixed-Point Toolbox'],
    estimatedHours: 28,
    salaryImpact: 35,
  },

  // ── Level 3-4 ─────────────────────────────────────────────
  {
    slug: 'pcie-hardware-design',
    name: 'PCIe Hardware Design',
    description: 'PCIe Gen 1-5 lane architecture, root complex vs endpoint, BAR space, MSI-X interrupts, PCIe physical layer, equalization requirements, PCB routing rules.',
    level: 4, difficulty: 75, difficultyTier: 'expert',
    keyConepts: ['root complex', 'endpoint', 'BAR', 'MSI-X', 'gen4 equalization', 'lane count'],
    tools: ['Xilinx PCIe IP', 'LeCroy PCIe analyzer', 'Cadence Allegro'],
    estimatedHours: 30,
    salaryImpact: 40,
  },
  {
    slug: 'hls-high-level-synthesis',
    name: 'High-Level Synthesis (Vivado HLS / Vitis HLS)',
    description: 'C/C++ to RTL, pragmas (pipeline, unroll, dataflow, array_partition), latency/II trade-offs, co-simulation, IP generation, HLS limitations.',
    level: 4, difficulty: 72, difficultyTier: 'expert',
    keyConepts: ['pipeline pragma', 'II', 'dataflow', 'array partition', 'co-simulation'],
    tools: ['Xilinx Vitis HLS', 'Intel HLS Compiler', 'Cadence Stratus'],
    estimatedHours: 28,
    salaryImpact: 45,
  },
  {
    slug: 'fpga-verification-methodology',
    name: 'FPGA Verification Methodology',
    description: 'UVM basics, SystemVerilog assertions (SVA), functional coverage, constrained-random stimulus, formal verification basics (Symbiyosys), coverage closure.',
    level: 4, difficulty: 80, difficultyTier: 'expert',
    keyConepts: ['UVM', 'SVA', 'functional coverage', 'constrained random', 'formal verification'],
    tools: ['Questa Sim', 'VCS', 'Symbiyosys', 'Cadence Incisive'],
    estimatedHours: 35,
    salaryImpact: 50,
  },
  {
    slug: 'zynq-soc-design',
    name: 'Zynq UltraScale+ MPSoC Design',
    description: 'PS-PL interface via AXI, APU/RPU Linux/FreeRTOS partitioning, DMA from PL to DDR, clocking wizard, Petalinux device tree, OpenAMP for RPU-APU IPC.',
    level: 4, difficulty: 80, difficultyTier: 'expert',
    keyConepts: ['PS-PL AXI', 'APU', 'RPU', 'Petalinux', 'OpenAMP', 'HP/HPC ports'],
    tools: ['Xilinx Vivado', 'Petalinux', 'Vitis SDK'],
    estimatedHours: 40,
    salaryImpact: 55,
  },

  // ── Level 5-6 ─────────────────────────────────────────────
  {
    slug: 'asic-front-end-design',
    name: 'ASIC Front-End Design',
    description: 'RTL design for ASIC, synthesis with Design Compiler/Genus, STA with PrimeTime, clock tree concepts, scan insertion, DFT, formal equivalence checking.',
    level: 5, difficulty: 85, difficultyTier: 'elite',
    keyConepts: ['synthesis', 'STA', 'clock tree', 'scan insertion', 'DFT', 'formal equivalence'],
    tools: ['Synopsys Design Compiler', 'PrimeTime', 'Cadence Genus/Tempus'],
    estimatedHours: 45,
    salaryImpact: 70,
  },
  {
    slug: 'fpga-partial-reconfiguration',
    name: 'FPGA Partial Reconfiguration',
    description: 'Pblock definition, decoupler, dynamic function exchange (DFX), configuration interfaces (ICAP), reconfiguration time, floor-planning constraints.',
    level: 5, difficulty: 82, difficultyTier: 'elite',
    keyConepts: ['DFX', 'Pblock', 'ICAP', 'decoupler', 'reconfiguration time'],
    tools: ['Xilinx Vivado DFX', 'ICAP controller'],
    estimatedHours: 35,
    salaryImpact: 60,
  },

  // ── Level 7 ───────────────────────────────────────────────
  {
    slug: 'sky130-custom-ic',
    name: 'Custom IC Design with SkyWater 130nm PDK',
    description: 'Open-source analog IC design flow: schematic in Xschem, simulation in ngspice, layout in Magic VLSI, DRC/LVS with Netgen, post-layout extraction, OpenLane for digital.',
    level: 7, difficulty: 94, difficultyTier: 'legendary',
    keyConepts: ['Xschem', 'ngspice', 'Magic VLSI', 'DRC/LVS', 'Netgen', 'OpenLane', 'SkyWater PDK'],
    tools: ['Xschem', 'ngspice', 'Magic VLSI', 'Netgen', 'OpenLane', 'KLayout'],
    estimatedHours: 80,
    salaryImpact: 90,
  },
]

export const FPGA_BRANCH = {
  slug: 'fpga-digital-design',
  name: 'FPGA & Digital Design',
  description: 'Digital logic, FPGA architecture, AXI IPs, HLS, SoC design, and ASIC methodology.',
  domain: 'system',
  icon: '🖥️',
  color: '#a78bfa',
}
